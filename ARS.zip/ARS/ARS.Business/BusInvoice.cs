﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
   
    public class BusInvoice
    {

        DatInvoice DatI = new DatInvoice();

        public SqlDataReader fetchBookingDetails(EntInvoice EntI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntI.BookingId;
            return DatI.fetchBookingDetails(sp);
        }

        public SqlDataReader fetchCancelDetails(EntInvoice EntI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);
          
            sp.Value =EntI.BookingId;
            return DatI.fetchCancelDetails(sp);
        }

        public SqlDataReader fetchTicketDetails(EntInvoice EntI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntI.BookingId;
            return DatI.fetchTicketDetailss(sp);
        }
    }

}
