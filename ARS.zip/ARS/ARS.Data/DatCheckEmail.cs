﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace ARS.Data
{
    public class DatCheckEmail
    {
       SqlConnection con = null;

       public DatCheckEmail()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public int check(SqlParameter[] sp)
        {
            con.Open();
            SqlCommand com = new SqlCommand("check_email_available", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            SqlDataReader rdr = com.ExecuteReader();
            rdr.Read();
            if (Convert.ToInt32(rdr["count"].ToString()) != 0)
            {
                return Convert.ToInt32(rdr["count"].ToString());
            }
            con.Close();
            return 0;
        }

        public bool insert(SqlParameter[] sp)
        {
            con.Open();
            SqlCommand com = new SqlCommand("changeemail", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            SqlDataReader rdr = com.ExecuteReader();
            rdr.Read();
            if (Convert.ToBoolean(rdr["result"].ToString()) != false)
            {
                return true;
            }
            con.Close();
            return false;
        }
    }
}
