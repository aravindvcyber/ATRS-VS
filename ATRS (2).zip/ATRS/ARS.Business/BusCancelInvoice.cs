﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
    public class BusCancelInvoice
    {

        DatCancelInvoice DatCI = new DatCancelInvoice();

        public SqlDataReader fetchBookingDetails(EntCancelInvoice EntCI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntCI.BookingId;
            return DatCI.fetchBookingDetails(sp);
        }

        public SqlDataReader fetchCancelDetails(EntCancelInvoice EntCI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntCI.BookingId;
            return DatCI.fetchCancelDetails(sp);
        }

        public SqlDataReader fetchTicketDetails(EntCancelInvoice EntCI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntCI.BookingId;
            return DatCI.fetchTicketDetailss(sp);
        }

    }
}
