﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusChangePwd
    {

        DatChangePwd DatCP = new DatChangePwd();

        public bool ChangePwd(EntChangePwd EntCP)
        {

           
            SqlParameter[] sp= new SqlParameter[3];

            
            sp[0] = new SqlParameter("@userName", SqlDbType.VarChar, 15);
            sp[0].Value = EntCP.UserName;
            sp[1] = new SqlParameter("@password", SqlDbType.VarChar, 40);
            sp[1].Value = EntCP.PasswordHash;
            sp[2] = new SqlParameter("@salt", SqlDbType.VarChar, 40);
            sp[2].Value = EntCP.Salt;



            return DatCP.ChangePwd(sp);

        }
    }
}
