﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusCheckEmail
    {
        DatCheckEmail DatCE = new DatCheckEmail();
        public int check(EntCheckEmail EntCE)
        {
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("@email", SqlDbType.VarChar, 50);
            sp[0].Value = EntCE.Email;
            int count = DatCE.check(sp);
            return count;
        }

        public bool insert(EntCheckEmail EntCE)
        {
            SqlParameter[] sp = new SqlParameter[2];
            sp[0] = new SqlParameter("@email", SqlDbType.VarChar, 50);
            sp[0].Value = EntCE.Email;
            sp[1] = new SqlParameter("@cid", SqlDbType.VarChar, 6);
            sp[1].Value = EntCE.Cid;

            return DatCE.insert(sp);
        }
    }
}
