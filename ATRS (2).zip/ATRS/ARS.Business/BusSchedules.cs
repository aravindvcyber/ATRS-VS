﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
    public class BusSchedules
    {
        DatSchedules DatS = new DatSchedules();


        public DataSet fetchFlights()
        {
            return DatS.fetchFlights();
        }

        public DataSet fetchLocations()
        {
            return DatS.fetchLocations();
        }

        public bool insertSchedules(EntSchedules EntS)
        {
            SqlParameter[] sp = new SqlParameter[7];

            sp[0] = new SqlParameter("@flightid", SqlDbType.VarChar, 20);
            sp[0].Value = EntS.FlightId;
            sp[1] = new SqlParameter("@from", SqlDbType.VarChar, 20);
            sp[1].Value = EntS.From;
            sp[2] = new SqlParameter("@to", SqlDbType.VarChar, 20);
            sp[2].Value = EntS.To;
            sp[3] = new SqlParameter("@departuredate", SqlDbType.Date);
            sp[3].Value =EntS.DepartureDate ;
            sp[4] = new SqlParameter("@arrivaltime", SqlDbType.Time);
            sp[4].Value = EntS.ArrivalTime;
            sp[5] = new SqlParameter("@departuretime", SqlDbType.Time);
            sp[5].Value = EntS.DepartureTime;
            sp[6] = new SqlParameter("@duration", SqlDbType.Time);
            sp[6].Value =EntS.Duration;


            return DatS.insertSchedules(sp);
        }
    }
}
