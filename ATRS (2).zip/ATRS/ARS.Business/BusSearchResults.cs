﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
   
    public class BusSearchResults
    {
        DatSearchResults DatSR = new DatSearchResults();


        public SqlDataReader getSearchResults(EntSearchResults EntSR)
        {
            SqlParameter[] sp = new SqlParameter[5];
            sp[0] = new SqlParameter("@FromLocation", SqlDbType.VarChar, 30);
            sp[0].Value = EntSR.From;
            sp[1] = new SqlParameter("@ToLocation", SqlDbType.VarChar, 30);
            sp[1].Value = EntSR.To;
            sp[2] = new SqlParameter("@DepartureDate", SqlDbType.Date);
            sp[2].Value = EntSR.DepartureDate;
            sp[3] = new SqlParameter("@NumberOfSeats", SqlDbType.Int);
            sp[3].Value = EntSR.Seats;
            sp[4] = new SqlParameter("@ClassId", SqlDbType.Int);
            sp[4].Value = EntSR.ClassType;

            SqlDataReader rdr=DatSR.getSearchResults(sp);

            return rdr;
        }
    }
}
