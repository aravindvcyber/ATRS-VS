﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    
    
   public  class BusViewInvoice
    {
        DatViewInvoice DatVI = new DatViewInvoice();



        public SqlDataReader fetchCancelDetails(EntViewInvoice EntVI)
        {

            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntVI.BookingId;
            return DatVI.fetchCancelDetails(sp);
        }

        public SqlDataReader fetchTicketDetails(EntViewInvoice EntVI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntVI.BookingId;
            return DatVI.fetchTicketDetailss(sp);
        }

        public SqlDataReader fetchBookingDetails(EntViewInvoice EntVI)
        {
            SqlParameter sp = null;
            sp = new SqlParameter("@bookingid", SqlDbType.VarChar, 10);

            sp.Value = EntVI.BookingId;
            return DatVI.fetchBookingDetails(sp);
        }
    }
}
