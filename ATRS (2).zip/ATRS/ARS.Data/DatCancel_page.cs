﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ARS.Data
{
   public class DatCancel_page
    {
        SqlConnection con = null;

        public DatCancel_page()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
       public List<string> GetBookingDetails(SqlParameter sp)
       {
           List<string> bid = new List<string>();
           SqlCommand com = new SqlCommand("bookingid_list", con);
           com.CommandType = CommandType.StoredProcedure;
           com.Parameters.Add(sp);
           try
           {
               con.Open();
               SqlDataReader rdr= com.ExecuteReader();

               while (rdr.Read())
               {
                  bid.Add(rdr[0].ToString());
               }
           }
           catch (Exception ex)
           {
              
               throw new Exception("Exception Getting Booking Details. " + ex.Message);
           }
           finally
           {
               con.Close();
           }

           return bid;
       }
    }
}
