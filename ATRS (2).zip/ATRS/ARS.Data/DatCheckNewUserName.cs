﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatCheckNewUserName
    {
        SqlConnection con = null;

        public DatCheckNewUserName()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public int check(SqlParameter[] sp)
        {
            con.Open();
            SqlCommand com = new SqlCommand("check_uname_available", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            SqlDataReader rdr = com.ExecuteReader();
            rdr.Read();
            if (Convert.ToInt32(rdr["count"].ToString()) != 0)
            {
                return Convert.ToInt32(rdr["count"].ToString());
            }
            con.Close();
            return 0;
        }
    }
}
