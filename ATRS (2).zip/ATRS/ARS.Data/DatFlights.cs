﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace ARS.Data
{
    public class DatFlights
    {
         SqlConnection con = null;

         public DatFlights()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
        public DataSet fetchAirlines()
        {
            SqlCommand com = new SqlCommand("getAirlines", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "A_Name");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting AirLines. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public bool insertFlights(SqlParameter[] sp)
        {
            bool res = false;
            SqlCommand com = new SqlCommand("insert_flightdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();

                if (rdr.Read())
                {

                    res = true;

                }
                else
                {

                    res = false;
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Inserting new Flights. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return res;
        }
    }
}
