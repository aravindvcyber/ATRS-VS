﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace ARS.Data
{
    public class DatPreInvoice
    {

        SqlConnection con = null;

        public DatPreInvoice()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }


        public string Booking(SqlParameter sp)
        {
            string wallet;
            SqlCommand com = new SqlCommand("getwallet", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            try
            {
                con.Open();
                SqlDataReader rdr=com.ExecuteReader();
                if (rdr.Read())
                {
                    wallet = rdr["wallet"].ToString();
                }
                else
                {
                    wallet = "0";
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting wallet Details. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return wallet;
        }

        public string ContinueBooking(SqlParameter[] sp, SqlParameter outsp)
        {
            string BookingId;
            SqlCommand com = new SqlCommand("performbooking", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            com.Parameters.Add(outsp);
            
            try
            {
                con.Open();
               
                com.ExecuteNonQuery();
                BookingId = outsp.Value.ToString();
               
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception in performing booking... " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return BookingId;
        }

        public SqlDataReader FetchFlightDetails(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("preinvoice_flightdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            SqlDataReader rdr;
            try
            {
                con.Open();
                rdr = com.ExecuteReader();
                rdr.Read();


            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Flight Details. " + ex.Message);
            }
            finally
            {

            }
            return rdr;
        }
    }
}
