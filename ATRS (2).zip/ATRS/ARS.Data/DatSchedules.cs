﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Data
{
    public class DatSchedules
    {
        SqlConnection con = null;

        public DatSchedules()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public DataSet fetchFlights()
        {
            SqlCommand com = new SqlCommand("getFlights", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "FlightId");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Flights. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public DataSet fetchLocations()
        {
            SqlCommand com = new SqlCommand("getLocations", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "Location_Name");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Locations. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public bool insertSchedules(SqlParameter[] sp)
        {
            bool res = false;
            SqlCommand com = new SqlCommand("insert_scheduledetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();

                if (rdr.Read())
                {

                    res = true;

                }
                else
                {

                    res = false;
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Inserting new Schedules. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return res;
        }
    }
}
