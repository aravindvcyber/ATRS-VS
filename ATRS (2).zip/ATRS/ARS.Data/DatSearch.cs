﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatSearch
    {
        SqlConnection con = null;

        public DatSearch()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public DataSet fetchLocations()
        {
            SqlCommand com = new SqlCommand("getLocations", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "Location_Name");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Locations. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public DataSet fetchClassType()
        {
            SqlCommand com = new SqlCommand("getClassType", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "Class_Type");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Class Types. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
