﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatTransactions
    {

        SqlConnection con = null;

        public DatTransactions()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public DataSet fetchInvoice(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("getbookingids", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);
                
                sqlAdapter.Fill(ds, "BookingId");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting booking ids for all invoices. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public DataSet fetchReceipts(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("getbookingids_cancel", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "BookingId");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting booking ids for all Receipts. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
