﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntEdit
    {
        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        
        private string firstname;
        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        private string lastname;
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }
        private string emailid;

        public string EmailId
        {
            get { return emailid; }
            set { emailid = value; }
        }
        private string securityquestion;

        public string SecurityQuestion
        {
            get { return securityquestion; }
            set { securityquestion = value; }
        }
        private string mobile;

        public string Mobile
        {
            get { return mobile; }
            set { mobile = value; }
        }
        private string securityanswer;

        public string SecurityAnswer
        {
            get { return securityanswer; }
            set { securityanswer = value; }
        }
        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        private DateTime dob;

        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }
        private string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        private string ssntype;

        public string SsnType
        {
            get { return ssntype; }
            set { ssntype = value; }
        }
        private string ssnvalue;

        public string SsnValue
        {
            get { return ssnvalue; }
            set { ssnvalue = value; }
        }

        private string lastupdate;

        public string LastUpdate
        {
            get { return lastupdate; }
            set { lastupdate = value; }
        }
        
        
    }
}
