﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntForgetPwd
    {

        private string username;

        public string UserName
        {
            get { return username; }
            set { username = value; }
        }

        private string emailid;

        public string EmailId
        {
            get { return emailid; }
            set { emailid = value; }
        }

        private string security;

        public string Security
        {
            get { return security; }
            set { security = value; }
        }

        private string securityans;

        public string SecurityAns
        {
            get { return securityans; }
            set { securityans = value; }
        }
        
    }
}
