﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntLogin
    {
        private string username;

        public string UserName
        {
            get { return username; }
            set { username = value; }
        }
        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        private string passwordhash;

        public string PasswordHash
        {
            get { return passwordhash; }
            set { passwordhash = value; }
        }
        private string salt;

        public string Salt
        {
            get { return salt; }
            set { salt = value; }
        }

        private string uname;

        public string Uname
        {
            get { return uname; }
            set { uname = value; }
        }
        private string cid;

        public string Cid
        {
            get { return cid; }
            set { cid = value; }
        }
        private string fname;

        public string Fname
        {
            get { return fname; }
            set { fname = value; }
        }
        private string lname;

        public string Lname
        {
            get { return lname; }
            set { lname = value; }
        }
        private string wallet;

        public string Wallet
        {
            get { return wallet; }
            set { wallet = value; }
        }

        private string isadmin;

        public string Isadmin
        {
            get { return isadmin; }
            set { isadmin = value; }
        }


        
        

    }
}
