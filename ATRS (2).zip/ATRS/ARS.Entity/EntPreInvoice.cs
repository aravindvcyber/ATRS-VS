﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntPreInvoice
    {

        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        private int price;

        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        private int seats;

        public int Seats
        {
            get { return seats; }
            set { seats = value; }
        }

        private int classtype;

        public int ClassType
        {
            get { return classtype; }
            set { classtype = value; }
        }
        private string scheduleid;

        public string ScheduleId
        {
            get { return scheduleid; }
            set { scheduleid = value; }
        }
        private string bid;

        public string BId
        {
            get { return bid; }
            set { bid = value; }
        }
        


    }
}
