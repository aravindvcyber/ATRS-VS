﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntRegister
    {
        private string newcustid;

        public string NewCustId
        {
            get { return newcustid; }
            set { newcustid = value; }
        }
        private string customername;

        public string CustomerName
        {
            get { return customername; }
            set { customername = value; }
        }
        private string emailid;

        public string EmailId
        {
            get { return emailid; }
            set { emailid = value; }
        }
        private string securityquestion;

        public string SecurityQuestion
        {
            get { return securityquestion; }
            set { securityquestion = value; }
        }
        private string mobile;

        public string Mobile
        {
            get { return mobile; }
            set { mobile = value; }
        }
        private string securityanswer;

        public string SecurityAnswer
        {
            get { return securityanswer; }
            set { securityanswer = value; }
        }
        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        private DateTime dob;

        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }
        private string username;

        public string UserName
        {
            get { return username; }
            set { username = value; }
        }
        private string salt;

        public string Salt
        {
            get { return salt; }
            set { salt = value; }
        }

        private string passwordhash;

        public string PasswordHash
        {
            get { return passwordhash; }
            set { passwordhash = value; }
        }



     

        
        
        
        
        

    }
}
