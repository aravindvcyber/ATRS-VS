﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";

            SqlConnection con = new SqlConnection(ConnectString);
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);
            con.Open();
            string str = "select Customers.customername from Booking join customers on customers.customerid=booking.customerid where Customers.customerId='ARS001' and bookingid='B16072901'";
            SqlCommand com = new SqlCommand(str, con);
            SqlDataReader reader = com.ExecuteReader();


            reader.Read();
            Label2.Text = reader["customername"].ToString();





        }
    }
}