﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Preinvoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CustomerName.Value=Request.Cookies["uname"].Value;
        NoofPassenger.Value = Request.Cookies["seats"].Value;
        Class.Value = Request.Cookies["class"].Value;
        string SchedlueId = Request.Cookies["schedule"].Value;
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

            SqlConnection con = new SqlConnection(ConnectString);
            con.Open();
            string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
            SqlCommand com = new SqlCommand(str, con);
            SqlDataReader reader = com.ExecuteReader();


            reader.Read();
            FlightID.Value = reader["customername"].ToString();
            AirlineName.Value = reader["BookingId"].ToString();
            DepatureTime.Value = reader["BookingDate"].ToString();
            DateofJourney.Value = reader["BookingDate"].ToString();
            LeavingFrom.Value = reader["fromlocation"].ToString();
           GoingTo.Value = reader["tolocation"].ToString();


           reader.Close();   
        }
    }
   
    protected void confirm_Click(object sender, EventArgs e)
    {
        Response.Redirect("Finalinvoice.aspx");
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
}