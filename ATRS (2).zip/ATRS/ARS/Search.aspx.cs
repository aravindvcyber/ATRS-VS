﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select Location_Name,Location_id from Location_Master";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

            L1.DataSource = ds;
            L1.DataTextField = "Location_Name";
            L1.DataValueField = "Location_id";
            L1.DataBind();
            L2.DataSource = ds;
            L2.DataTextField = "Location_Name";
            L2.DataValueField = "Location_id";
            L2.DataBind();
            QueryString = "select ClassId,ClassType from Class_Master";

            myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
            ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

           classtype.DataSource = ds;
            classtype.DataTextField = "ClassType";
            classtype.DataValueField = "ClassId";
            classtype.DataBind();
           

        }

    }


    protected void Results_Click(object sender, EventArgs e)
    {
        Response.Cookies["From"].Value=L1.Value;
        Response.Cookies["To"].Value=L2.Value;
        Response.Cookies["DOJ"].Value=date.Value;
        Response.Cookies["class"].Value=classtype.Value;
        Response.Cookies["seats"].Value=D3.Value;
        Response.Redirect("search_results.aspx");
    }
}