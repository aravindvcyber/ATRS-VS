﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Preinvoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CustomerName.Value=Request.Cookies["uname"].Value;
        NoofPassenger.Value = Request.Cookies["seats"].Value;
        Class.Value = Request.Cookies["class"].Value;
        String SchedlueId = Request.Cookies["schedule"].Value;
        String Price = Request.Cookies["price"].Value;
        TotalPrice.Value =(Convert.ToInt32(Price) * Convert.ToInt32(NoofPassenger.Value)).ToString();
       
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

            SqlConnection con = new SqlConnection(ConnectString);
            
            //string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
            //SqlCommand com = new SqlCommand(str, con);
            //SqlDataReader reader = com.ExecuteReader();
            SqlCommand cmd = new SqlCommand("preinvoice_flightdetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter sqlParam = null;
            sqlParam = cmd.Parameters.Add("@scheduleid", SqlDbType.VarChar, 20);
            sqlParam.Value = SchedlueId;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            FlightID.Value = reader["FlightId"].ToString();
            AirlineName.Value = reader["a_name"].ToString();
            DepatureTime.Value = reader["departuredate"].ToString();
            DateofJourney.Value = reader["departuretime"].ToString();
            LeavingFrom.Value = reader["fromlocation"].ToString();
            GoingTo.Value = reader["tolocation"].ToString();
            reader.Close();   
        }

    }
   
    protected void confirm_Click(object sender, EventArgs e)
    {
        Booking();
        Response.Redirect("Finalinvoice.aspx");
    }
    protected void Booking()
    {
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        SqlConnection con = new SqlConnection(ConnectString);
        SqlCommand cmd = new SqlCommand("get_wallet", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        sqlParam.Value = Request.Cookies["uname"].Value;
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        int wallet = Convert.ToInt32(reader["wallet"].ToString());
        int bookingcharge = 50 * Convert.ToInt32(NoofPassenger.Value);
        int Amount = bookingcharge + Convert.ToInt32(TotalPrice.Value);
        if (wallet >= Amount)
            continueBooking();
        else
            cancelBooking();
      


    }

    private void cancelBooking()
    {
        throw new NotImplementedException();
    }
    protected void continueBooking()
    { 
        
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
}