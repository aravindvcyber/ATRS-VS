﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class search_results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //String From=Request.Cookies["From"].Value;
        //String To =Request.Cookies["To"].Value;
        //DateTime DOJ=Convert.ToDateTime(Request.Cookies["DOJ"].Value);
        //String Class=Request.Cookies["class"].Value;
        //String seats=Request.Cookies["seats"].Value;
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
}