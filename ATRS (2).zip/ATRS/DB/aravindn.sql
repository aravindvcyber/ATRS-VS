1.
create procedure cancel_details
(@bookingid varchar(20))
as 
begin

select booking.bookingid, Booking.BookingDate,A_name,departuredate,fromlocation,
tolocation,cancellationcharge,refund
from Booking join Schedules on Schedules.Id=Booking.ScheduleId join Flight_Master on Flight_Master.FlightId=Schedules.FlightId
join AIRLINES_MASTER on AIRLINES_MASTER.A_ID=Flight_Master.A_ID join Cancellation on Cancellation.customerid=cancellation.customerid
where booking.BookingId=@bookingid
end




2.
create procedure store_charges

(
@cancelid varchar(20),@customerid varchar(20),@bookingid varchar(20),@remarks varchar(255),
@cancelcharge int,@refundamount int
)
as
begin
insert into Cancellation(CancellationId,CustomerId,BookingId,Remarks,CancellationCharge,Refund)
values (@cancelid,@customerid,@bookingid,@remarks,@cancelcharge,@refundamount)

end




3.create procedure bookingid_list
(
@customerid varchar(20)
)
as 
begin

select BookingId from Booking where customerid=@customerid
end



4. 
create procedure restore_seat

(@scheduleid varchar(20), @class varchar(20),@noofseats int)

as 
begin
if @class='IClass'
update Seats_Available set Iclass=Iclass+@noofseats
where ScheduleId=@scheduleid

else if @class='IIClass'
 update Seats_Available set IIclass=IIClass+@noofseats
 where ScheduleId=@scheduleid

if @class='IIIClass'
update Seats_Available set IIIclass=IIIClass+@noofseats
where ScheduleId=@scheduleid

end 
 



5. create procedure gen_bookingid
as
begin
declare @getdate varchar(20)
declare @today_date varchar(20)
declare @id int

declare @topdata varchar(20)
select @topdata=MAX(cast(substring(bookingid,2,8)as int)) from Booking

select @getdate=substring(bookingid,2,6) from Booking where BookingId
=(select BookingId from Booking where (cast(substring(bookingid,2,8)as int)=@topdata) )

select @today_date=CONVERT(VARCHAR(10),GETDATE(),12)

if(@getdate=@today_date)
begin

select @id= MAX(cast(right(BookingId,2) as int))+1 from Booking where BookingId =(select BookingId from Booking)

select 'B'+CONVERT(VARCHAR(10),GETDATE(),12)+ REPLICATE('0',2-LEN(@id))+ CAST(@id as varchar(20))
end

else

select 'B'+CONVERT(VARCHAR(10),GETDATE(),12)+'01'
end



6.  create procedure gen_ticketid
(
@current_booking varchar(20)
)
as
begin
declare @getbooking varchar(20)
declare @id int
declare @topdata int

select @topdata=MAX(cast(substring(ticketid,2,10)as int)) from Tickets

select @getbooking=substring(ticketid,1,9) from tickets where ticketId=(select ticketId from Tickets 
where (cast(substring(ticketid,2,10)as int))=@topdata)


if(@getbooking=@current_booking)
begin
select @id= cast(right(ticketid,2) as int)+1 from Tickets where TicketId =(select ticketId from Tickets 
where (cast(substring(ticketid,2,10)as int))=@topdata)
select @current_booking+CAST(@id as varchar(20))
end
else
select @current_booking+'01'
end



7. create procedure gen_cancelid
(
@current_bookingid varchar(20)
)
as
begin
select 'C'+ SUBSTRING(@current_bookingid,2,8)
end


8.  create procedure gen_customerid
as 
begin
declare @topdata int
select @topdata= cast(right(CustomerId,3) as int)+1 from Customers
select 'ARS'+REPLICATE('0',3-LEN(@topdata))+cast((@topdata)as varchar(20))
end


exec gen_customerid 

sp_helptext RegisterUser
declare @id varchar(6)
@id=gen_customerid
print @id
print gen_customerid

use ATRS 
go
Alter PROCEDURE RegisterUser  
(    
@userName varchar(15),  
@passwordHash varchar(128),  
@salt varchar(128)  
)  
AS  
begin
declare @Id varchar(6)
@Id=gen_customerid

INSERT INTO Logins (CustomerId,UserName,password,salt)VALUES(@Id,@userName, @passwordHash, @salt)  
end
go