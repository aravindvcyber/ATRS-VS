﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.MasterPage
{
    public string SMSmsg = "Hi";
    public string Headmsg = "Successfull!";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current != null && HttpContext.Current.Request != null)
        {
            sms.Text = SMSmsg;
            heading.InnerText = Headmsg;

            if (Session["uname"] == null)
            {

                Response.Redirect("login.aspx");

            }
            else
            {
                SMSmsg += Session["fname"];
                if (Session["isadmin"].ToString() != "True")
                    Response.Redirect("user.aspx");

            }
        }
        else
        {
            Response.Redirect("expired.aspx");
        }


    }
    //protected void Page_Prerender(object sender, EventArgs e)
    //{
     

    //}
    //public void ChangeSms(string label)
    //{
    //    sms.Text = label;
    //}
    //public string Sms
    //{
    //    set
    //    {
    //        sms.Text = value;
    //    }
    //    get
    //    {
    //        return sms.ToString();
    //    }

    //}
}
