﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;
using System.Activities.Statements;
using ARS.Business;
using ARS.Entity;
/// <summary>
/// Forget Password Validation Page
/// </summary>
public partial class ForgetPwd : System.Web.UI.Page
{
    EntForgetPwd EntFP = new EntForgetPwd();
    BusForgetPwd BusFP = new BusForgetPwd();
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.QueryString.Count > 0)
        //    UserName.Value = Request.QueryString["uname"];
        if (!IsPostBack)
        {

            if (Request.QueryString.Count > 0)
            {
                errormsg.Text = Request.QueryString["err"] ;
             
                errormsg.Visible = true;
            }
            DataSet ds = new DataSet();
            ds = BusFP.getSecurityQues();

           

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();

        }
    }
    /// <summary>
    /// Forget Password Validate Button 
    /// </summary>
    protected void loginbtn_Click(object sender, EventArgs e)
    {
        EntFP.UserName = UserName.Value;
        EntFP.EmailId = email.Value;
        EntFP.Security = security.Value;
        EntFP.SecurityAns = securityans.Value;

        if (BusFP.getUserNameValidate(EntFP))
        {
            LoggingSample.Logging.LogInfo("Validating user Credentials Successfull for " + UserName.Value, true);
            Response.Cookies["uname"].Value = UserName.Value;
            //FormsAuthentication.SetAuthCookie(UserName.Value, Persist.Checked);
            Response.Redirect("ChangePassword.aspx");
        }
        else
        {
            LoggingSample.Logging.LogInfo("Validating user Credentials unsuccessfull for " + UserName.Value, true);
            Response.Redirect("ForgetPwd.aspx?err=Invalid Credentials");
        }

       

    }
}