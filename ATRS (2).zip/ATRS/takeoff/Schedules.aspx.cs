﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class Schedules : System.Web.UI.Page
{
    EntSchedules EntS = new EntSchedules();
    BusSchedules BusS = new BusSchedules();

    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "Flights Scheduler";
        ((Admin)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = BusS.fetchFlights();





            //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select FlightId from Flight_Master";

            //SqlConnection myConnection = new SqlConnection(ConnectString);
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            //ds = new DataSet();
            //myCommand.Fill(ds, "FlightId");

            flightid.DataSource = ds;
            flightid.DataTextField = "FlightId";
            flightid.DataValueField = "FlightId";
            flightid.DataBind();


            ds = BusS.fetchLocations();

            //QueryString = "select Location_Name from Location_Master";

            //myConnection = new SqlConnection(ConnectString);
            //myCommand = new SqlDataAdapter(QueryString, myConnection);
            //ds = new DataSet();
            //myCommand.Fill(ds, "Location_Name");

            L1.DataSource = ds;
            L1.DataTextField = "Location_Name";
            L1.DataValueField = "Location_Name";
            L1.DataBind();



            //QueryString = "select Location_Name from Location_Master ";

            //myConnection = new SqlConnection(ConnectString);
            //myCommand = new SqlDataAdapter(QueryString, myConnection);
            //ds = new DataSet();
            //myCommand.Fill(ds, "Location_Name");

            L2.DataSource = ds;
            L2.DataTextField = "Location_Name";
            L2.DataValueField = "Location_Name";
            L2.DataBind();

        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {

        try
        {
            EntS.FlightId = flightid.Value;
            EntS.From = L1.Value;
            EntS.To = L2.Value;
            EntS.DepartureDate = Convert.ToDateTime(this.Request.Form.Get("departuredate"));
            string arr = this.Request.Form.Get("arrivaltime");
            EntS.ArrivalTime = TimeSpan.Parse(arr);
            string dep = this.Request.Form.Get("departuretime");
            EntS.DepartureTime = TimeSpan.Parse(dep);
            TimeSpan duration = DateTime.Parse(arr).Subtract(DateTime.Parse(dep));
            EntS.Duration = duration;

            if (BusS.insertSchedules(EntS))
            {

                ControlCollection cc = new ControlCollection(this.Page.Form);
                foreach (Control c in this.Page.Form.Controls)
                {
                    foreach (Control c2 in c.Controls)
                    {
                        foreach (Control c4 in c2.Controls)
                        {

                            if (c4 is Label)
                            {
                                Label lb = (Label)c4;
                                lb.Text = "New Schedule for flight with id " + flightid.Value + " added...";
                            }
                            else if (c4.ID == "heading")
                            {

                            }

                        }
                    }
                }

                
            }
            else
            {
            }


            // SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

            // SqlCommand cmd = new SqlCommand("insert_scheduledetails", conn);
            // cmd.CommandType = CommandType.StoredProcedure;
            // SqlParameter sqlParam = null;
            // sqlParam = cmd.Parameters.Add("@flightid", SqlDbType.VarChar, 20);
            // sqlParam.Value = flightid.Value;
            // sqlParam = cmd.Parameters.Add("@from", SqlDbType.VarChar, 20);
            // sqlParam.Value = L1.Value;
            // sqlParam = cmd.Parameters.Add("@to", SqlDbType.VarChar, 20);
            // sqlParam.Value = L2.Value;
            // sqlParam = cmd.Parameters.Add("@departuredate", SqlDbType.Date);
            // sqlParam.Value = Convert.ToDateTime(this.Request.Form.Get("departuredate"));

            // sqlParam = cmd.Parameters.Add("@arrivaltime", SqlDbType.Time);
            // arr = this.Request.Form.Get("arrivaltime");
            // sqlParam.Value = TimeSpan.Parse(arr);
            // sqlParam = cmd.Parameters.Add("@departuretime", SqlDbType.Time);
            //dep = this.Request.Form.Get("departuretime");
            // sqlParam.Value = TimeSpan.Parse(dep);

            // duration = DateTime.Parse(arr).Subtract(DateTime.Parse(dep));
            // sqlParam = cmd.Parameters.Add("@duration", SqlDbType.Time);
            // sqlParam.Value = duration;

            //try
            //{
            //conn.Open();
            //cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception inserting schedule. " + ex.Message);
        }
        finally
        {
            //conn.Close();
        }

        //Response.Redirect("admin.aspx");

    }
}