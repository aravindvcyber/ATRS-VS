﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace takeoff
{
    public partial class comments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.AppendHeader("Refresh", "45");
            if (Session["uname"] != null)
            {
                HiddenField hidDate = (HiddenField)FormView1.FindControl("hidTimeDate");
                hidDate.Value = DateTime.Now.ToString();
                HiddenField hidDate1 = (HiddenField)FormView1.FindControl("HiddenField1");
                hidDate1.Value = Session["cid"].ToString();
                HiddenField hidDate2 = (HiddenField)FormView1.FindControl("HiddenField2");
                hidDate2.Value = Session["fname"].ToString();
                ((User)this.Master).SMSmsg = "We request " + Session["uname"].ToString()+" to comment and give your feedback";
                ((User)this.Master).Headmsg = "Successfully opened!";
            }
            else
            {
                Response.Redirect("login.aspx");
            }
           
        }

        protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {
            Response.Redirect("comments.aspx");
        }
    }
}