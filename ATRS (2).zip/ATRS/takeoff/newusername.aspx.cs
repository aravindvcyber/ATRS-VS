﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class newusername : System.Web.UI.Page
{
    BusCheckNewUserName BusCNUN = new BusCheckNewUserName();
    EntCheckNewUserName EntCNUN = new EntCheckNewUserName();
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void checkavailability_onclick(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(txtUsername.Text))
        {
            string str = @"^[a-zA-Z]{1}[a-zA-Z0-9]{6,15}$";
            if (Regex.IsMatch(txtUsername.Text, str))
            {
                EntCNUN.NewUser = txtUsername.Text;
                int count = BusCNUN.check(EntCNUN);
                if (count != 0)
                {
                    checkusername.Visible = true;
                    imgstatus.ImageUrl = "img/cross.jpeg";
                    lblStatus.Text = @"UserName Already Taken";
                    System.Threading.Thread.Sleep(2000);
                }
                else
                {
                    //checkusername.Visible = true;
                    //imgstatus.ImageUrl = "img/check.png";
                    //lblStatus.Text = "UserName Available";

                    System.Threading.Thread.Sleep(5000);
                    Response.Cookies["uname"].Value = txtUsername.Text;
                    Response.Redirect("Register.aspx");
                }

            }
            else
            {
                lblStatus.Text = "Invalid UserName";
            }
        }
        else
        {
            checkusername.Visible = false;
        }
    }

}

