﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class search_results : System.Web.UI.Page
{
    EntSearchResults EntSR = new EntSearchResults();
    BusSearchResults BusSR = new BusSearchResults();
    protected void Page_Load(object sender, EventArgs e)
    {
        String From = Request.Cookies["From"].Value;
        String To = Request.Cookies["To"].Value;
        DateTime DOJ = Convert.ToDateTime(Request.Cookies["DOJ"].Value);
        String Class = Request.Cookies["class"].Value;
        String seats = Request.Cookies["seats"].Value;


        try
        {
            EntSR.From = Request.Cookies["From"].Value;
            EntSR.To = Request.Cookies["To"].Value;
            EntSR.DepartureDate = Convert.ToDateTime(Request.Cookies["DOJ"].Value);
            EntSR.ClassType = Convert.ToInt32(Request.Cookies["class"].Value);
            EntSR.Seats = Convert.ToInt32(Request.Cookies["seats"].Value);

            GridView1.DataSource = BusSR.getSearchResults(EntSR);
            GridView1.DataBind();


        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception Viewing search results. " + ex.Message);
        }
        finally
        {

        }
        

        //con.Close();

        //SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        //conn.Open();


        //SqlCommand cmd = new SqlCommand("search_flights", conn);
        //cmd.CommandType = CommandType.StoredProcedure;
        //SqlParameter sqlParam = null;
        //sqlParam = cmd.Parameters.Add("@FromLocation", SqlDbType.VarChar, 30);
        //sqlParam.Value = From;

        //sqlParam = cmd.Parameters.Add("@ToLocation", SqlDbType.VarChar, 30);
        //sqlParam.Value = To;

        //sqlParam = cmd.Parameters.Add("@DepartureDate", SqlDbType.Date);
        //sqlParam.Value = DOJ;

        //sqlParam = cmd.Parameters.Add("@NumberOfSeats", SqlDbType.Int);
        //sqlParam.Value = seats;

        //sqlParam = cmd.Parameters.Add("@ClassId", SqlDbType.Int);
        //sqlParam.Value = Class;
        
       

        //GridView1.DataSource=  cmd.ExecuteReader();
        //GridView1.DataBind();

        //conn.Close();
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    { 
        Response.Cookies["scheduleid"].Value=GridView1.SelectedRow.Cells[10].Text.ToString();
        
        Response.Cookies["price"].Value=GridView1.SelectedRow.Cells[9].Text.ToString();

        Response.Redirect("preinvoice.aspx");
    }
}