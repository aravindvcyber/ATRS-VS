﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
    public class BusTopUp
    {
        DatTopUp DatTU = new DatTopUp();



        public DataSet fetchUsers()
        {
            return DatTU.fetchUsers();
        }

        public bool TopUpWallet(EntTopUp EntTU)
        {
            SqlParameter[] sp = new SqlParameter[2];

            sp[0] = new SqlParameter("@username", SqlDbType.VarChar, 20);
            sp[0].Value = EntTU.UserName;
            sp[1] = new SqlParameter("@amount", SqlDbType.Int);
            sp[1].Value = EntTU.Amount;
            return DatTU.TopUpWallet(sp);
        }
    }
}
