﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusViewStatus
    {

        DatViewStatus DatVS = new DatViewStatus();
        public int check(EntViewStatus EntVS)
        {
            SqlParameter[] sp = new SqlParameter[2];
            sp[0] = new SqlParameter("@cid", SqlDbType.VarChar, 6);
            sp[0].Value =EntVS.CustomerId;
            sp[1] = new SqlParameter("@bid", SqlDbType.VarChar, 10);
            sp[1].Value = EntVS.BookingId;
            int count = DatVS.check(sp);
            return count;
        }
    }
}
