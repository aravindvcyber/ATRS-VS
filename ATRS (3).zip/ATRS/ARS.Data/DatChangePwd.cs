﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace ARS.Data
{
    public class DatChangePwd
    {
        SqlConnection con = null;

        public DatChangePwd()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

       
        public bool ChangePwd(SqlParameter[] sp)
        {
           
            SqlCommand com = new SqlCommand("ChangePassword", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);

            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                return false;
                throw new Exception("Exception Changing Password" + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return true;

        }
    }
}
