﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntCancel_details
    {
        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        private string bookingid;

        public string BookingId
        {
            get { return bookingid; }
            set { bookingid = value; }
        }
        private string remarks;

        public string Remarks
        {
            get { return remarks; }
            set { remarks = value; }
        }

        private Dictionary<string,string> candet;

        public Dictionary<string,string> CanDet
        {
            get { return candet; }
            set { candet = value; }
        }
        private int cancelcharge;

        public int CancelCharge
        {
            get { return cancelcharge; }
            set { cancelcharge = value; }
        }

        private int refund;

        public int Refund
        {
            get { return refund; }
            set { refund = value; }
        }


        
    }
}
