﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntUnlockUser
    {


        private string username;

        public string UserName
        {
            get { return username; }
            set { username = value; }
        }
        
    }
}
