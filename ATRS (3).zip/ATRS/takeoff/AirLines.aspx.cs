﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
public partial class AirLines : System.Web.UI.Page
{
    EntAirlines EntA = new EntAirlines();
    BusAirlines BusA = new BusAirlines();


    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "New Airlines inserter";
        ((Admin)this.Master).Headmsg = "Successfully opened!";
        CalendarExtender1.EndDate = DateTime.Now;
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }

    protected void insert_Click(object sender, EventArgs e)
    { try
        {

        EntA.AirlineName = airline_name.Value;
        EntA.Logo = logo.Value;
        EntA.DOP=Convert.ToDateTime(dop.Text);
        if (BusA.insertAirlines(EntA))
        {
            ControlCollection cc = new ControlCollection(this.Page.Form);
            foreach (Control c in this.Page.Form.Controls)
            {
                foreach (Control c2 in c.Controls)
                {
                    foreach (Control c4 in c2.Controls)
                    {

                        if (c4 is Label)
                        {
                            Label lb = (Label)c4;
                            lb.Text = "AirLine " + airline_name.Value + " added...";
                        }
                        else if (c4.ID == "heading")
                        {

                        }

                    }
                }
            }

            //((Admin)this.Master).SMSmsg = "AirLine " + airline_name.Value + " added...";
            //((Admin)this.Master).Headmsg = "Successfull!";
        }
        else
        {

        }

        
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception  inserting new airline. " + ex.Message);
        }
        finally
        {
            airline_name.Value = "";
        }
       
        //Response.Redirect("admin.aspx");
    }
}