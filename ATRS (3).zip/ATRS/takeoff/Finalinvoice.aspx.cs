﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Entity;
using ARS.Business;

public partial class Finalinvoice : System.Web.UI.Page
{
    EntFinalInvoice EntFI = new EntFinalInvoice();
    BusFinalInvoice BusFI = new BusFinalInvoice();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {

            Response.Redirect("login.aspx");

        }
        else
        {
            if (Request.Cookies["seats"] != null && Request.Cookies["price"] != null && Request.Cookies["scheduleid"] != null && Request.Cookies["class"] != null && Request.Cookies["bookingid"] != null)
            {
            ((MasterPage)this.Master.Master).displayMessage("<p style='color:navy;'>Sucessfull Booking</p> Booking Id <br/>" + Request.Cookies["bookingid"].Value);
            CustomerName.Value = Session["fname"].ToString() + " " + Session["lname"].ToString();
            NoofPassenger.Value = Request.Cookies["seats"].Value;
            //ClassType.Value = Request.Cookies["class"].Value;
            switch (Convert.ToInt32(Request.Cookies["class"].Value))
            {
                case 1:
                    ClassType.Value = "Business";
                    break;
                case 2:
                    ClassType.Value = "Economy";
                    break;
                case 3:
                    ClassType.Value = "First Class";
                    break;
                default:
                    ClassType.Value = "Not Available";
                    break;
            }
            today.Value = DateTime.Now.ToShortDateString();
            string SchedlueId = Request.Cookies["scheduleid"].Value;
            String Price = Request.Cookies["price"].Value;
            TotalPrice.Value = (Convert.ToInt32(Price) * Convert.ToInt32(NoofPassenger.Value)).ToString();
            BookingID.Value = Request.Cookies["bookingid"].Value;
            if (!IsPostBack)
            {

                FetchFlightDetails();

            }
            }
            else
            {
                Response.Redirect("user.aspx");
            }
        }


    }

    private void FetchFlightDetails()
    {

        EntFI.ScheduleId = Request.Cookies["scheduleid"].Value;
        SqlDataReader reader = BusFI.FetchFlightDetails(EntFI);



        svgimg.Src = reader["Logo"].ToString();
        FlightID.Value = reader["FlightId"].ToString();
        aname.Value = reader["a_name"].ToString();
        DepatureTime.Value = Convert.ToDateTime(reader["departuretime"].ToString()).ToShortTimeString();
        DateofJourney.Value = Convert.ToDateTime(reader["departuredate"].ToString()).ToShortDateString();
        LeavingFrom.Value = reader["fromlocation"].ToString();
        GoingTo.Value = reader["tolocation"].ToString();

        foreach (Control c in this.Page.Form.Controls)
        {

            foreach (Control c2 in c.Controls)
            {
                foreach (Control c4 in c2.Controls)
                {

                    if (c4 is Label)
                    {
                        Label lb = (Label)c4;
                        lb.Text = "Booking Id is " + BookingID.Value + "...";
                    }
                    else if (c4.ID == "heading")
                    {

                    }

                }
            }
        }
        reader.Close();
    }
    protected void Home_Click(object sender, EventArgs e)
    {
        Response.Redirect("user.aspx");
    }
    protected void Print_Click(object sender, EventArgs e)
    {
        Response.Cookies["bookingid"].Value = BookingID.Value;
        Response.Redirect("invoice.aspx");
    }
}