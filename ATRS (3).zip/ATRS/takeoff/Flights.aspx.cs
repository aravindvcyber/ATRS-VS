﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class Flights : System.Web.UI.Page
{
    EntFlights EntF = new EntFlights();
    BusFlights BusF = new BusFlights();
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "New Flights inserter";
        ((Admin)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = BusF.fetchAirlines();


            
         

            airlineid.DataSource = ds;
            airlineid.DataTextField = "A_Name";
            airlineid.DataValueField = "A_Name";
            airlineid.DataBind();
        }
    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        
         try
        {
        EntF.AirlineId=airlineid.Value;
        EntF.ISeats= Convert.ToInt32(Iseats.Value);
        EntF.IPrice = Convert.ToInt32(Iprice.Value);
        EntF.IISeats= Convert.ToInt32(IIseats.Value);
        EntF.IIPrice=Convert.ToInt32(IIprice.Value);
        EntF.IIISeats= Convert.ToInt32(IIIseats.Value);
        EntF.IIIPrice=Convert.ToInt32(IIIprice.Value);
          if(BusF.insertFlights(EntF))
          {
              ControlCollection cc = new ControlCollection(this.Page.Form);
              foreach (Control c in this.Page.Form.Controls)
              {
                  foreach (Control c2 in c.Controls)
                  {
                      foreach (Control c4 in c2.Controls)
                      {

                          if (c4 is Label)
                          {
                              Label lb = (Label)c4;
                              lb.Text = "New Flight from " + airlineid.Value + " added...";
                          }
                          else if (c4.ID == "heading")
                          {

                          }

                      }
                  }
              }

              //((Admin)this.Master).SMSmsg = "New Flight from " + airlineid.Value + " added...";
              //((Admin)this.Master).Headmsg = "Successfull!";
          }
              else
          {
          }



       
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception adding flight details " + ex.Message);
        }
        finally
        {
            Iseats.Value = "";
            IIseats.Value = "";
            IIIseats.Value = "";
            Iprice.Value = "";
            IIprice.Value = "";
            IIIprice.Value = "";
        }
       
        //Response.Redirect("admin.aspx");
    }

    protected void cancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("admin.aspx");
    }
}