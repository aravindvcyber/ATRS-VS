﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class Locations : System.Web.UI.Page
{

    BusLocations BusL = new BusLocations();
    EntLocations EntL =  new EntLocations();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ((Admin)this.Master).SMSmsg = "Locations Inserter";
            ((Admin)this.Master).Headmsg = "Successfully opened!";
        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {

        

        try{
        EntL.LocationName = locationname.Value;
        if (BusL.insertLocations(EntL))
        {
            ControlCollection cc = new ControlCollection(this.Page.Form);
            foreach (Control c in this.Page.Form.Controls)
            {
                foreach (Control c2 in c.Controls)
                {
                    foreach (Control c4 in c2.Controls)
                    {

                        if (c4 is Label)
                        {
                            Label lb = (Label)c4;
                            lb.Text = "Location " + locationname.Value + " added...";
                        }
                        else if (c4.ID == "heading")
                        {

                        }

                    }
                }
            }
        }
        else
        {
        }
        
        }
        catch (Exception ex)
        {

            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception inserting location. " + ex.Message);
        }
        finally
        {
            locationname.Value = "";
        }

        
      
        
        //Response.Redirect("Locations.aspx");
    }
}