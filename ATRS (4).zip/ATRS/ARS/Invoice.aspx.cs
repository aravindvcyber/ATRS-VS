﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Invoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

            SqlConnection con = new SqlConnection(ConnectString);
            con.Open();
            string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
            SqlCommand com = new SqlCommand(str, con);
            SqlDataReader reader = com.ExecuteReader();


            reader.Read();
            CusName.Text = reader["customername"].ToString();
            BookId.Text = reader["BookingId"].ToString();
            BookDate.Text = reader["BookingDate"].ToString();
            mobile.Text = reader["mobile"].ToString();
            booking.Text = "&#8377 " + reader["Bookingcharge"].ToString();
            Total.Text = "&#8377 " + reader["Amount"].ToString();
            ticket.Text = "&#8377 " + (Convert.ToInt32(reader["Amount"].ToString()) - Convert.ToInt32(reader["Bookingcharge"].ToString())).ToString();
            fromloc.Text = reader["fromlocation"].ToString();
            toloc.Text = reader["tolocation"].ToString();
            classtype.Text = reader["classtype"].ToString();
            dateofjourney.Text = Convert.ToDateTime(reader["departuredate"]).ToShortDateString() + " " +reader["DepartureTime"].ToString();
            reader.Close();
           
             str = "select TicketId from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Tickets on Tickets.BookingId=Booking.BookingId  where Customers.customerId='ARS001' and Booking.bookingid='B16072901'";
             com = new SqlCommand(str, con);
             reader = com.ExecuteReader();

           
          
             while (reader.Read())
             {
                
                Tickets.Items.Add(reader[0].ToString());
             }
             reader.Close();
             str = "select TicketId from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Tickets on Tickets.BookingId=Booking.BookingId  where Customers.customerId='ARS001' and Booking.bookingid='B16072901' and status='false'";
             com = new SqlCommand(str, con);
             reader = com.ExecuteReader();



             while (reader.Read())
             {

                 TicketsCancel.Text += reader[0].ToString() + " ";

             }
        }
    }
}