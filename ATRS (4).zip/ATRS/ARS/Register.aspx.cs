﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.Cookies["uname"].Value != null)
        {
            UserName.Value = Request.Cookies["uname"].Value;
        }

        else
        {
            Response.Redirect("newusername.aspx");
        }

    }
    //    public void register_click()
    //{
    //    int saltSize = 5;
    //    string salt = CreateSalt(saltSize);
    //    string passwordHash = CreatePasswordHash(UserName.Value, salt);
    //    try
    //    {
    //        StoreAccountDetails(UserName.Value, passwordHash, salt);
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMessage.Text = ex.Message;
    //    }
    //}
    protected void StoreAccountDetails(string userName,string passwordHash,string salt)
    {


        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("RegisterUser", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        
        
        sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar,15);
        sqlParam.Value = userName;
        sqlParam = cmd.Parameters.Add("@passwordHash ", SqlDbType.VarChar,40);
        sqlParam.Value = passwordHash;
        sqlParam = cmd.Parameters.Add("@salt ", SqlDbType.VarChar, 40);
        sqlParam.Value = salt;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception adding account. " + ex.Message);
        }
        finally
        {
            conn.Close();
        }
    }
    protected static string CreateSalt(int size)
    {
        // Generate a cryptographic random number using the cryptographic
        // service provider
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] buff = new byte[size];
        rng.GetBytes(buff);
        // Return a Base64 string representation of the random number
        return Convert.ToBase64String(buff);
    }
    protected static string CreatePasswordHash(string pwd, string salt)
    {
        string saltAndPwd = String.Concat(pwd, salt);
        string hashedPwd =FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
        hashedPwd = String.Concat(hashedPwd, salt);
        return hashedPwd;
    }


    protected void registerbtn_Click(object sender, EventArgs e)
    {
        int saltSize = 5;
        string salt = CreateSalt(saltSize);
        string passwordHash = CreatePasswordHash(UserName.Value, salt);
        try
        {
            StoreAccountDetails(UserName.Value, passwordHash, salt);
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
    }
}