﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using LoggingSample;
using System.Data.SqlClient;
using System.Data;

public partial class MasterPage : System.Web.UI.MasterPage
{
    string user = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["uname"] == null)
        {

            logout.Text = "login";
        }
        else
        {
            logout.Text = "logout";
        }


        try
        {
            //HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.Response.Cache.SetNoServerCaching();
            //HttpContext.Current.Response.Cache.SetNoStore();
            //{get data from database by passing userid}
            ////to check if it logs the error throw an argument exception
            //throw new ArgumentException("generated error");
            //on success Log the activity
            if (Session["uname"] == null)
            {
                user = "Guest";
                uname.Text = "Guest";
            }
            else
            {
                user = Session["uname"].ToString();
                uname.Text = Session["uname"].ToString();
            }
            Logging.LogInfo("Get successful for userid : " + user, true);
            //uname.Text = if(Session["uname"].ToString()==null)? Request.Cookies["uname"].ToString():Session["uname"].ToString();
            //wallet.Text = Session["wallet"].ToString();
            getwallet();
        }
        catch (Exception ex)
        {
            //on error log the exception
            Logging.LogException(ex, "Error in data bind");
        }

    }

    private void getwallet()
    {
        string custid = Session["cid"].ToString();
        //custid = Request.Cookies["customerid"].Value;
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select BookingId from Booking";
        SqlConnection myConnection = new SqlConnection(ConnectString);
        SqlCommand storedProcCommand = new SqlCommand("getwallet", myConnection);
        storedProcCommand.CommandType = CommandType.StoredProcedure;
        //storedProcCommand.Parameters.Add("@customerid", Request.Cookies["customerid"].Value);
        SqlParameter parameter = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
        //Set the parameter direction as output
        //parameter.Direction = ParameterDirection.Output;
        storedProcCommand.Parameters.Add(parameter);
        parameter.Value = custid;
        SqlDataAdapter sqlAdapter = new SqlDataAdapter(storedProcCommand);
        DataSet ds = new DataSet();
        sqlAdapter.Fill(ds, "wallet");
        //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select BookingId from Booking";

        //SqlConnection myConnection = new SqlConnection(ConnectString);
        //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
        //DataSet ds = new DataSet();
        //myCommand.Fill(ds, "BookingId");

        wallet.Text = ds.Tables[0].Rows[0][0].ToString();
       
      
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        //Session.RemoveAll;
        Session.RemoveAll(); 
        uname.Text = "User";
        wallet.Text = "";
        logout.Text = "login";
        if (logout.Text == "logout")
            Response.Redirect("home.aspx");
        else
            Response.Redirect("login.aspx");
    }
}
