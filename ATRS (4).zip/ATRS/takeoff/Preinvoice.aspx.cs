﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Preinvoice : System.Web.UI.Page
{
    String SchedlueId;

    String Price; 
    protected void Page_Load(object sender, EventArgs e)
    {
         CustomerName.Value=Session["fname"].ToString()+ " " +Session["lname"].ToString();
         NoofPassenger.Value = Request.Cookies["seats"].Value;
         Class.Value = Request.Cookies["class"].Value;
         SchedlueId = Request.Cookies["scheduleid"].Value;
        Price = Request.Cookies["price"].Value;
        TotalPrice.Value =(Convert.ToInt32(Price) * Convert.ToInt32(NoofPassenger.Value)).ToString();
       
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

            SqlConnection con = new SqlConnection(ConnectString);
            
            //string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
            //SqlCommand com = new SqlCommand(str, con);
            //SqlDataReader reader = com.ExecuteReader();
            SqlCommand cmd = new SqlCommand("preinvoice_flightdetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter sqlParam = null;
            sqlParam = cmd.Parameters.Add("@scheduleid", SqlDbType.VarChar, 20);
            sqlParam.Value = SchedlueId;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            FlightID.Value = reader["FlightId"].ToString();
            AirlineName.Value = reader["a_name"].ToString();
            DepatureTime.Value = reader["departuredate"].ToString();
            DateofJourney.Value = reader["departuretime"].ToString();
            LeavingFrom.Value = reader["fromlocation"].ToString();
            GoingTo.Value = reader["tolocation"].ToString();
            reader.Close();   
        }

    }
   
    protected void confirm_Click(object sender, EventArgs e)
    {
        Booking();
        Response.Redirect("Finalinvoice.aspx");
    }
    protected void Booking()
    {
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        SqlConnection con = new SqlConnection(ConnectString);
        SqlCommand cmd = new SqlCommand("getwallet", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        sqlParam.Value = Session["cid"].ToString();
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        int wallet = Convert.ToInt32(reader["wallet"].ToString());
        int bookingcharge = 50 * Convert.ToInt32(NoofPassenger.Value);
        int Amount = bookingcharge + Convert.ToInt32(TotalPrice.Value);
        if (wallet >= Amount)
            continueBooking();
        else
            cancelBooking();
    }

    private void cancelBooking()
    {
        Response.Redirect("user.aspx");
    }
    protected void continueBooking()
    {
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        SqlConnection con = new SqlConnection(ConnectString);
        con.Open();
        SqlCommand cmd = new SqlCommand("performbooking", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        sqlParam.Value = Session["cid"].ToString();
        sqlParam = cmd.Parameters.Add("@classtype", SqlDbType.Int);
        sqlParam.Value = Convert.ToInt32(Class.Value);
        sqlParam = cmd.Parameters.Add("@seats", SqlDbType.Int);
        sqlParam.Value = Convert.ToInt32(NoofPassenger.Value);
        sqlParam = cmd.Parameters.Add("@scheduleid", SqlDbType.VarChar, 10);
        sqlParam.Value = Request.Cookies["scheduleid"].Value;
        sqlParam = cmd.Parameters.Add("@price", SqlDbType.Int);
        sqlParam.Value = Convert.ToInt32(Price);
        SqlParameter outbid = null;
        outbid = cmd.Parameters.Add("@bid", SqlDbType.VarChar, 20);
        outbid.Direction = ParameterDirection.Output;
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        //cmd.ExecuteNonQuery();
         string id=outbid.Value.ToString();
         reader.Close();
     
       if (id!=null)
       {

           Response.Cookies["bookingid"].Value = id;
                Response.Redirect("finalinvoice.aspx");
            }
            else
            {
                Response.Redirect("Search.aspx");
            }
        
    }
    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
}