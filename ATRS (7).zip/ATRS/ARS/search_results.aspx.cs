﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class search_results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Cookies["From"].Value = L1.Value;
        //Response.Cookies["To"].Value = L2.Value;
        //Response.Cookies["DOJ"].Value = date.Value;
        //Response.Cookies["class"].Value = classtype.Value;
        //Response.Cookies["seats"].Value = D3.Value;
        //Response.Redirect("search_results.aspx");
    }
}