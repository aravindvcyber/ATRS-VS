﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;
namespace ARS.Business
{ 

   
    public class BusAirlines
    {

        DatAirlines DatA = new DatAirlines();
        public bool insertAirlines(EntAirlines EntA)
        {

            SqlParameter[] sp = new SqlParameter[3];
            sp[0] = new SqlParameter("@airlinename", SqlDbType.VarChar, 20);
            sp[0].Value = EntA.AirlineName;
            sp[1] = new SqlParameter("@dop",SqlDbType.Date);
            sp[1].Value = EntA.DOP;
            sp[2] = new SqlParameter("@logo", SqlDbType.VarChar, 150);
            sp[2].Value = EntA.Logo;

           return DatA.insertAirLines(sp);
        }
    }
}
