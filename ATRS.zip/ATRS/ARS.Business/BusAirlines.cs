﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
namespace ARS.Business
{ 

   
    public class BusAirlines
    {

        DatAirlines DatA = new DatAirlines();
        public bool insertAirlines(EntAirlines EntA)
        {

            SqlParameter[] sp = new SqlParameter[2];
            sp[0] = new SqlParameter("@airlinename", System.Data.SqlDbType.VarChar, 20);
            sp[0].Value = EntA.AirlineName;
            sp[1] = new SqlParameter("@dop", System.Data.SqlDbType.Date);
            sp[1].Value = EntA.DOP;

           return DatA.insertAirLines(sp);
        }
    }
}
