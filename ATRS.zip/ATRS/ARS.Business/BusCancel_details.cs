﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using ARS.Data;
using ARS.Entity;

namespace ARS.Business
{
   public class BusCancel_details
    {


       DatCancel_details DatCD = new DatCancel_details();
       public Dictionary<string, string> GetCanceldetails(EntCancel_details EntCD)
       {
           Dictionary<string, string> candet = new Dictionary<string, string>();

           SqlParameter sp = new SqlParameter("@bookingid", EntCD.BookingId);

           candet = DatCD.GetCanceldetails(sp);


           return candet;
       }

       public void cancelTickets(EntCancel_details EntCD)
       {
           
           SqlParameter[] sp = new SqlParameter[5];
           sp[0] = new SqlParameter("@customerid", EntCD.CustomerId);

           sp[1] = new SqlParameter("@bookingid",EntCD.BookingId);

           sp[2] = new SqlParameter("@remarks", EntCD.Remarks);

           sp[3] = new SqlParameter("@cancelcharge", EntCD.CancelCharge);

           sp[4] = new SqlParameter("@refundamount", EntCD.Refund);
           

           DatCD.cancelTickets(sp);
       }
    }
}
