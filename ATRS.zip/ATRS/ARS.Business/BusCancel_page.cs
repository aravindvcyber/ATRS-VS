﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using ARS.Data;
using ARS.Entity;

namespace ARS.Business
{
    public class BusCancel_page
    {
        DatCancel_page DatCP = new DatCancel_page();

        public List<string> GetBookingDetails(EntCancel_page EntCP)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@CustomerId", EntCP.CustomerId);


            List<string> bid = DatCP.GetBookingDetails(sp);


            return bid;
        }

    }
}
