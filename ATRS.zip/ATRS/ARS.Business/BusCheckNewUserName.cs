﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using ARS.Business;
using System.Data;
using System.Data.SqlClient;


namespace ARS.Business
{
    public class BusCheckNewUserName
    {

        DatCheckNewUserName DatCNUN = new DatCheckNewUserName();

        public int check(EntCheckNewUserName EntCNUN)
        {
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 20);
            sp[0].Value = EntCNUN.NewUser;
            int count = DatCNUN.check(sp);
            return count;
        }

    }
}
