﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusFinalInvoice
    {
        DatFinalInvoice DatFI = new DatFinalInvoice();

        public SqlDataReader FetchFlightDetails(EntFinalInvoice EntFI)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@scheduleid", SqlDbType.VarChar, 10);
            sp.Value = EntFI.ScheduleId;

            return DatFI.FetchFlightDetails(sp);
        }
    }
}
