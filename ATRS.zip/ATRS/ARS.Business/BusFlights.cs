﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
    public class BusFlights
    {
        DatFlights DatF = new DatFlights();

        public DataSet fetchAirlines()
        {
            return DatF.fetchAirlines();
        }

        public bool insertFlights(EntFlights EntF)
        {

            SqlParameter[] sp = new SqlParameter[7];

            sp[0] = new SqlParameter("@airlinename", SqlDbType.VarChar, 15);
            sp[0].Value = EntF.AirlineId;
            sp[1] = new SqlParameter("@Iseats", SqlDbType.Int);
            sp[1].Value = EntF.ISeats;
            sp[2] = new SqlParameter("@Iprice", SqlDbType.Int);
            sp[2].Value = EntF.IPrice;
            sp[3] = new SqlParameter("@IIseats", SqlDbType.Int);
            sp[3].Value = EntF.IISeats;
            sp[4] = new SqlParameter("@IIprice", SqlDbType.Int);
            sp[4].Value = EntF.IIPrice;
            sp[5] = new SqlParameter("@IIIseats", SqlDbType.Int);
            sp[5].Value = EntF.IIISeats;
            sp[6] = new SqlParameter("@IIIprice", SqlDbType.Int);
            sp[6].Value = EntF.IIIPrice;
          
            return DatF.insertFlights(sp);
        }
    }
}
