﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using System.Data.SqlClient;
using ARS.Entity;

namespace ARS.Business
{

    public class BusForgetPwd
    {
        DatForgetPwd DatFP = new DatForgetPwd();

        public bool getUserNameValidate(EntForgetPwd EntFP)
        {
            SqlParameter[] sp = new SqlParameter[4];
            sp[0] = new SqlParameter("@username", System.Data.SqlDbType.VarChar, 20);
            sp[0].Value = EntFP.UserName;
            sp[1] = new SqlParameter("@emailid", System.Data.SqlDbType.VarChar, 50);
            sp[1].Value = EntFP.EmailId;
            sp[2] = new SqlParameter("@security", System.Data.SqlDbType.VarChar, 50);
            sp[2].Value = EntFP.Security;
            sp[3] = new SqlParameter("@securityans", System.Data.SqlDbType.VarChar, 100);
            sp[3].Value = EntFP.SecurityAns;
            bool count = DatFP.getUserNameValidate(sp);
            return count;
        }
    }
}
