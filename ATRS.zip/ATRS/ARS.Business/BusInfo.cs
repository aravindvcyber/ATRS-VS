﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;


namespace ARS.Business
{
    public class BusInfo
    {
        DatInfo DatI = new DatInfo();



        public SqlDataReader FetchCounts()
        {


            return DatI.FetchCounts();
        }
    }
}
