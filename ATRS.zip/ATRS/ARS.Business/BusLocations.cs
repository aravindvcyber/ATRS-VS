﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Entity;
using ARS.Data;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{

   
    public class BusLocations
    {
        DatLocations DatL = new DatLocations();

        public bool insertLocations(EntLocations EntL)
        {
            SqlParameter[] sp = new SqlParameter[1];
            sp[0] = new SqlParameter("@locname", SqlDbType.VarChar, 30);
            sp[0].Value = EntL.LocationName;
            return DatL.insertLocations(sp[0]);
        }
    }
}
