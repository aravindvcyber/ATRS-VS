﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;

namespace ARS.Business
{
    public class BusLogin
    {
        DatLogin DatL = new DatLogin();

        public Dictionary<string, string> AuthenticateAdmin(EntLogin EntL)
        {
            SqlParameter[] sp = new SqlParameter[2];

            EntL.PasswordHash = getPasswordHash(EntL);

            sp[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 15);
            sp[0].Value = EntL.UserName;
            sp[1] = new SqlParameter("@Password", SqlDbType.VarChar, 40);
            sp[1].Value = EntL.PasswordHash;


            generatesessionvariables(UserName.Value);
            Response.Write("<script type='javascript'>alert('Logged in Successfully')</script>");
            FormsAuthentication.RedirectFromLoginPage(UserName.Value, Persist.Checked);


            return DatL.AuthenticateAdmin(sp);
        }

        public Dictionary<string, string> AuthenticateUser(EntLogin EntL)
        {
            SqlParameter[] sp = new SqlParameter[2];

            EntL.PasswordHash = getPasswordHash(EntL);

            sp[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 15);
            sp[0].Value = EntL.UserName;
            sp[1] = new SqlParameter("@Password", SqlDbType.VarChar, 40);
            sp[1].Value = EntL.PasswordHash;
            return DatL.AuthenticateUser(sp);
        }

        public bool checkAdmin(EntLogin EntL)
        {
            SqlParameter[] sp = new SqlParameter[1];


            sp[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 15);
            sp[0].Value = EntL.UserName;

            return DatL.checkAdmin(sp);
        }
        public string getPasswordHash(EntLogin EntL)
        {
            EntL.Salt = getSalt(EntL);
            string saltAndPwd = String.Concat(EntL.Password, EntL.Salt);
            string hashedPwd = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
            //hashedPwd = String.Concat(hashedPwd, salt);
            return hashedPwd;
        }
        public string getSalt(EntLogin EntL)
        {

            SqlParameter[] sp = new SqlParameter[1];

            sp[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 15);
            sp[0].Value = EntL.UserName;

            return DatL.getSalt(sp);
        }
        public Dictionary<string, string> generatesessionvariables(EntLogin EntL)
        {
            SqlParameter[] sp = new SqlParameter[1];

            sp[0] = new SqlParameter("@UserName", SqlDbType.VarChar, 15);
            sp[0].Value = EntL.UserName;

            return DatL.generatesessionvariables(sp);


            //string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
            //using (SqlConnection con = new SqlConnection(CS))
            //{
            //    //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
            //    SqlCommand cmd = new SqlCommand("sessionvariables", con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    SqlParameter sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar, 15);
            //    sqlParam.Value = UserName;
            //    con.Open();
            //    SqlDataReader rdr = cmd.ExecuteReader();
            //    while (rdr.Read())
            //    {
            //        Session["uname"] = UserName;
            //        Session["cid"] = rdr["customerid"].ToString();
            //        Session["fname"] = rdr["firstname"].ToString();
            //        Session["lname"] = rdr["lastname"].ToString();
            //        Session["wallet"] = rdr["wallet"].ToString();
            //        Session["isadmin"] = rdr["isadmin"].ToString();
            //    }
            //}
        }
    }
}
