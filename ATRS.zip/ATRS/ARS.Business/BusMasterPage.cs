﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
   public class BusMasterPage

    {
       DatMasterPage DatMP = new DatMasterPage();
        public DataSet getWallet(EntMasterPage EntMP)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            sp.Value = EntMP.CustomerId;

            return DatMP.getWallet(sp);
        }

    }
}
