﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusPreInvoice
    {
        DatPreInvoice DatPI = new DatPreInvoice();




        public string Booking(EntPreInvoice EntPI)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            sp.Value = EntPI.CustomerId;

             return DatPI.Booking(sp);
        }

        public string ContinueBooking(EntPreInvoice EntPI)
        {
            SqlParameter[] sp = new SqlParameter[5];

            sp[0] = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            sp[0].Value = EntPI.CustomerId;
            sp[1] = new SqlParameter("@classtype", SqlDbType.Int);
            sp[1].Value = EntPI.ClassType;
            sp[2] = new SqlParameter("@seats", SqlDbType.Int);
            sp[2].Value = EntPI.Seats;
            sp[3] = new SqlParameter("@scheduleid", SqlDbType.VarChar, 10);
            sp[3].Value = EntPI.ScheduleId;
            sp[4] = new SqlParameter("@price", SqlDbType.Int);
            sp[4].Value = EntPI.Price;

            SqlParameter outsp = new SqlParameter("@bid", SqlDbType.VarChar, 10);
            outsp.Direction = ParameterDirection.Output;
            

            return DatPI.ContinueBooking(sp,outsp);
        }

        public SqlDataReader FetchFlightDetails(EntPreInvoice EntPI)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@scheduleid", SqlDbType.VarChar, 20);
            sp.Value = EntPI.ScheduleId;

            return DatPI.FetchFlightDetails(sp);
        }
    }
}
