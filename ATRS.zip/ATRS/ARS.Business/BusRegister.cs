﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using ARS.Data;
using ARS.Entity;

namespace ARS.Business
{
    public class BusRegister
    {
     
        DatRegister DatR=new DatRegister();

        public void StoreAccountDetails(EntRegister EntR)
        {
            
            string newcustid=DatR.getnewcustid();

            SqlParameter[] sp = new SqlParameter[10];
            
            sp[0] = new SqlParameter("@CustomerId", SqlDbType.VarChar, 6);
            sp[0].Value = newcustid;
            sp[1] = new SqlParameter("@CustomerName", SqlDbType.VarChar, 25);
            sp[1].Value = EntR.CustomerName;
            sp[2] = new SqlParameter("@EmailId ", SqlDbType.VarChar, 50);
            sp[2].Value = EntR.EmailId;
            sp[3] = new SqlParameter("@SecurityQuestion", SqlDbType.VarChar, 50);
            sp[3].Value = EntR.SecurityQuestion;
            sp[4] = new SqlParameter("@SecurityAnswer", SqlDbType.VarChar, 50);
            sp[4].Value = EntR.SecurityAnswer;
            sp[5] = new SqlParameter("@mobile", SqlDbType.VarChar, 15);
            sp[5].Value = EntR.Mobile;
            sp[6] = new SqlParameter("@Gender", SqlDbType.VarChar, 10);
            sp[6].Value = EntR.Gender;
            sp[7] = new SqlParameter("@DOB", SqlDbType.Date);
            sp[7].Value = EntR.DOB.ToShortDateString();
            sp[8] = new SqlParameter("@SsnType", SqlDbType.VarChar, 30);
            sp[8].Value = EntR.SecurityQuestion;
            sp[9] = new SqlParameter("@SsnValue", SqlDbType.VarChar, 50);
            sp[9].Value = EntR.SecurityAnswer;
            

            SqlParameter[] sp1 = new SqlParameter[4];
           
            sp1[0] = new SqlParameter("@id", SqlDbType.VarChar, 6);
            sp1[0].Value = newcustid;
            sp1[1] = new SqlParameter("@userName", SqlDbType.VarChar, 15);
            sp1[1].Value = EntR.UserName;
            sp1[2] = new SqlParameter("@passwordHash ", SqlDbType.VarChar, 40);
            sp1[2].Value = EntR.PasswordHash;
            sp1[3] = new SqlParameter("@salt ", SqlDbType.VarChar, 40);
            sp1[3].Value = EntR.Salt;

            

            DatR.StoreAccountDetails(sp,sp1);
            
        }



        public DataSet fetchSecurityQues()
        {
            return DatR.fetchSecurityQues();
        }

        public DataSet fetchSsnType()
        {
            return DatR.fetchSsnType();
        }
    }
}
