﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;

namespace ARS.Business
{
    public class BusSearch
    {
        DatSearch DatS = new DatSearch();
        public System.Data.DataSet fetchLocations()
        {
            return DatS.fetchLocations();
        }

        public System.Data.DataSet fetchClassType()
        {
            return DatS.fetchClassType();
        }
    }
}
