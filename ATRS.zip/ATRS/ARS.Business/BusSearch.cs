﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data;

namespace ARS.Business
{
    public class BusSearch
    {
        DatSearch DatS = new DatSearch();
        public DataSet fetchLocations()
        {
            return DatS.fetchLocations();
        }

        public DataSet fetchClassType()
        {
            return DatS.fetchClassType();
        }
    }
}
