﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusTransactions
    {
        DatTransactions DatT = new DatTransactions();


        public DataSet fetchInvoice(EntTransactions EntT)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            sp.Value = EntT.CustomerId;

            return DatT.fetchInvoice(sp);
        }

        public DataSet fetchReceipts(EntTransactions EntT)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            sp.Value = EntT.CustomerId;

            return DatT.fetchReceipts(sp);
        }
    }
}
