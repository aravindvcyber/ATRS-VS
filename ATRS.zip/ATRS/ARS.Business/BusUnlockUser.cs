﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data;
using System.Data.SqlClient;

namespace ARS.Business
{
    public class BusUnlockUser
    {

        DatUnlockUser DatUU = new DatUnlockUser();

        public DataSet fetchLockedUsers()
        {
            return DatUU.fetchLockedUsers();
        }

        public bool UnlockUser(EntUnlockUser EntUU)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@username", SqlDbType.VarChar, 15);
            sp.Value = EntUU.UserName;


            return DatUU.UnlockUser(sp);
        }
    }
}
