﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatAirlines
    {

        SqlConnection con = null;

        public DatAirlines()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public bool insertAirLines(SqlParameter[] sp)
        {
            bool res = false;
            SqlCommand com = new SqlCommand("insert_airlinedetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();

                if (rdr.Read())
                {

                    res = true;

                }
                else
                {

                    res = false;
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Inserting new Airlines. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return res;
        }
    }
}
