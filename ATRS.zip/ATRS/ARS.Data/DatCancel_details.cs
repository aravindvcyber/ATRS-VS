﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace ARS.Data
{
   public class DatCancel_details
    {
       SqlConnection con = null;

       public DatCancel_details()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

       public Dictionary<string, string> GetCanceldetails(SqlParameter sp)
       {
           Dictionary<string, string> candet = new Dictionary<string, string>();

           SqlCommand cmd = new SqlCommand("cancel_details", con);
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Parameters.Add(sp);
           try
           {
               con.Open();
               SqlDataReader rdr = cmd.ExecuteReader();

               while (rdr.Read())
               {
                   candet.Add("bid", rdr["bookingid"].ToString());
                   candet.Add("bdate", rdr["BookingDate"].ToString());
                   candet.Add("Aname", rdr["A_name"].ToString());
                   candet.Add("depdate", rdr["departuredate"].ToString());
                   candet.Add("flocation", rdr["fromlocation"].ToString());
                   candet.Add("tlocation", rdr["tolocation"].ToString());
                   candet.Add("classtype", rdr["ClassType"].ToString());
                   candet.Add("seats", rdr["Seats"].ToString());
                   candet.Add("amount", rdr["Amount"].ToString());
                   
                   
               }
           }
           catch (Exception ex)
           {

               throw new Exception("Exception Getting Cancel details. " + ex.Message);
           }
           finally
           {
               con.Close();
           }

          

           return candet;
       }

       public void cancelTickets(SqlParameter[] sp)
       {
           SqlCommand cmd = new SqlCommand("insert_canceldetails", con);
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Parameters.AddRange(sp);

           try
           {
               con.Open();
               cmd.ExecuteNonQuery();
           }
           catch (Exception ex)
           {
               // Code to check for primary key violation (duplicate account name)
               // or other database errors omitted for clarity
               throw new Exception("Exception in Cancelling Tickets. " + ex.Message);
           }
           finally
           {
               con.Close();
           }

       }

       public bool checkstatus(SqlParameter sp)
       {
           bool admin = false;
           SqlCommand com = new SqlCommand("checkstatusbid", con);
           com.CommandType = CommandType.StoredProcedure;
           com.Parameters.Add(sp);

           try
           {
               con.Open();
               SqlDataReader rdr = com.ExecuteReader();
               if (rdr.Read())
               {
                   admin = true;
               }
           }
           catch (Exception ex)
           {
               // Code to check for primary key violation (duplicate account name)
               // or other database errors omitted for clarity

               throw new Exception("Exception Checking cancellation status for booking id." + ex.Message);
           }
           finally
           {
               con.Close();
           }
           return admin;
       }

       public bool checkvalidbid(SqlParameter[] sp)
       {
           bool admin = true;
           SqlCommand com = new SqlCommand("check_bid", con);
           com.CommandType = CommandType.StoredProcedure;
           com.Parameters.AddRange(sp);

           try
           {
               con.Open();
               SqlDataReader rdr = com.ExecuteReader();
               if (rdr.Read())
               {
                   admin = false;
               }
           }
           catch (Exception ex)
           {
               // Code to check for primary key violation (duplicate account name)
               // or other database errors omitted for clarity

               throw new Exception("Exception Validating booking id." + ex.Message);
           }
           finally
           {
               con.Close();
           }
           return admin;
       }
    }

}
