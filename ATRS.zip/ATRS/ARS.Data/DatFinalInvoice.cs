﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatFinalInvoice
    {
        SqlConnection con = null;

        public DatFinalInvoice()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public SqlDataReader FetchFlightDetails(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("preinvoice_flightdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            SqlDataReader rdr;
            try
            {
                con.Open();
                rdr = com.ExecuteReader();
                rdr.Read();


            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Flight Details. " + ex.Message);
            }
            finally
            {

            }
            return rdr;
        }
    }
}
