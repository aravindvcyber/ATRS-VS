﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatLocations
    {
          SqlConnection con = null;

          public DatLocations()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

          public bool insertLocations(SqlParameter sp)
          {
              bool res = false;
              SqlCommand com = new SqlCommand("insert_locations", con);
              com.CommandType = CommandType.StoredProcedure;
              com.Parameters.Add(sp);
              try
              {
                  con.Open();
                  SqlDataReader rdr = com.ExecuteReader();

                  if (rdr.Read())
                  {

                      res = true;

                  }
                  else
                  {

                      res = false;
                  }
              }
              catch (Exception ex)
              {
                  // Code to check for primary key violation (duplicate account name)
                  // or other database errors omitted for clarity
                  throw new Exception("Exception Inserting new Locations. " + ex.Message);
              }
              finally
              {
                  con.Close();
              }
              return res;
          }
    }
}
