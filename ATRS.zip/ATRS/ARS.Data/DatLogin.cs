﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatLogin
    {
        SqlConnection con = null;

        public DatLogin()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public bool checkAdmin(SqlParameter[] sp)
        {
            bool admin = false;
            SqlCommand com = new SqlCommand("checkAdmin", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);

            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();
                if (rdr.Read())
                {
                    admin = Convert.ToBoolean(rdr["isadmin"].ToString());
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity

                throw new Exception("Exception Checking Admin." + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return admin;
        }

        public string getSalt(SqlParameter[] sp)
        {
            string salt = "";
            SqlCommand com = new SqlCommand("getsalt", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);

            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();
                if (rdr.Read())
                {
                    salt = rdr["salt"].ToString();
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity

                throw new Exception("Exception getting Salt." + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return salt;
        }
        public Dictionary<string, string> generatesessionvariables(SqlParameter sp)
        {
            //string username = sp[0].Value.ToString();
            Dictionary<string, string> sessionvariables = new Dictionary<string, string>();
            SqlCommand com = new SqlCommand("sessionvariables", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);

            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();
                if (rdr.Read())
                {
                    sessionvariables.Add("uname", rdr["UserName"].ToString());
                    sessionvariables.Add("cid", rdr["customerid"].ToString());
                    sessionvariables.Add("fname", rdr["firstname"].ToString());
                    sessionvariables.Add("lname", rdr["lastname"].ToString());
                    sessionvariables.Add("wallet", rdr["wallet"].ToString());
                    sessionvariables.Add("isadmin", rdr["isadmin"].ToString());

                }
            }
            catch (Exception ex)
            {


                throw new Exception("Exception generating Session Variables." + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return sessionvariables;
        }


        public Dictionary<string, string> AuthenticateAdmin(SqlParameter[] sp)
        {
            Dictionary<string, string> AuthAdmin = new Dictionary<string, string>();
            string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;

            using (SqlConnection con = new SqlConnection(CS))
            {

                SqlCommand cmd = new SqlCommand("spAuthenticateUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(sp);

                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    int RetryAttempts = Convert.ToInt32(rdr["RetryAttempts"]);
                    if (Convert.ToBoolean(rdr["AccountLocked"]))
                    {
                        AuthAdmin.Add("Msg", "Account locked. Please contact administrator");
                        AuthAdmin.Add("Authenticated", rdr["Authenticated"].ToString());
                    }
                    else if (RetryAttempts > 0)
                    {
                        int AttemptsLeft = (4 - RetryAttempts);
                        AuthAdmin.Add("Msg", "Invalid user name and/or password. " + AttemptsLeft.ToString() + "attempt(s) left");
                        AuthAdmin.Add("Authenticated", rdr["Authenticated"].ToString());
                    }
                    else
                        if (Convert.ToBoolean(rdr["Authenticated"]))
                        {
                            //Session["uname"] = UserName.Value;
                            AuthAdmin.Add("Authenticated", rdr["Authenticated"].ToString());

                        }
                    //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
                }
                con.Close();
            }
            return AuthAdmin;
        }


        public Dictionary<string, string> AuthenticateUser(SqlParameter[] sp)
        {
            Dictionary<string, string> AuthUser = new Dictionary<string, string>();
            string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;

            using (SqlConnection con = new SqlConnection(CS))
            {

                SqlCommand cmd = new SqlCommand("spAuthenticateUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(sp);

                con.Open();

                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    int RetryAttempts = Convert.ToInt32(rdr["RetryAttempts"]);
                    if (Convert.ToBoolean(rdr["AccountLocked"]))
                    {
                        AuthUser.Add("Msg", "Account locked. Please contact administrator");
                        AuthUser.Add("Authenticated", rdr["Authenticated"].ToString());
                    }
                    else if (RetryAttempts > 0)
                    {
                        int AttemptsLeft = (4 - RetryAttempts);
                        AuthUser.Add("Msg", "Invalid user name and/or password. " + AttemptsLeft.ToString() + "attempt(s) left");
                        AuthUser.Add("Authenticated", rdr["Authenticated"].ToString());
                    }
                    else
                        if (Convert.ToBoolean(rdr["Authenticated"]))
                        {
                            //Session["uname"] = UserName.Value;
                            AuthUser.Add("Authenticated", rdr["Authenticated"].ToString());

                        }
                    //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
                }
                con.Close();
            }
            return AuthUser;
        }
    }
}
