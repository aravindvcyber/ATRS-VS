﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ARS.Data
{
    public class DatMasterPage
    {
        SqlConnection con = null;

        public DatMasterPage()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
      
        public DataSet getWallet(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("getwallet", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "wallet");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Wallet. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
