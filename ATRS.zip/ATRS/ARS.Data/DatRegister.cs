﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ARS.Data
{
    public class DatRegister
    {
        SqlConnection con = null;

        public DatRegister()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public void StoreAccountDetails(SqlParameter[] sp, SqlParameter[] sp1)
        {
           
            SqlCommand com = new SqlCommand("RegisterUserDetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception inserting into Customer Details. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            com = new SqlCommand("RegisterUser", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp1);

            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception inserting into Logins Table. " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }
        public string getnewcustid()
        {
        string custid = "";
        string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
           
            SqlCommand cmd = new SqlCommand("gen_customerid", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                if (rdr.Read())
                {
                    custid = rdr["customerid"].ToString();
                }

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception generating new customerid. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            
        }
        return custid;
        }



        public DataSet fetchSecurityQues()
        {
            SqlCommand com = new SqlCommand("getsecutiyques", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "SecurityQuestions");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Security Questions. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
