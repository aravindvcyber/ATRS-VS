﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatSearchResults
    {
        SqlConnection con = null;

        public DatSearchResults()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
        public SqlDataReader getSearchResults(SqlParameter[] sp)
        {
           
            SqlCommand com = new SqlCommand("search_flights", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            SqlDataReader rdr;
            try
            {
                con.Open();
                rdr = com.ExecuteReader();

              
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting search results. " + ex.Message);
            }
            finally
            {
                
            }
            return rdr;


        }

    }
}
