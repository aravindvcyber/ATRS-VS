﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace ARS.Data
{
    public class DatTopUp
    {
         SqlConnection con = null;

         public DatTopUp()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
        public DataSet fetchUsers()
        {
            SqlCommand com = new SqlCommand("getusernames", con);
            com.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "username");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting UserNames. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public bool TopUpWallet(SqlParameter[] sp)
        {
            bool res = false;
            SqlCommand com = new SqlCommand("topupwallet", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();

                if (rdr.Read())
                {

                    res = true;

                }
                else
                {

                    res = false;
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Topping Up UserName. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return res;
        }
    }
}
