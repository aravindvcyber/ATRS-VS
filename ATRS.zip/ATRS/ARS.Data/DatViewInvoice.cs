﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatViewInvoice
    {
        SqlConnection con = null;

        public DatViewInvoice()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }

        public SqlDataReader fetchBookingDetails(SqlParameter sp)
        {
            SqlCommand com = new SqlCommand("invoice_bookingdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            SqlDataReader rdr;
            try
            {
                con.Open();
                rdr = com.ExecuteReader();
                rdr.Read();


            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Booking Details. " + ex.Message);
            }
            finally
            {

            }
            return rdr;
        }

        public SqlDataReader fetchCancelDetails(SqlParameter sp)
        {
           
            SqlCommand com = new SqlCommand("cancelstatus", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            SqlDataReader rdr;
            try
            {
            
                rdr = com.ExecuteReader();
                //rdr.Read();


            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting cancel status Details. " + ex.Message);
            }
            finally
            {

            }
            return rdr;
        }

        public SqlDataReader fetchTicketDetailss(SqlParameter sp)
        {
       
            SqlCommand com = new SqlCommand("invoice_ticketdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            SqlDataReader rdr;
            try
            {
               
                rdr = com.ExecuteReader();
                //rdr.Read();


            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting ticket details Details. " + ex.Message);
            }
            finally
            {

            }
            return rdr;
        }
        
    }
}
