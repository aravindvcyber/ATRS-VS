﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace ARS.Data
{
    public class datchecknewuser
    {
        SqlConnection con = null;

        public datchecknewuser()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
        
        //public List<string> inserdalemp(SqlParameter[] sp)
        //{


        //    List<string> l = new List<string>();

        //    con.Open();
        //    SqlCommand com = new SqlCommand("insertemp", con);
        //    com.CommandType = CommandType.StoredProcedure;

        //    com.Parameters.AddRange(sp);

        //    SqlDataReader dr = com.ExecuteReader();
        //    while (dr.Read())
        //    {
        //        l.Add(dr[0].ToString());
        //        l.Add(dr[1].ToString());
        //    }
        //    return l;
        //}
    }
}
