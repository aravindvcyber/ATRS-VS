﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntAirlines
    {
        private string airlinename;

        public string AirlineName
        {
            get { return airlinename; }
            set { airlinename = value; }
        }

        private DateTime dop;

        public DateTime DOP
        {
            get { return dop; }
            set { dop = value; }
        }

        private string logo;

        public string Logo
        {
            get { return logo; }
            set { logo = value; }
        }
        


    }
}
