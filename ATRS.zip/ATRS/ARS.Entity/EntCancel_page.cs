﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntCancel_page
    {
        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }

        private string bookingid;

        public string BookingId
        {
            get { return bookingid; }
            set { bookingid = value; }
        }
        
    }
}
