﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
   public class EntChangePwd
    {
       private string username;
        public string UserName
        {
            get { return username; }
            set { username = value; }
        }
        private string salt;

        public string Salt
        {
            get { return salt; }
            set { salt = value; }
        }

        private string passwordhash;

        public string PasswordHash
        {
            get { return passwordhash; }
            set { passwordhash = value; }
        }
        
    }
}
