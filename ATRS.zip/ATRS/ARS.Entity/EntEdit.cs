﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntEdit
    {
        private string customername;
        public string CustomerName
        {
            get { return customername; }
            set { customername = value; }
        }
        private string emailid;

        public string EmailId
        {
            get { return emailid; }
            set { emailid = value; }
        }
        private string securityquestion;

        public string SecurityQuestion
        {
            get { return securityquestion; }
            set { securityquestion = value; }
        }
        private string mobile;

        public string Mobile
        {
            get { return mobile; }
            set { mobile = value; }
        }
        private string securityanswer;

        public string SecurityAnswer
        {
            get { return securityanswer; }
            set { securityanswer = value; }
        }
        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        private DateTime dob;

        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }
    }
}
