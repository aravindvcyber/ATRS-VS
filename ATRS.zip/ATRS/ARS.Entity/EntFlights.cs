﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntFlights
    {
        private string airlineid;

        public string AirlineId
        {
            get { return airlineid; }
            set { airlineid = value; }
        }
        private int iseats;

        public int ISeats
        {
            get { return iseats; }
            set { iseats = value; }
        }

        private int iprice;

        public int IPrice
        {
            get { return iprice; }
            set { iprice = value; }
        }

        private int iiseats;

        public int IISeats
        {
            get { return iiseats; }
            set { iiseats = value; }
        }
        private int iiprice;

        public int IIPrice
        {
            get { return iiprice; }
            set { iiprice = value; }
        }
        private int iiiseats;

        public int IIISeats
        {
            get { return iiiseats; }
            set { iiiseats = value; }
        }

        private int iiiprice;

        public int IIIPrice
        {
            get { return iiiprice; }
            set { iiiprice = value; }
        }
        



    }
}
