﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
   public class EntMasterPage
    {
        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        


    }
}
