﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntSchedules
    {
        private string flightid;

        public string FlightId
        {
            get { return flightid; }
            set { flightid = value; }
        }


        private string from;

        public string From
        {
            get { return from; }
            set { from = value; }
        }

        private string to;

        public string To
        {
            get { return to; }
            set { to = value; }
        }

        private DateTime departuredate;

        public DateTime DepartureDate
        {
            get { return departuredate; }
            set { departuredate = value; }
        }

        private TimeSpan arrivaltime;

        public TimeSpan ArrivalTime
        {
            get { return arrivaltime; }
            set { arrivaltime = value; }
        }


        private TimeSpan departuretime;

        public TimeSpan DepartureTime
        {
            get { return departuretime; }
            set { departuretime = value; }
        }


        private TimeSpan duration;

        public TimeSpan Duration
        {
            get { return duration; }
            set { duration = value; }
        }
        
        
        


    }
}
