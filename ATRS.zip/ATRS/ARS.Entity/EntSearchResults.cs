﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntSearchResults
    {

        private string from;

        public string From
        {
            get { return from; }
            set { from = value; }
        }

        private string to;

        public string To
        {
            get { return to; }
            set { to = value; }
        }


        private DateTime departuredate;

        public DateTime DepartureDate
        {
            get { return departuredate; }
            set { departuredate = value; }
        }
        private int classtype;

        public int ClassType
        {
            get { return classtype; }
            set { classtype = value; }
        }
        private int seats;

        public int Seats
        {
            get { return seats; }
            set { seats = value; }
        }

        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        


    }
}
