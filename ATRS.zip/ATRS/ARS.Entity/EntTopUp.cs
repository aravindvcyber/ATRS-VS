﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntTopUp
    {

        private string username;

        public string UserName
        {
            get { return username; }
            set { username = value; }
        }


        private int amount;

        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        

    }
}
