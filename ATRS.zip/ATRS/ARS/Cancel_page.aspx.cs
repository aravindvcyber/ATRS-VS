﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Cancellation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            string custid = Session["cid"].ToString();
            //custid = Request.Cookies["customerid"].Value;
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select BookingId from Booking";
            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlCommand storedProcCommand = new SqlCommand("getbookingids", myConnection);
            storedProcCommand.CommandType = CommandType.StoredProcedure;
            //storedProcCommand.Parameters.Add("@customerid", Request.Cookies["customerid"].Value);
            SqlParameter parameter = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
            //Set the parameter direction as output
            //parameter.Direction = ParameterDirection.Output;
            storedProcCommand.Parameters.Add(parameter);
            parameter.Value = custid;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(storedProcCommand);
            DataSet ds = new DataSet();
            sqlAdapter.Fill(ds, "BookingId");
            //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select BookingId from Booking";

            //SqlConnection myConnection = new SqlConnection(ConnectString);
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            //DataSet ds = new DataSet();
            //myCommand.Fill(ds, "BookingId");

            BookingId.DataSource = ds;
            BookingId.DataTextField = "BookingId";
            BookingId.DataValueField = "BookingId";
            BookingId.DataBind();

        }
    }
    protected void submit(object sender, EventArgs e)
    {
        Response.Redirect("cancel_details.aspx");
    }
}