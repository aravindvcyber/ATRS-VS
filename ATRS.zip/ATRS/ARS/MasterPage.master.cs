﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using LoggingSample;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //{get data from database by passing userid}
            ////to check if it logs the error throw an argument exception
            //throw new ArgumentException("generated error");
            //on success Log the activity
            Logging.LogInfo("Get successful for userid : "+ Request.Cookies["uname"].Value, true);
          
        
        }
        catch (Exception ex)
        {
            //on error log the exception
            Logging.LogException(ex, "Error in data bind");
        }

    }
    protected void logout_Click(object sender, EventArgs e)
    {
        //Session.RemoveAll;
       
        Response.Redirect("home.aspx");
    }
}
