﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class newusername : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtUsername_TextChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(txtUsername.Text) && RegularExpressionValidator3=true)
        {
            SqlConnection con = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Login where UserName=@Name", con);
            cmd.Parameters.AddWithValue("@Name", txtUsername.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                checkusername.Visible = true;
                imgstatus.ImageUrl = "img/cross.jpeg";
                lblStatus.Text = "UserName Already Taken";
                System.Threading.Thread.Sleep(2000);
            }
            else
            {
                checkusername.Visible = true;
                imgstatus.ImageUrl = "img/check.png";
                lblStatus.Text = "UserName Available";
               
                System.Threading.Thread.Sleep(2000);
            }
        }
        else
        {
            checkusername.Visible = false;
        }
    }
}