﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class search_results : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String From = Request.Cookies["From"].Value;
        String To = Request.Cookies["To"].Value;
        DateTime DOJ = Convert.ToDateTime(Request.Cookies["DOJ"].Value);
        String Class = Request.Cookies["class"].Value;
        String seats = Request.Cookies["seats"].Value;


        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

       // string newcustid = getnewcustid();


        conn.Open();


        SqlCommand cmd = new SqlCommand("search_flights", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@FromLocation", SqlDbType.VarChar, 30);
        sqlParam.Value = From;

        sqlParam = cmd.Parameters.Add("@ToLocation", SqlDbType.VarChar, 30);
        sqlParam.Value = To;

        sqlParam = cmd.Parameters.Add("@DepartureDate", SqlDbType.Date);
        sqlParam.Value = DOJ;

        sqlParam = cmd.Parameters.Add("@NumberOfSeats", SqlDbType.Int);
        sqlParam.Value = seats;

        sqlParam = cmd.Parameters.Add("@ClassId", SqlDbType.Int);
        sqlParam.Value = Class;

        GridView1.DataSource=  cmd.ExecuteReader();
        GridView1.DataBind();
        conn.Close();
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Search.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    { 
        Response.Cookies["scheduleid"].Value=GridView1.SelectedRow.Cells[10].Text.ToString();
        Response.Cookies["price"].Value=GridView1.SelectedRow.Cells[9].Text.ToString();

        Response.Redirect("preinvoice.aspx");
    }
}