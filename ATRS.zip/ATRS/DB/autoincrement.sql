create procedure insertintocus(@name varchar(10))
as 
begin
declare @id int,@cid varchar(5)
set @id=(select MAX(cast(substring(id,3,3) as int)) from Test)
if(@id=null)
set @id=1;
else
set @id=@id+1
set @cid='C_'
declare @i varchar(3)
set @i=CAST(@id as varchar(3))
set @cid=@cid+'00'+@i
print @cid
insert into Test(Id,Cname) values(@cid,@name)
end
