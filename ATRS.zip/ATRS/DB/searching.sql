CREATE procedure search_flights (
@FromLocation varchar(30),
@ToLocation varchar(30),
@DepartureDate date,
@NumberOfSeats int,
@ClassId int
)
as
begin
if(@ClassId=1)
begin
select s.FlightId,s.DepartureTime,s.ArrivalTime,s.FromLocation,s.ToLocation
from dbo.Schedules s join dbo.Seats_Available se
on s.Id=se.ScheduleId
where FromLOcation=@FromLocation 
and ToLocation=@ToLocation
and DepartureDate=@DepartureDate
and IClass>=@NumberOfSeats
end
else if(@ClassId=2)
begin
select s.FlightId,s.DepartureTime,s.ArrivalTime,s.FromLocation,s.ToLocation
from dbo.Schedules s join dbo.Seats_Available se
on s.Id=se.ScheduleId
where FromLOcation=@FromLocation 
and ToLocation=@ToLocation
and DepartureDate=@DepartureDate
and IIClass>=@NumberOfSeats
end
else if(@ClassId=3)
begin
select s.FlightId,s.DepartureTime,s.ArrivalTime,s.FromLocation,s.ToLocation
from dbo.Schedules s join dbo.Seats_Available se
on s.Id=se.ScheduleId
where FromLOcation=@FromLocation 
and ToLocation=@ToLocation
and DepartureDate=@DepartureDate
and IIIClass>=@NumberOfSeats
end

end


exec search_flights 'Ahmedabad','Chennai','2016-07-23',10,1

alter procedure calculate_price 
(@final_price int output ,
@from_location_id int,
@to_location_id int ,
@class_id int,@flight_id  varchar(40) )
as
begin

if(@class_id =1)
begin
select @final_price= IClassPrice+(abs(@from_location_id-@to_location_id)*400)

from Flight_Master where FlightId=@flight_id;

end

else if(@class_id=2)
begin
select @final_price= IIClassPrice+(abs(@from_location_id-@to_location_id)*350)

from Flight_Master where FlightId=@flight_id;

end

else if(@class_id=3)
begin
select @final_price= IIIClassPrice+(abs(@from_location_id-@to_location_id)*300)

from Flight_Master where FlightId=@flight_id;

end



end



declare @final_price  int 

exec calculate_price @final_price output,4,2,1,'IND011'

print @final_price



create procedure get_location(@location_name varchar(30))
as
begin
select Location_id from Location_Master where Location_Name=@location_name
end

create procedure get_ssnId(@ssntype varchar(30))
as
begin
select SSNId from SSN_Master where SSN_Master.SSN_Type=@ssntype
end


create procedure get_classId(@Class_type varchar(30))
as
begin
select Class_Master.ClassId from Class_Master where ClassType=@Class_type
end

create procedure get_securityId(@Security varchar(30))
as
begin
select Security.SecurityId from Security where Security.SecurityQuestions=@Security
end


create procedure check_uname_available(@useername varchar(30))

as

begin

select COUNT(*) from Login where UserName=@useername

end


Create table tblUsers
(
 [Id] int identity primary key,
 [UserName] nvarchar(100),
 [Password] nvarchar(200),
 [Email] nvarchar(100),
 [RetryAttempts] int,
 [IsLocked] bit,
 [LockedDateTime] datetime
) 


Create table Logins
(
 CustomerId varchar(6) primary key,
 UserName varchar(15),
 password nvarchar(200),
 salt nvarchar(100),
 RetryAttempts int,
 IsLocked bit,
 LockedDateTime datetime
) 

Alter proc spRegisterUser  
@UserName varchar(15),  
@Password nvarchar (200))  
as  
Begin  
 Declare @Count int  
 Declare @ReturnCode int  
   
 Select @Count = COUNT(UserName)   
 from tblUsers where UserName = @UserName  
 If @Count > 0  
 Begin  
  Set @ReturnCode = -1  
 End  
 Else  
 Begin  
  Set @ReturnCode = 1  
  --Change: Column list specified while inserting
  Insert into Logins(UserName, Password) 
  values  (@UserName, @Password)  
 End  
 Select @ReturnCode as ReturnValue  
End  

Alter proc spAuthenticateUser
@UserName nvarchar(100),
@Password nvarchar(200)
as
Begin
 Declare @AccountLocked bit
 Declare @Count int
 Declare @RetryCount int

 Select @AccountLocked = IsLocked
 from tblUsers where UserName = @UserName
  
 --If the account is already locked
 if(@AccountLocked = 1)
 Begin
  Select 1 as AccountLocked, 0 as Authenticated, 0 as RetryAttempts
 End
 Else
 Begin
  -- Check if the username and password match
  Select @Count = COUNT(UserName) from tblUsers
  where [UserName] = @UserName and [Password] = @Password
  
  -- If match found
  if(@Count = 1)
  Begin
   -- Reset RetryAttempts 
   Update tblUsers set RetryAttempts = 0
   where UserName = @UserName
       
   Select 0 as AccountLocked, 1 as Authenticated, 0 as RetryAttempts
  End
  Else
  Begin
   -- If a match is not found
   Select @RetryCount = IsNULL(RetryAttempts, 0)
   from tblUsers
   where UserName = @UserName
   
   Set @RetryCount = @RetryCount + 1
   
   if(@RetryCount <= 3)
   Begin
    -- If re-try attempts are not completed
    Update tblUsers set RetryAttempts = @RetryCount
    where UserName = @UserName 
    
    Select 0 as AccountLocked, 0 as Authenticated, @RetryCount as RetryAttempts
   End
   Else
   Begin
    -- If re-try attempts are completed
    Update tblUsers set RetryAttempts = @RetryCount,
    IsLocked = 1, LockedDateTime = GETDATE()
    where UserName = @UserName

    Select 1 as AccountLocked, 0 as Authenticated, 0 as RetryAttempts
   End
  End
 End
End



-- create stored procedure to register user details
Alter PROCEDURE RegisterUser
(

@userName varchar(15),
@passwordHash varchar(128),
@salt varchar(128)
)
AS
begin
declare @CustomerId varchar(6)
@CustomerId='ARS101'
INSERT INTO ATRS.Logi(,UserName,password,salt)VALUES(@CustomerId,@userName, @passwordHash, @salt)
end
GO




exec RegisterUser 'fsdfds','gdfgdf','gdfgd'
-- create stored procedure to retrieve user details
CREATE PROCEDURE LookupUser
@userName varchar(20)
AS
SELECT PasswordHash 
FROM Users
WHERE UserName = @userName
GO