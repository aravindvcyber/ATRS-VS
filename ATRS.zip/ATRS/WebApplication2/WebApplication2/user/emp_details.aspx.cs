﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using buslogiclayer;
using entitylayer;

namespace WebApplication2.user
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        busempdetails objbsu = new busempdetails();
        emp objent = new emp();
      
        protected void Page_Load(object sender, EventArgs e)
        {
         

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                objent.id = Convert.ToInt32(TextBox1.Text);
                objent.name = TextBox2.Text;

                int res = objbsu.insert_emp(objent);

                if (res > 0)
                {
                }

                else
                {
                }
            }
            catch (Exception Ex)
            {

            }


           
        }
    }
}