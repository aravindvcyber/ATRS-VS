﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using entitylayer;
using System.Data.SqlClient;
using System.Data;
using dal;

namespace buslogiclayer
{
    public class busempdetails
    {

      //  emp objemp= new emp();
        dalempdetails dalobj = new dalempdetails();
     

        public int insert_emp(emp obj)
        {
            SqlParameter[] sp = new SqlParameter[2];
            sp[0] = new SqlParameter("@id",System.Data.SqlDbType.Int ,20);
            sp[0].Value=obj.id;
            sp[1] = new SqlParameter("@name", System.Data.SqlDbType.VarChar, 20);
            sp[1].Direction = ParameterDirection.Output;
            obj.name = sp[1].Value.ToString();

       int res=     dalobj.inserdalemp(sp);
       return res;


        }
    }
}
