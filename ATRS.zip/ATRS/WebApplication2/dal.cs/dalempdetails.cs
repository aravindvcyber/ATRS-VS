﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace dal
{
    public class dalempdetails
    {
        SqlConnection con = null;

        public dalempdetails()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["conn"].ConnectionString);
        }


        public  List<string> inserdalemp (SqlParameter[] sp)
        {


            List<string> l = new List<string>();
            
            con.Open();
            SqlCommand com = new SqlCommand("insertemp", con);
            com.CommandType = CommandType.StoredProcedure;

            com.Parameters.AddRange(sp);

         SqlDataReader dr=   com.ExecuteReader();
         while (dr.Read())
         {
             l.Add(dr[0].ToString());
             l.Add(dr[1].ToString());
         }
         return l;
        }
    }
}
