﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.Xml.Xsl;
using System.Xml;

public partial class Activity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "Activity Logger";
        ((Admin)this.Master).Headmsg = "Successfull!";
        if (!Page.IsPostBack)
        {
            if (Request.QueryString.Count == 0)
            {
                dvActivityReport.InnerHtml = ApplyXSLTransformation();
                transf.Visible = false;
            }
            else
            {
                
                dvActivityReport.InnerHtml = ApplyXSLTransformation(Request.QueryString["fid"]);
                transf.Visible = true;
                ((Admin)this.Master).SMSmsg = "Click the Link to view the generated xml file with transformation :";
                ((Admin)this.Master).Headmsg = "Successfully opened!";
                xml.NavigateUrl = generateXML(Request.QueryString["fid"]);

               
            }
        }
    }
    protected string generateXML(string fid)
    {
        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_App");

        string File = path + "\\" + fid;


        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Activities>");

        StreamReader strmReader = new StreamReader(File);
        sbLogFiles.Append(strmReader.ReadToEnd());
        strmReader.Close();

        sbLogFiles.Append("</Activities>");
        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Activity")
                             //orderby a.Element("SessionID").Value ascending
                             //orderby Convert.ToDateTime(a.Element("DateTime").Value) descending
                             select a);

        XElement objFinalXML = new XElement("Activities", objOrderedXml);


        // Create the XmlDocument.
        XmlDocument doc = new XmlDocument();


        doc.LoadXml(objFinalXML.ToString());


        //Create an XML declaration. 
        XmlDeclaration xmldecl;
        xmldecl = doc.CreateXmlDeclaration("1.0", null, null);
        xmldecl.Encoding = "UTF-8";
        xmldecl.Standalone = "yes";

        //Add the new node to the document.
        XmlElement root = doc.DocumentElement;
        doc.InsertBefore(xmldecl, root);

        //// Add a price element.
        //XmlElement newElem = doc.CreateElement("price");
        //newElem.InnerText = "10.95";
        //doc.DocumentElement.AppendChild(newElem);

        // Save the document to a file. White space is
        // preserved (no white space).
        doc.PreserveWhitespace = true;
        string xfid = fid.Replace(".txt", ".xml");
        doc.Save(path + "\\xml\\" + xfid);


        //Build your target to navigate to (using String.Format())
        string url = String.Format("XmlTransform.aspx?type=App&fid=" + xfid, false);

        ////Build your client-side script that will open your target in a new page
        //string script = String.Format("window.open('{0}','_blank');", url);

        ////Combine these two together so that when your page is loaded it will open your target URL in a new window
        //ClientScript.RegisterStartupScript(GetType(), "YourStartupScript", script, true);




        //string url = HttpContext.Current.Server.MapPath("XmlTransform.aspx") + "?type=App&fid=" + xfid;
        //StringBuilder sb = new StringBuilder();
        //sb.Append("<script type = 'text/javascript'>");
        //sb.Append("window.open('");
        //sb.Append(url);
        //sb.Append("');");
        //sb.Append("</script>");
        //ClientScript.RegisterStartupScript(this.GetType(),
        //        "script", sb.ToString());

        //Response.Write("<script>");
        //Response.Write("window.open('" + xml + "','_blank')");
        //Response.Write("</script>");

        //Server.Transfer(url);

        //((MasterPage)this.Master.Master).displayMessage("<p style='color:navy;'>Session Terminated</p> Due to your Action<br/>");

        //Response.Redirect(url, false);
        return url;

    }
    private string ApplyXSLTransformation(string fid)
    {
        string strHtml;


        string strXstFile = Server.MapPath("Styles/ActivityLog.xslt");
        XslCompiledTransform x = new XslCompiledTransform();

        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_App");

        string File = path + "\\" + fid;

      
        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Activities>");
       
            StreamReader strmReader = new StreamReader(File);
            sbLogFiles.Append(strmReader.ReadToEnd());
            strmReader.Close();

        sbLogFiles.Append("</Activities>");
        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Activity")
                             
                             select a);

        XElement objFinalXML = new XElement("Activities", objOrderedXml);

        XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
        XPathDocument doc = new XPathDocument(objXmlReader);

        // Load the style sheet.
        XslCompiledTransform xslt = new XslCompiledTransform();
        xslt.Load(strXstFile);
        MemoryStream ms = new MemoryStream();
        XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
        StreamReader rd = new StreamReader(ms);
        xslt.Transform(doc, writer);
        ms.Position = 0;
        strHtml = rd.ReadToEnd();
        rd.Close();
        ms.Close();
        return strHtml;
    }
    private string ApplyXSLTransformation()
        {
            string strHtml;
           

            string strXstFile = Server.MapPath("Styles/ActivityLog.xslt");
            XslCompiledTransform x = new XslCompiledTransform();

            // Load the XML 
            string path = HttpContext.Current.Server.MapPath("Logs_App");
            string[] strFiles = Directory.GetFiles(path);
            StringBuilder sbLogFiles = new StringBuilder();
            sbLogFiles.Append("<Activities>");
            for (int i = 0; i < strFiles.Length; i++)
            {
                StreamReader strmReader = new StreamReader(strFiles[i]);
                sbLogFiles.Append(strmReader.ReadToEnd());
                strmReader.Close();
            }
            sbLogFiles.Append("</Activities>");
            XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

            var objOrderedXml = (from a in objXmlLog.Elements("Activity")
                                
                                 select a);

            XElement objFinalXML = new XElement("Activities", objOrderedXml);

            XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
            XPathDocument doc = new XPathDocument(objXmlReader);

            // Load the style sheet.
            XslCompiledTransform xslt = new XslCompiledTransform();
            xslt.Load(strXstFile);
            MemoryStream ms = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
            StreamReader rd = new StreamReader(ms);
            xslt.Transform(doc, writer);
            ms.Position = 0;
            strHtml = rd.ReadToEnd();
            rd.Close();
            ms.Close();
            return strHtml;
        }

    protected void Button1_Click(object sender, EventArgs e)
    {
        transf.Visible = false;
        generateXML(Request.QueryString["fid"]);
    }
}