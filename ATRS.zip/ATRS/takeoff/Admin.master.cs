﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        sms.Text ="fdfdf" ;
        sms.Text = Sms;
       
        if (Session["uname"] == null)
        {
            //ClientScriptManager cs = Page.ClientScript;
            //string message = "You need to Login\n to access this page";
            //string url = "login.aspx";
            //string script = "window.onload = function(){ alert('";
            //script += message;
            //script += "');";
            //script += "window.location = '";
            //script += url;
            //script += "'; }";
            //cs.RegisterStartupScript(this.GetType(), "Redirect", script, true);
           
        }
        else
        {
            if (Session["isadmin"].ToString() != "True")
                Response.Redirect("user.aspx");

        }

    }
    protected void Page_Prerender(object sender, EventArgs e)
    {
     

    }
    public void ChangeSms(string label)
    {
        sms.Text = label;
    }
    public string Sms
    {
        set
        {
            sms.Text = value;
        }
        get
        {
            return sms.ToString();
        }

    }
}
