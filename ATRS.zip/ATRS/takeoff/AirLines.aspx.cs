﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
public partial class AirLines : System.Web.UI.Page
{
    EntAirlines EntA = new EntAirlines();
    BusAirlines BusA = new BusAirlines();


    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "New Airlines inserter";
        ((Admin)this.Master).Headmsg = "Successfully opened!";
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }

    protected void insert_Click(object sender, EventArgs e)
    { try
        {

        EntA.AirlineName = airline_name.Value;
        EntA.DOP=Convert.ToDateTime(this.Request.Form.Get("dop"));
        if (BusA.insertAirlines(EntA))
        {
            ((Admin)this.Master).SMSmsg = "AirLine " + airline_name.Value + " added...";
            ((Admin)this.Master).Headmsg = "Successfull!";
        }
        else
        {
        }

        //SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        //SqlCommand cmd = new SqlCommand("insert_airlinedetails", conn);
        //cmd.CommandType = CommandType.StoredProcedure;
        //SqlParameter sqlParam = null;
        //sqlParam = cmd.Parameters.Add("@airlinename", SqlDbType.VarChar, 20);
        //sqlParam.Value =airline_name.Value;
        //sqlParam = cmd.Parameters.Add("@dop", SqlDbType.Date);
        //sqlParam.Value = Convert.ToDateTime(this.Request.Form.Get("dop")) ;
        //try
        //{
            //conn.Open();
            //cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception  inserting new airline. " + ex.Message);
        }
        finally
        {
            //conn.Close();
        }
       
        Response.Redirect("admin.aspx");
    }
}