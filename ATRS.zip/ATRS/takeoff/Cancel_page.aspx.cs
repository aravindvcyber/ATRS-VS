﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class Cancellation : System.Web.UI.Page
{
    EntCancel_page EntCP = new EntCancel_page();
    BusCancel_page BusCP = new BusCancel_page();
    protected void Page_Load(object sender, EventArgs e)
    {
        ((User)this.Master).SMSmsg = "Cancellation Module - To cancel your tickets";
        ((User)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {

            string custid = Session["cid"].ToString();
            EntCP.CustomerId = Session["cid"].ToString();
            List<string> bid = BusCP.GetBookingDetails(EntCP);
            BookingId.DataSource = bid;
            BookingId.DataBind();



            //string custid = Session["cid"].ToString();
        
            //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        
            //SqlConnection myConnection = new SqlConnection(ConnectString);
            //SqlCommand storedProcCommand = new SqlCommand("bookingid_list", myConnection);
            //storedProcCommand.CommandType = CommandType.StoredProcedure;
   
            //SqlParameter parameter = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
     
    
            //storedProcCommand.Parameters.Add(parameter);
            //parameter.Value = custid;
            //SqlDataAdapter sqlAdapter = new SqlDataAdapter(storedProcCommand);
            //DataSet ds = new DataSet();
            //sqlAdapter.Fill(ds, "BookingId");
           

            //BookingId.DataSource = ds;
            //BookingId.DataTextField = "BookingId";
            //BookingId.DataValueField = "BookingId";
            //BookingId.DataBind();

        }
    }
    protected void submit(object sender, EventArgs e)
    {
        Response.Cookies["bookingid"].Value = BookingId.Value;
        Response.Redirect("cancel_details.aspx");
    }
}