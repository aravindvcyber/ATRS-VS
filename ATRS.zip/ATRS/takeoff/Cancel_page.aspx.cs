﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
using AjaxControlToolkit;



public partial class Cancellation : System.Web.UI.Page
{
    EntCancel_page EntCP = new EntCancel_page();
    BusCancel_page BusCP = new BusCancel_page();
    protected void Page_Load(object sender, EventArgs e)
    {
        ((User)this.Master).SMSmsg = "Cancellation Module - To cancel your tickets";
        ((User)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {
            if (Session["uname"] == null)
            {

                Response.Redirect("login.aspx");

            }
            else
            {
                string custid = Session["cid"].ToString();
                EntCP.CustomerId = Session["cid"].ToString();
                List<string> bid = BusCP.GetBookingDetails(EntCP);
                if (bid.Count > 0)
                {

                    ids.DataSource = bid;
                    ids.DataBind();
                    errormsg.Visible = false;
                    Button1.Disabled = false;
                }
                else
                {
                    errormsg.Text = "No booking id is available to cancel";
                    errormsg.Visible = true;
                    Button1.Disabled = true;

                }

                if (Request.QueryString.Count > 0)
                {
                    errormsg.Text = Request.QueryString["err"] + " : " + Request.QueryString["bid"];
                    ((User)this.Master).SMSmsg = errormsg.Text;
                    errormsg.Visible = true;
                }


            }

        }
    }
    protected void submit(object sender, EventArgs e)
    {
        EntCP.BookingId =ids.SelectedValue;
        int status= BusCP.checkbookingidstatus(EntCP);
        Response.Cookies["bookingid"].Value = ids.SelectedValue;
        Response.Redirect("cancel_details.aspx");
    }

 
}