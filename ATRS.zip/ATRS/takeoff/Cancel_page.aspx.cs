﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Cancellation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            string custid = Session["cid"].ToString();
        
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        
            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlCommand storedProcCommand = new SqlCommand("getbookingids", myConnection);
            storedProcCommand.CommandType = CommandType.StoredProcedure;
   
            SqlParameter parameter = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
     
    
            storedProcCommand.Parameters.Add(parameter);
            parameter.Value = custid;
            SqlDataAdapter sqlAdapter = new SqlDataAdapter(storedProcCommand);
            DataSet ds = new DataSet();
            sqlAdapter.Fill(ds, "BookingId");
           

            BookingId.DataSource = ds;
            BookingId.DataTextField = "BookingId";
            BookingId.DataValueField = "BookingId";
            BookingId.DataBind();

        }
    }
    protected void submit(object sender, EventArgs e)
    {
        Response.Cookies["BookingId"].Value = BookingId.Value;
        Response.Redirect("cancel_details.aspx");
    }
}