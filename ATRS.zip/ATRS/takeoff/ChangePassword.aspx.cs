﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
using AjaxControlToolkit;


public partial class ChangePassword : System.Web.UI.Page
{
    EntChangePwd EntCP = new EntChangePwd();
    BusChangePwd BusCP = new BusChangePwd();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            if (Request.Cookies["uname"] != null)

                UserName.Text = Request.Cookies["uname"].Value;
            else
                Response.Redirect("login.aspx");
        }
        else
            UserName.Text = Session["uname"].ToString();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int saltSize = 5;
        string salt = CreateSalt(saltSize);
        string passwordHash = CreatePasswordHash(passtxt.Text, salt);
        try
        {
            EntCP.UserName = UserName.Text;
            EntCP.Salt = salt;
            EntCP.PasswordHash = passwordHash;

            if (BusCP.ChangePwd(EntCP))
            {
                Response.Write("<script type='javascript'>alert('inserted successfully and you need to login again')</script>");
                Session.RemoveAll();
                Response.Redirect("login.aspx?uname=" + UserName.Text);
            }
            else
            {
                Response.Write("<script type='javascript'>alert('Change not successful')</script>");
            }
            //StoreAccountDetails(UserName.Value, passwordHash, salt);
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }

        //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
      
        //Response.Redirect("Login.aspx?uname=" + UserName.Value);
        //try
        //{
        //    StoreAccountDetails(UserName.Text, passwordHash, salt);
        //}
        //catch (Exception ex)
        //{
        //    lblMessage.Text = ex.Message;
        //}
    }
    //protected void StoreAccountDetails(string userName, string passwordHash, string salt)
    //{


    //    SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

    //    SqlCommand cmd = new SqlCommand("ChangePassword", conn);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    SqlParameter sqlParam = null;


    //    sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar, 15);
    //    if (Session["uname"] == null)
    //        sqlParam.Value = Request.Cookies["uname"].Value;
    //    else
    //        sqlParam.Value = Session["uname"].ToString();
    //    //sqlParam.Value = Request.Cookies["uname"].Value;
    //    sqlParam = cmd.Parameters.Add("@password ", SqlDbType.VarChar, 40);
    //    sqlParam.Value = passwordHash;
    //    sqlParam = cmd.Parameters.Add("@salt ", SqlDbType.VarChar, 40);
    //    sqlParam.Value = salt;
    //    try
    //    {
    //        conn.Open();
    //        cmd.ExecuteNonQuery();
    //    }
    //    catch (Exception ex)
    //    {
    //        // Code to check for primary key violation (duplicate account name)
    //        // or other database errors omitted for clarity
    //        throw new Exception("Exception Changing Password" + ex.Message);
    //    }
    //    finally
    //    {
    //        conn.Close();
    //    }

    //    Response.Redirect("login.aspx?uname="+UserName.Text);
    //}
    protected static string CreateSalt(int size)
    {
        // Generate a cryptographic random number using the cryptographic
        // service provider
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] buff = new byte[size];
        rng.GetBytes(buff);
        // Return a Base64 string representation of the random number
        return Convert.ToBase64String(buff);
    }
    protected static string CreatePasswordHash(string pwd, string salt)
    {
        string saltAndPwd = String.Concat(pwd, salt);
        string hashedPwd = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
        //hashedPwd = String.Concat(hashedPwd, salt);
        return hashedPwd;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        passtxt.Text = "";
        cpasstxt.Text = "";
    }
}