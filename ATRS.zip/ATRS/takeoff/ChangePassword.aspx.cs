﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
using AjaxControlToolkit;

/// <summary>
/// An internal method for writing data to file
/// </summary>
/// <param name="">
/// Data to be written
/// /// </param>
/// /// <returns></returns>
public partial class ChangePassword : System.Web.UI.Page
{
    EntChangePwd EntCP = new EntChangePwd();
    BusChangePwd BusCP = new BusChangePwd();
    /// <summary>
    /// Change Password Page
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            if (Request.Cookies["uname"] != null)
            {
                LoggingSample.Logging.LogInfo("Accessing Changing Password for the user : " + Request.Cookies["uname"].Value + ": After validating the credentials", true);
                UserName.Text = Request.Cookies["uname"].Value;
            }
            else
            {
                Response.Redirect("login.aspx");
            }
        }
        else
        {
            LoggingSample.Logging.LogInfo("Accessing Changing Password for the user : " + Session["uname"].ToString() + ": From the user's console", true);
            UserName.Text = Session["uname"].ToString();
        }

    }
    /// <summary>
    /// Change Password Button Clik
    /// </summary>
    protected void Button2_Click(object sender, EventArgs e)
    {
        int saltSize = 5;
        string salt = CreateSalt(saltSize);
        string passwordHash = CreatePasswordHash(passtxt.Text, salt);
        try
        {
            EntCP.UserName = UserName.Text;
            EntCP.Salt = salt;
            EntCP.PasswordHash = passwordHash;

            if (Session["uname"] == null)
            {
                if (Request.Cookies["uname"] != null)
                {
                    if (BusCP.ChangePwd(EntCP))
                    {
                        LoggingSample.Logging.LogInfo("Successfully Changed Password for the user : " + Request.Cookies["uname"].Value, true);
                        Response.Write("<script type='javascript'>alert('inserted successfully and you need to login again')</script>");
                        Session.RemoveAll();
                        Response.Redirect("login.aspx?uname=" + UserName.Text);
                    }
                    else
                    {
                        LoggingSample.Logging.LogInfo("Unable to Change Password for the user : " + Request.Cookies["uname"].Value, true);
                        //Response.Write("<script type='javascript'>alert('Change not successful')</script>");
                        ((MasterPage)this.Master).displayMessage("Change not successfull");
                    }

                }

            }
            else
            {
                if (BusCP.ChangePwd(EntCP))
                {
                    LoggingSample.Logging.LogInfo("Successfully Changed Password for the user : " + Session["uname"].ToString(), true);
                    Response.Write("<script type='javascript'>alert('inserted successfully and you need to login again')</script>");
                    //Session.RemoveAll();
                    string msg = "Password Changed Successfully";
                    Response.Redirect("user.aspx?msg=" + msg);
                    //Response.Redirect("login.aspx?uname=" + UserName.Text);
                }
                else
                {
                    LoggingSample.Logging.LogInfo("Unable to Change Password for the user : " + Request.Cookies["uname"].Value, true);
                    //Response.Write("<script type='javascript'>alert('Change not successful')</script>");
                    ((MasterPage)this.Master).displayMessage("Change not successfull");
                }
            }
            //StoreAccountDetails(UserName.Value, passwordHash, salt);
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }

        //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
      
        //Response.Redirect("Login.aspx?uname=" + UserName.Value);
        //try
        //{
        //    StoreAccountDetails(UserName.Text, passwordHash, salt);
        //}
        //catch (Exception ex)
        //{
        //    lblMessage.Text = ex.Message;
        //}
    }
    /// <summary>
    /// An internal method for writing data to file
    /// </summary>
    /// <param name="size">
    /// Size of the Salt
    /// /// </param>
    /// /// <returns>Salt String</returns>
    protected static string CreateSalt(int size)
    {
        // Generate a cryptographic random number using the cryptographic
        // service provider
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] buff = new byte[size];
        rng.GetBytes(buff);
        // Return a Base64 string representation of the random number
        LoggingSample.Logging.LogInfo("Successfully generated new salt", true);
        return Convert.ToBase64String(buff);
    }
    /// <summary>
    /// Creating Password Hash
    /// </summary>
    /// <param name="pwd">
    /// password entered by the user
    /// </param>
    /// <param name="salt">
    /// Salt generated during the process
    /// </param>
    /// /// <returns>Hashed Password</returns>
    protected static string CreatePasswordHash(string pwd, string salt)
    {
        string saltAndPwd = String.Concat(pwd, salt);
        string hashedPwd = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
        //hashedPwd = String.Concat(hashedPwd, salt);
        LoggingSample.Logging.LogInfo("Successfully hashed the password", true);
        return hashedPwd;
    }
    /// <summary>
    /// Reset Button Click Event
    /// </summary>
    protected void Button1_Click(object sender, EventArgs e)
    {
        passtxt.Text = "";
        cpasstxt.Text = "";
    }
}