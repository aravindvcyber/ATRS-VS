﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data.SqlClient;
using System.Data;

public partial class ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UserName.Text = Session["uname"].ToString();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int saltSize = 5;
        string salt = CreateSalt(saltSize);
        string passwordHash = CreatePasswordHash(passtxt.Text, salt);
        try
        {
            StoreAccountDetails(UserName.Text, passwordHash, salt);
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
    }
    protected void StoreAccountDetails(string userName, string passwordHash, string salt)
    {


        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("ChangePassword", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;


        sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar, 15);
        sqlParam.Value = userName;
        sqlParam = cmd.Parameters.Add("@password ", SqlDbType.VarChar, 40);
        sqlParam.Value = passwordHash;
        sqlParam = cmd.Parameters.Add("@salt ", SqlDbType.VarChar, 40);
        sqlParam.Value = salt;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception Changing Password" + ex.Message);
        }
        finally
        {
            conn.Close();
        }
        Response.Redirect("login.aspx");
    }
    protected static string CreateSalt(int size)
    {
        // Generate a cryptographic random number using the cryptographic
        // service provider
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] buff = new byte[size];
        rng.GetBytes(buff);
        // Return a Base64 string representation of the random number
        return Convert.ToBase64String(buff);
    }
    protected static string CreatePasswordHash(string pwd, string salt)
    {
        string saltAndPwd = String.Concat(pwd, salt);
        string hashedPwd = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
        //hashedPwd = String.Concat(hashedPwd, salt);
        return hashedPwd;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        passtxt.Text = "";
        cpasstxt.Text = "";
    }
}