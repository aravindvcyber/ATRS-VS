﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";

        if (!IsPostBack)
        {
            
            string QueryString = "select SSN_type from  SSN_Master";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "SSN_Type");

            Select1.DataSource = ds;
            Select1.DataTextField = "SSN_Type";
            Select1.DataValueField = "SSN_Type";
            Select1.DataBind();

            QueryString = "select SecurityQuestions from security ";

             myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
             ds = new DataSet();
             myCommand.Fill(ds, "SecurityQuestions");

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();



        }
        SqlConnection Conn = new SqlConnection(ConnectString);
        try
        {
        
        SqlCommand cmd = new SqlCommand("selectCommand", Conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@CustomerId", SqlDbType.VarChar, 6);
        sqlParam.Value = Session["cid"].ToString();
      
            Conn.Open(); 
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
               
                first_name.Value = rdr["firstname"].ToString();
                last_name.Value = rdr["lastname"].ToString();
                email.Value = rdr["emailid"].ToString();
                Select1.Value = rdr["ssntype"].ToString();
                Ssn_Number.Value = rdr["ssnvalue"].ToString();
                security.Value = rdr["SecurityQuestion"].ToString();
                securityans.Value = rdr["SecurityAnswer"].ToString();
               //(RadioButton)this.Page.FindControl("test1")
                //if (rdr["gender"].ToString()== "Male") 
                //{
                //    Request["test1"]=checked;
                //}
                //else
                //{
                //    Request["test2"]=checked;
                //}
                Address.Value = rdr["address"].ToString();
             //date    = rdr["dob"].ToString();
                mobile.Value = rdr["mobile"].ToString();
            }
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception viewing Customer Details " + ex.Message);
        }
        finally
        {
            Conn.Close();
        }
       
    }

    protected void loginbtn_Click(object sender, EventArgs e)
    {
        updatecustomerdetails();
        Response.Redirect("user.aspx");
    }

    private void updatecustomerdetails()
    {
        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        string newcustid = Session["cid"].ToString();


        SqlCommand cmd = new SqlCommand("updatecustomerdetails", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        sqlParam.Value = newcustid;
        sqlParam = cmd.Parameters.Add("@first", SqlDbType.VarChar, 25);
        sqlParam.Value = first_name.Value;
        sqlParam = cmd.Parameters.Add("@last", SqlDbType.VarChar, 25);
        sqlParam.Value = last_name.Value;
        sqlParam = cmd.Parameters.Add("@email", SqlDbType.VarChar, 50);
        sqlParam.Value = email.Value;
        sqlParam = cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 15);
        sqlParam.Value = mobile.Value;
        sqlParam = cmd.Parameters.Add("@dob", SqlDbType.Date);
        sqlParam.Value = Convert.ToDateTime(this.Request.Form.Get("date")).ToShortDateString();
        sqlParam = cmd.Parameters.Add("@address", SqlDbType.VarChar, 100);
        sqlParam.Value = Address.Value;
        sqlParam = cmd.Parameters.Add("@ssntype", SqlDbType.VarChar, 30);
        sqlParam.Value = Select1.Value;
        sqlParam = cmd.Parameters.Add("@ssnvalue", SqlDbType.VarChar, 50);
        sqlParam.Value = Ssn_Number.Value;
        sqlParam = cmd.Parameters.Add("@security", SqlDbType.VarChar, 100);
        sqlParam.Value = security.Value;
        sqlParam = cmd.Parameters.Add("@securityans", SqlDbType.VarChar, 100);
        sqlParam.Value = securityans.Value;
        sqlParam = cmd.Parameters.Add("@gender", SqlDbType.VarChar, 10);
        if (this.Request.Form.Get("test1") == "true")
            sqlParam.Value = "Male";
        else
            sqlParam.Value = "Female"; 
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception updating Customer Details " + ex.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    protected void reset_Click(object sender, EventArgs e)
    {
        Response.Redirect("user.aspx");
    }
}