﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using ARS.Business;
using ARS.Entity;

public partial class Edit : System.Web.UI.Page
{
    EntEdit EntE = new EntEdit();
    BusEdit BusE = new BusEdit();
    protected void Page_Load(object sender, EventArgs e)
    {

        ((User)this.Master).SMSmsg = "Edit Module - To edit the user profile details";
        ((User)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {

            DataSet ds = new DataSet();
            ds = BusE.fetchSsnType();

           

            Select1.DataSource = ds;
            Select1.DataTextField = "SSN_Type";
            Select1.DataValueField = "SSN_Type";
            Select1.DataBind();

            ds = BusE.fetchSecurityQues();

           

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();

            try
            {


            EntEdit EntEv = new EntEdit();
            EntEv.CustomerId = Session["cid"].ToString();
            EntEv=BusE.viewcustomerdetails(EntEv);

            first_name.Value = EntEv.FirstName;
            last_name.Value = EntEv.LastName;
            email.Value = EntEv.EmailId;
            Select1.Value = EntEv.SsnType;
            Ssn_Number.Value = EntEv.SsnValue;
            security.Value = EntEv.SecurityQuestion;
            securityans.Value = EntEv.SecurityAnswer;
            gender.Value =EntEv.Gender;
            Address.Value = EntEv.Address;
            //this.Page.Form.V date.Text   = rdr["dob"].ToString();
            mobile.Value = EntEv.Mobile;



           
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Viewing Customer Details " + ex.Message);
            }
            finally
            {
                //Conn.Close();
            }
        }

    }

    protected void loginbtn_Click(object sender, EventArgs e)
    {

         if (Page.IsValid && (captcha.Value.ToString() ==
                            Session["randomStr"].ToString()))
        {

        //Response.Write(@"<script language='javascript'>alert('Update is successful.')</script>");
        updatecustomerdetails();
        
        Response.Redirect("user.aspx");
        //Response.Write("<script language=javascript>alert('Successfully Updated the Profile Details');</script>");
        }
         else
         {
             Label1.Text = "Please re-enter the Captcha-digits correctly...";
         }
   

    }

    private void updatecustomerdetails()
    {
        try
        {
        EntE.CustomerId=Session["cid"].ToString();
        EntE.FirstName=first_name.Value;
        EntE.LastName=last_name.Value;
        EntE.EmailId=email.Value;
        EntE.Mobile=mobile.Value;
        EntE.Address=Address.Value;
        EntE.SecurityQuestion=security.Value;
        EntE.SecurityAnswer=securityans.Value;
        EntE.SsnType=Select1.Value;
        EntE.SsnValue=Ssn_Number.Value;
        EntE.DOB=Convert.ToDateTime(this.Request.Form.Get("date"));
        EntE.Gender = gender.Value;

        BusE.updatecustomerdetails(EntE);

       
        }
           
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception updating Customer Details " + ex.Message);
        }
        finally
        {
            //Response.Write(@"<script language='javascript'>alert('Update is successful.')</script>");
            //conn.Close();
        }
    }

    protected void reset_Click(object sender, EventArgs e)
    {
        Response.Redirect("user.aspx");
    }
}