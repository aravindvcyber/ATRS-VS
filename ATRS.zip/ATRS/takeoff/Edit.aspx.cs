﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using ARS.Business;
using ARS.Entity;

public partial class Edit : System.Web.UI.Page
{
    EntEdit EntE = new EntEdit();
    BusEdit BusE = new BusEdit();
    protected void Page_Load(object sender, EventArgs e)
    {

        ((User)this.Master).SMSmsg = "Edit Module - To edit the user profile details";
        ((User)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {

            DataSet ds = new DataSet();
            ds = BusE.fetchSsnType();

            //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select SSN_type from  SSN_Master";

            //SqlConnection myConnection = new SqlConnection(ConnectString);
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            //ds = new DataSet();
            //myCommand.Fill(ds, "SSN_Type");

            Select1.DataSource = ds;
            Select1.DataTextField = "SSN_Type";
            Select1.DataValueField = "SSN_Type";
            Select1.DataBind();

            ds = BusE.fetchSecurityQues();

            //QueryString = "select SecurityQuestions from security ";

            //myConnection = new SqlConnection(ConnectString);
            //myCommand = new SqlDataAdapter(QueryString, myConnection);
            //ds = new DataSet();
            //myCommand.Fill(ds, "SecurityQuestions");

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();

            try
            {


            EntEdit EntEv = new EntEdit();
            EntEv.CustomerId = Session["cid"].ToString();
            EntEv=BusE.viewcustomerdetails(EntEv);

            first_name.Value = EntEv.FirstName;
            last_name.Value = EntEv.LastName;
            email.Value = EntEv.EmailId;
            Select1.Value = EntEv.SsnType;
            Ssn_Number.Value = EntEv.SsnValue;
            security.Value = EntEv.SecurityQuestion;
            securityans.Value = EntEv.SecurityAnswer;
            gender.Value =EntEv.Gender;
            Address.Value = EntEv.Address;
            //this.Page.Form.V date.Text   = rdr["dob"].ToString();
            mobile.Value = EntEv.Mobile;



            //SqlConnection Conn = new SqlConnection(ConnectString);
           
            //    SqlCommand cmd = new SqlCommand("selectCommand", Conn);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    SqlParameter sqlParam = null;
            //    sqlParam = cmd.Parameters.Add("@CustomerId", SqlDbType.VarChar, 6);
            //    sqlParam.Value = Session["cid"].ToString();

            //    Conn.Open();
            //    SqlDataReader rdr = cmd.ExecuteReader();
            //    while (rdr.Read())
            //    {

            //        first_name.Value = rdr["firstname"].ToString();
            //        last_name.Value = rdr["lastname"].ToString();
            //        email.Value = rdr["emailid"].ToString();
            //        Select1.Value = rdr["ssntype"].ToString();
            //        Ssn_Number.Value = rdr["ssnvalue"].ToString();
            //        security.Value = rdr["SecurityQuestion"].ToString();
            //        securityans.Value = rdr["SecurityAnswer"].ToString();
            //        gender.Value = rdr["gender"].ToString();
            //        Address.Value = rdr["address"].ToString();
            //        //this.Page.Form.V date.Text   = rdr["dob"].ToString();
            //        mobile.Value = rdr["mobile"].ToString();
            //    }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Viewing Customer Details " + ex.Message);
            }
            finally
            {
                //Conn.Close();
            }
        }

    }

    protected void loginbtn_Click(object sender, EventArgs e)
    {

         if (Page.IsValid && (captcha.Value.ToString() ==
                            Session["randomStr"].ToString()))
        {

        //Response.Write(@"<script language='javascript'>alert('Update is successful.')</script>");
        updatecustomerdetails();
        
        Response.Redirect("user.aspx");
        //Response.Write("<script language=javascript>alert('Successfully Updated the Profile Details');</script>");
        }
         else
         {
             Label1.Text = "Please re-enter the Captcha-digits correctly...";
         }
   

    }

    private void updatecustomerdetails()
    {
        try
        {
        EntE.CustomerId=Session["cid"].ToString();
        EntE.FirstName=first_name.Value;
        EntE.LastName=last_name.Value;
        EntE.EmailId=email.Value;
        EntE.Mobile=mobile.Value;
        EntE.Address=Address.Value;
        EntE.SecurityQuestion=security.Value;
        EntE.SecurityAnswer=securityans.Value;
        EntE.SsnType=Select1.Value;
        EntE.SsnValue=Ssn_Number.Value;
        EntE.DOB=Convert.ToDateTime(this.Request.Form.Get("date"));
        EntE.Gender = gender.Value;

        BusE.updatecustomerdetails(EntE);

        //SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        //string newcustid = Session["cid"].ToString();

        //SqlCommand cmd = new SqlCommand("updatecustomerdetails", conn);
        //cmd.CommandType = CommandType.StoredProcedure;
        //SqlParameter sqlParam = null;
        //sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        //sqlParam.Value = newcustid;
        //sqlParam = cmd.Parameters.Add("@first", SqlDbType.VarChar, 25);
        //sqlParam.Value = first_name.Value;
        //sqlParam = cmd.Parameters.Add("@last", SqlDbType.VarChar, 25);
        //sqlParam.Value = last_name.Value;
        //sqlParam = cmd.Parameters.Add("@email", SqlDbType.VarChar, 50);
        //sqlParam.Value = email.Value;
        //sqlParam = cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 15);
        //sqlParam.Value = mobile.Value;
        //sqlParam = cmd.Parameters.Add("@dob", SqlDbType.Date);
        //sqlParam.Value = Convert.ToDateTime(this.Request.Form.Get("date")).ToShortDateString();
        //sqlParam = cmd.Parameters.Add("@address", SqlDbType.VarChar, 100);
        //sqlParam.Value = Address.Value;
        //sqlParam = cmd.Parameters.Add("@ssntype", SqlDbType.VarChar, 30);
        //sqlParam.Value = Select1.Value;
        //sqlParam = cmd.Parameters.Add("@ssnvalue", SqlDbType.VarChar, 50);
        //sqlParam.Value = Ssn_Number.Value;
        //sqlParam = cmd.Parameters.Add("@security", SqlDbType.VarChar, 100);
        //sqlParam.Value = security.Value;
        //sqlParam = cmd.Parameters.Add("@securityans", SqlDbType.VarChar, 100);
        //sqlParam.Value = securityans.Value;
        //sqlParam = cmd.Parameters.Add("@gender", SqlDbType.VarChar, 10);
        ////if (this.Request.Form.Get("test1") == "true")
        ////    sqlParam.Value = "Male";
        ////else
        ////    sqlParam.Value = "Female";
        // sqlParam.Value=gender.Value;
       
        //    conn.Open();
        //    cmd.ExecuteNonQuery();
        }
           
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception updating Customer Details " + ex.Message);
        }
        finally
        {
            //Response.Write(@"<script language='javascript'>alert('Update is successful.')</script>");
            //conn.Close();
        }
    }

    protected void reset_Click(object sender, EventArgs e)
    {
        Response.Redirect("user.aspx");
    }
}