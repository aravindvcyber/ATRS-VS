﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Security;

public partial class Errors : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "Error Logger";
        ((Admin)this.Master).Headmsg = "Successfull!";
        if (!Page.IsPostBack)
        {
            if (Request.QueryString.Count == 0)
            {
                dvErrorReport.InnerHtml = ApplyXSLTransformation();
                transf.Visible = false;
                ((Admin)this.Master).SMSmsg = "All the Error Logs of the Website Till Date";
                ((Admin)this.Master).Headmsg = "Successfully opened! : All Error Logs";
            }
            else
            {
                dvErrorReport.InnerHtml = ApplyXSLTransformation(Request.QueryString["fid"]);
                transf.Visible = true;
                ((Admin)this.Master).SMSmsg = "Click the Links Below to Download the generated xml file or View the Xml with transformation :";
                ((Admin)this.Master).Headmsg = "Successfully opened! : " + Request.QueryString["fid"];
                xml.NavigateUrl = generateXML(Request.QueryString["fid"]);
            }

        }
    }
    protected string generateXML(string fid)
    {
        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_Err");

        string File = path + "\\" + fid;


        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Errors>");

        StreamReader strmReader = new StreamReader(File);
        sbLogFiles.Append(strmReader.ReadToEnd());
        strmReader.Close();

        sbLogFiles.Append("</Errors>");
        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Exception")
                             //orderby a.Element("SessionID").Value ascending
                             //orderby Convert.ToDateTime(a.Element("DateTime").Value) descending
                             select a);

        XElement objFinalXML = new XElement("Errors", objOrderedXml);


        // Create the XmlDocument.
        XmlDocument doc = new XmlDocument();


        doc.LoadXml(objFinalXML.ToString());


        //Create an XML declaration. 
        XmlDeclaration xmldecl;
        xmldecl = doc.CreateXmlDeclaration("1.0", null, null);
        xmldecl.Encoding = "UTF-8";
        xmldecl.Standalone = "yes";

        //Add the new node to the document.
        XmlElement root = doc.DocumentElement;
        doc.InsertBefore(xmldecl, root);

        //// Add a price element.
        //XmlElement newElem = doc.CreateElement("price");
        //newElem.InnerText = "10.95";
        //doc.DocumentElement.AppendChild(newElem);

        // Save the document to a file. White space is
        // preserved (no white space).
        doc.PreserveWhitespace = true;
        string xfid = fid.Replace(".txt", ".xml");
        doc.Save(path + "\\xml\\" + xfid);

        //Build your target to navigate to (using String.Format())
        string url = String.Format("XmlTransformer.aspx?type=Err&fid=" + xfid, false);

        ////Build your client-side script that will open your target in a new page
        //string script = String.Format("window.open('{0}','_blank');", url);

        ////Combine these two together so that when your page is loaded it will open your target URL in a new window
        //ClientScript.RegisterStartupScript(GetType(), "YourStartupScript", script, true);




        //string url = HttpContext.Current.Server.MapPath("XmlTransform.aspx") + "?type=App&fid=" + xfid;
        //StringBuilder sb = new StringBuilder();
        //sb.Append("<script type = 'text/javascript'>");
        //sb.Append("window.open('");
        //sb.Append(url);
        //sb.Append("');");
        //sb.Append("</script>");
        //ClientScript.RegisterStartupScript(this.GetType(),
        //        "script", sb.ToString());

        //Response.Write("<script>");
        //Response.Write("window.open('" + xml + "','_blank')");
        //Response.Write("</script>");

        //Server.Transfer(url);

        //((MasterPage)this.Master.Master).displayMessage("<p style='color:navy;'>Session Terminated</p> Due to your Action<br/>");

        //Response.Redirect(url, false);
        return url;
    }
    private string ApplyXSLTransformation(string fid)
    {
        string strHtml;

        string strXstFile = Server.MapPath("Styles/ErrorLog.xslt");
        XslCompiledTransform x = new XslCompiledTransform();

        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_Err");

        string File = path + "\\" + fid;


        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Errors>");

        StreamReader strmReader = new StreamReader(File);
        sbLogFiles.Append(strmReader.ReadToEnd());
        strmReader.Close();

        sbLogFiles.Append("</Errors>");
      

        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Exception")
                            
                             select a);

        XElement objFinalXML = new XElement("Errors", objOrderedXml);

        XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
        XPathDocument doc = new XPathDocument(objXmlReader);

        // Load the style sheet.
        XslCompiledTransform xslt = new XslCompiledTransform();
        xslt.Load(strXstFile);
        MemoryStream ms = new MemoryStream();
        XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
        StreamReader rd = new StreamReader(ms);
        xslt.Transform(doc, writer);
        ms.Position = 0;
        strHtml = rd.ReadToEnd();
        rd.Close();
        ms.Close();
        return strHtml;
    }
    private string ApplyXSLTransformation()
    {
        string strHtml;

        string strXstFile = Server.MapPath("Styles/ErrorLog.xslt");
        XslCompiledTransform x = new XslCompiledTransform();

        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_Err");
        string[] strFiles = Directory.GetFiles(path);
        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Errors>");
        for (int i = 0; i < strFiles.Length; i++)
        {
            StreamReader strmReader = new StreamReader(strFiles[i]);
            sbLogFiles.Append(strmReader.ReadToEnd());
            strmReader.Close();
        }
        sbLogFiles.Append("</Errors>");
       

        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Exception")
                            
                             select a);

        XElement objFinalXML = new XElement("Errors", objOrderedXml);

        XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
        XPathDocument doc = new XPathDocument(objXmlReader);

        // Load the style sheet.
        XslCompiledTransform xslt = new XslCompiledTransform();
        xslt.Load(strXstFile);
        MemoryStream ms = new MemoryStream();
        XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
        StreamReader rd = new StreamReader(ms);
        xslt.Transform(doc, writer);
        ms.Position = 0;
        strHtml = rd.ReadToEnd();
        rd.Close();
        ms.Close();
        return strHtml;
    }
    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    transf.Visible = false;
    //    generateXML(Request.QueryString["fid"]);
    //}

    protected void downxml_Click(object sender, EventArgs e)
    {
        string fid = Request.QueryString["fid"];
        string xfid = fid.Replace(".txt", ".xml");

        //Download the Xml file
        Response.ContentType = "application/xml";
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + xfid);
        Response.TransmitFile(Server.MapPath("~/Logs_Err/xml/" + xfid));
        Response.End();
    }
}