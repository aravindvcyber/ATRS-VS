﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Entity;
using ARS.Business;

public partial class Finalinvoice : System.Web.UI.Page
{
    EntFinalInvoice EntFI = new EntFinalInvoice();
    BusFinalInvoice BusFI = new BusFinalInvoice();
    protected void Page_Load(object sender, EventArgs e)
    {
        CustomerName.Value = Session["fname"].ToString()+ " "+Session["lname"].ToString();
        NoofPassenger.Value = Request.Cookies["seats"].Value;
        ClassType.Value = Request.Cookies["class"].Value;
        string SchedlueId = Request.Cookies["scheduleid"].Value;
        String Price = Request.Cookies["price"].Value;
        TotalPrice.Value = (Convert.ToInt32(Price) * Convert.ToInt32(NoofPassenger.Value)).ToString();
        BookingID.Value = Request.Cookies["bookingid"].Value;
        if (!IsPostBack)
        {

            FetchFlightDetails();         
            
        }


    }

    private void FetchFlightDetails()
    {

        EntFI.ScheduleId = Request.Cookies["scheduleid"].Value;
        SqlDataReader reader = BusFI.FetchFlightDetails(EntFI);



        //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        

        //SqlConnection con = new SqlConnection(ConnectString);

       
        //SqlCommand cmd = new SqlCommand("preinvoice_flightdetails", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //SqlParameter sqlParam = null;
        //sqlParam = cmd.Parameters.Add("@scheduleid", SqlDbType.VarChar, 20);
        //sqlParam.Value = SchedlueId;
        //con.Open();
        //SqlDataReader reader = cmd.ExecuteReader();
        //reader.Read();
        FlightID.Value = reader["FlightId"].ToString();

        DepatureTime.Value = reader["departuredate"].ToString();
        DateofJourney.Value = reader["departuretime"].ToString();
        LeavingFrom.Value = reader["fromlocation"].ToString();
        GoingTo.Value = reader["tolocation"].ToString();
        reader.Close();
    }
    protected void Home_Click(object sender, EventArgs e)
    {
        Response.Redirect("user.aspx");
    }
    protected void Print_Click(object sender, EventArgs e)
    {
        Response.Cookies["bookingid"].Value = BookingID.Value;
        Response.Redirect("invoice.aspx");
    }
}