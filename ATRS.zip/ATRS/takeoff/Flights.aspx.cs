﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class Flights : System.Web.UI.Page
{
    EntFlights EntF = new EntFlights();
    BusFlights BusF = new BusFlights();
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "New Flights inserter";
        ((Admin)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = BusF.fetchAirlines();


            
         

            airlineid.DataSource = ds;
            airlineid.DataTextField = "A_Name";
            airlineid.DataValueField = "A_Name";
            airlineid.DataBind();
        }
    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        
         try
        {
        EntF.AirlineId=airlineid.Value;
        EntF.ISeats= Convert.ToInt32(Iseats.Value);
        EntF.IPrice = Convert.ToInt32(Iprice.Value);
        EntF.IISeats= Convert.ToInt32(IIseats.Value);
        EntF.IIPrice=Convert.ToInt32(IIprice.Value);
        EntF.IIISeats= Convert.ToInt32(IIIseats.Value);
        EntF.IIIPrice=Convert.ToInt32(IIIprice.Value);
          if(BusF.insertFlights(EntF))
          {
              ((Admin)this.Master).SMSmsg = "New Flight from " + airlineid.Value + " added...";
              ((Admin)this.Master).Headmsg = "Successfull!";
          }
              else
          {
          }



        //SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        //SqlCommand cmd = new SqlCommand("insert_flightdetails", conn);
        //cmd.CommandType = CommandType.StoredProcedure;
        //SqlParameter sqlParam = null;
        //sqlParam = cmd.Parameters.Add("@airlinename", SqlDbType.VarChar, 15);
        //sqlParam.Value = airlineid.Value;
        //sqlParam = cmd.Parameters.Add("@Iseats", SqlDbType.Int);
        //sqlParam.Value = Iseats.Value;
        //sqlParam = cmd.Parameters.Add("@Iprice", SqlDbType.Int);
        //sqlParam.Value = Iprice.Value;
        //sqlParam = cmd.Parameters.Add("@IIseats", SqlDbType.Int);
        //sqlParam.Value = IIseats.Value;
        //sqlParam = cmd.Parameters.Add("@IIprice", SqlDbType.Int);
        //sqlParam.Value = IIprice.Value;
        //sqlParam = cmd.Parameters.Add("@IIIseats", SqlDbType.Int);
        //sqlParam.Value = IIIseats.Value;
        //sqlParam = cmd.Parameters.Add("@IIIprice", SqlDbType.Int);
        //sqlParam.Value = IIIprice.Value;
        
        ////try
        ////{
        //    conn.Open();
        //    cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception adding flight details " + ex.Message);
        }
        finally
        {
            //conn.Close();
        }
        //((Admin)this.Master).SMSmsg = "New Flight from " + airlineid.Value + " added...";
        //((Admin)this.Master).Headmsg = "Successfull!";
        Response.Redirect("admin.aspx");
    }

    protected void cancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("admin.aspx");
    }
}