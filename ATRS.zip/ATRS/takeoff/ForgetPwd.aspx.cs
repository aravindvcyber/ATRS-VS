﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;
using System.Activities.Statements;
using ARS.Business;
using ARS.Entity;

public partial class ForgetPwd : System.Web.UI.Page
{
    EntForgetPwd EntFP = new EntForgetPwd();
    BusForgetPwd BusFP = new BusForgetPwd();
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.QueryString.Count > 0)
        //    UserName.Value = Request.QueryString["uname"];
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select SecurityQuestions from Security";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "SecurityQuestions");

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();

        }
    }
    protected void loginbtn_Click(object sender, EventArgs e)
    {
        EntFP.UserName = UserName.Value;
        EntFP.EmailId = email.Value;
        EntFP.Security = security.Value;
        EntFP.SecurityAns = securityans.Value;

        if (BusFP.getUserNameValidate(EntFP))
        {
            Response.Cookies["uname"].Value = UserName.Value;
            //FormsAuthentication.SetAuthCookie(UserName.Value, Persist.Checked);
            Response.Redirect("ChangePassword.aspx");
        }
        else
        {
            Response.Redirect("ForgetPwd.aspx");
        }

        //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select Customers.CustomerName,Customers.customerid from Customers inner join Logins on Customers.CustomerId=Logins.CustomerId where username='" + UserName.Value + "' and emailid='" + email.Value + "' and securityQuestion='" + security.Value + "'and securityAnswer='" + securityans.Value + "'";

        //SqlConnection myConnection = new SqlConnection(ConnectString);
        //SqlCommand command = new SqlCommand(QueryString, myConnection);
        //myConnection.Open();
        //SqlDataReader rdr = command.ExecuteReader();
        //if (rdr.Read())
        //{
        //    Response.Cookies["uname"].Value = UserName.Value;
        //    //FormsAuthentication.SetAuthCookie(UserName.Value, Persist.Checked);
        //    Response.Redirect("ChangePassword.aspx");
        //}
        //else
        //{
        //    Response.Redirect("ForgetPwd.aspx");
        //}

    }
}