﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ARS.Business;
using ARS.Entity;
using System.Data.SqlClient;

namespace takeoff
{
    public partial class Info : System.Web.UI.Page
    {
        BusInfo BusI = new BusInfo();
        EntInfo EntI = new EntInfo();

        protected void Page_Load(object sender, EventArgs e)
        {

            SqlDataReader reader = BusI.FetchCounts();




            AirLines.Value = reader["Airlines"].ToString();
            Flights.Value = reader["Flights"].ToString();
            Locations.Value = reader["Locations"].ToString();
            Schedules.Value = reader["Schedules"].ToString();

            Bookings.Value = reader["Bookings"].ToString();
            Cancellations.Value = reader["Cancellations"].ToString();
            Tickets.Value = reader["Tickets"].ToString();

            Users.Value = reader["Users"].ToString();
            Comments.Value = reader["Comments"].ToString();


            reader.Close();
        }
    }
}