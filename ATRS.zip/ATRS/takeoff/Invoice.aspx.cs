﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
using KeepAutomation.Barcode.Bean;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text;
using System.Text;
using System.Web.Mail;
using System.Net;
using System.Net.Mail;

/// <summary>
/// Invoice Page Code
/// </summary>
public partial class Invoice : System.Web.UI.Page
{
    EntInvoice EntI = new EntInvoice();
    BusInvoice BusI = new BusInvoice();
    /// <summary>
    /// Page Loading Invoice
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] != null)
        {
            if (Request.Cookies["bookingid"] != null)
            {
                string user = Session["uname"].ToString();

                inv.Attributes["data-jdenticon-hash"] = ((MasterPage)this.Master.Master).Hash(user);
                if (!IsPostBack)
                {

                    EntI.BookingId = Request.Cookies["bookingid"].Value;
                    ((User)this.Master).SMSmsg = "Booking Id: " + Request.Cookies["bookingid"].Value + ". Take a print out of this page for your reference.";
                    ((User)this.Master).Headmsg = "Successfully opened!";
                    fetchBookingDetails();
                    fetchTicketDetails();
                    fetchCancelDetails();
                    LoggingSample.Logging.LogInfo("Successfully Loaded invoice for Booking Id : " + Request.Cookies["bookingid"].Value + " by : " + Session["uname"], true);
             
                }
            }
            else
            {
                Response.Redirect("transactions.aspx");
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
    /// <summary>
    /// Downloading pdf
    /// </summary>
    public void DownloadPDF()
    {
        var sb = new StringBuilder();

        //serverid.RenderControl(new HtmlTextWriter(new StringWriter(sb)));
        string s = sb.ToString();
        s = "<center><h1>takeoff</h1><center><br/><br/><h3>Payment Receipt</h3><br/>";
        sb.Clear();
        serverid1.RenderControl(new HtmlTextWriter(new StringWriter(sb)));


        s+= sb.ToString();
        s += "<br/><br/>";
        sb.Clear();
        serverid2.RenderControl(new HtmlTextWriter(new StringWriter(sb)));

      
        s+= sb.ToString();
        s += "<br/><br/>";
        sb.Clear();
        serverid3.RenderControl(new HtmlTextWriter(new StringWriter(sb)));

    
        s += sb.ToString();
        s += "<br/><br/>";
        sb.Clear();
        Status.RenderControl(new HtmlTextWriter(new StringWriter(sb)));

        // s += sb.ToString();
        //serverid5.RenderControl(new HtmlTextWriter(new StringWriter(sb)));

        //s += sb.ToString();
        s=s.Replace("&#8377","Rs. ");
        s += "<span class='ltTxt'>Tickets Status </span> <span class='rtTxt'>:&nbsp; <strong>" + sb.ToString() + "</strong></span>";
        sb.Clear();
        s += "<br/><br/><strong>Thank you!!! </strong>for using <a href='http://takeoff.in/' target='_blank'>www.takeoff.in</a>";



        s += "<br/><br /> Air Ticket Reservation System<br />Contact us at <a href='mailto://mail.takeoff.contact@gmail.com/' target='_blank'>mail.takeoff.contact@gmail.com</a><br />Company Pan no <strong>AR34FMKF89L</strong><br /> <br /><span class='ltTxt'>AirLine Name.</span> <span class='rtTxt'>:&nbsp; <strong>";
        serverid6.RenderControl(new HtmlTextWriter(new StringWriter(sb))); 
        s+= sb.ToString()+ "</strong></span>";

        string HTMLContent = s;

        Response.Clear();
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=" + "PDFfile.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.BinaryWrite(GetPDF(HTMLContent));
        Response.End();
    }
    /// <summary>
    /// An internal method for writing data to file
    /// </summary>
    /// <param name="pHTML">
    /// string pHTML
    /// /// </param>
    /// /// <returns>byte[]</returns>
    public byte[] GetPDF(string pHTML)
    {
        LoggingSample.Logging.LogInfo("Generating Pdf for invoice with Booking Id : " + Request.Cookies["bookingid"].Value + " by : " + Session["uname"], true);
        byte[] bPDF = null;

        MemoryStream ms = new MemoryStream();
        TextReader txtReader = new StringReader(pHTML);

        // 1: create object of a itextsharp document class
        Document doc = new Document(PageSize.A4, 25, 25, 25, 25);


       



        
        // 2: we create a itextsharp pdfwriter that listens to the document and directs a XML-stream to a file
        PdfWriter oPdfWriter = PdfWriter.GetInstance(doc, ms);
        
        // 3: we create a worker parse the document
        HTMLWorker htmlWorker = new HTMLWorker(doc);
       
        // 4: we open document and start the worker on the document
        doc.Open();




        var logo = iTextSharp.text.Image.GetInstance(Server.MapPath("~/img/logo.gif"));
        logo.SetAbsolutePosition(440, 750);
        doc.Add(logo);


        htmlWorker.StartDocument();

        // 5: parse the html into the document
        htmlWorker.Parse(txtReader);

        // 6: close the document and the worker
        htmlWorker.EndDocument();
        htmlWorker.Close();
        doc.Close();

        bPDF = ms.ToArray();
   
        return bPDF;
    }
    /// <summary>
    /// Fetching Cancellation Details
    /// </summary>
    private void fetchCancelDetails()
    {
        LoggingSample.Logging.LogInfo("Fetching Cacellation Details for invoice with Booking Id : " + Request.Cookies["bookingid"].Value + " by : " + Session["uname"], true);
        SqlDataReader reader= BusI.fetchCancelDetails(EntI);
        while (reader.Read())
        {

            Status.Text = "Cancellation Id : " + reader["cancellationid"].ToString();
        }
        reader.Close();
    }
    /// <summary>
    /// Fetching Ticket Details
    /// </summary>
    private void fetchTicketDetails()
    {
        LoggingSample.Logging.LogInfo("Fetching Ticket Details for invoice with Booking Id : " + Request.Cookies["bookingid"].Value + " by : " + Session["uname"], true);
        SqlDataReader reader= BusI.fetchTicketDetails(EntI);
        while (reader.Read())
        {
            Tickets.Items.Add(reader[0].ToString());
        }
        reader.Close();
    }
    /// <summary>
    /// For Fetching Booking Details
    /// </summary>
    private void fetchBookingDetails()
    {
        LoggingSample.Logging.LogInfo("Fetching Booking Details for  invoice with Booking Id : " + Request.Cookies["bookingid"].Value + " by : " + Session["uname"], true);
        SqlDataReader reader= BusI.fetchBookingDetails(EntI);
        sid.Text = reader["ScheduleId"].ToString();
        aname.Text = reader["A_NAME"].ToString();
        fname.Text = reader["FlightId"].ToString(); 
        svgimg.Src=reader["Logo"].ToString();
        CusName.Text = reader["CustomerName"].ToString();
        BookId.Text = reader["BookingId"].ToString();
        BookDate.Text = Convert.ToDateTime(reader["BookingDate"]).ToString();
        mobile.Text = reader["mobile"].ToString();
        booking.Text = "&#8377 " + reader["BookingCharge"].ToString();
        Total.Text = "&#8377 " + reader["Amount"].ToString();
        ticket.Text = "&#8377 " + (Convert.ToInt32(reader["Amount"].ToString()) - Convert.ToInt32(reader["BookingCharge"].ToString())).ToString();
        fromloc.Text = reader["FromLocation"].ToString();
        toloc.Text = reader["ToLocation"].ToString();
        classtype.Text = reader["ClassType"].ToString();
        dateofjourney.Text = Convert.ToDateTime(reader["DepartureDate"]).ToShortDateString() + " " + reader["DepartureTime"].ToString();
        //BarCode qrcode = new BarCode();
        qrcode.Symbology = KeepAutomation.Barcode.Symbology.QRCode;
        qrcode.CodeToEncode = "CustomerId: " + Session["cid"].ToString() + "\nBookingId: " + reader["BookingId"].ToString();
     
        qrcode.X = 4;
        qrcode.Y = 4;
        qrcode.BarCodeHeight = 100;
        qrcode.BarCodeWidth = 100;
        qc.NavigateUrl = "http://localhost:777/takeoff/viewinvoice.aspx?cid=" + Session["cid"].ToString() + "&bid=" + reader["BookingId"].ToString();
        //qrcode.generateBarcodeToImageFile("C://qrcode-csharp.png");
        
        reader.Close();
      
    }
    /// <summary>
    /// Download invoice in pdf Button Event
    /// </summary>
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SendEmail();
        LoggingSample.Logging.LogInfo("Downloading the invoice for Booking Id : "+Request.Cookies["bookingid"].Value+" by : "+Session["uname"],true );
        DownloadPDF();
    }
    //protected void SendEmail()
    //{
    //    using (System.Net.Mail.MailMessage mm = new System.Net.Mail.MailMessage())
    //    {
            
    //        mm.Subject = "My Subject";
    //        mm.Body = "Message";
    //        //if (fuAttachment.HasFile)
    //        //{
    //        //    string FileName = Path.GetFileName(fuAttachment.PostedFile.FileName);
    //        //    mm.Attachments.Add(new Attachment(fuAttachment.PostedFile.InputStream, FileName));
    //        //}
    //        //mm.IsBodyHtml = false;
    //        SmtpClient smtp = new SmtpClient();
    //        smtp.Host = "smtp.gmail.com";
    //        smtp.EnableSsl = true;
    //        mm.To.Add("aravindvcyber@gmail.com");
    //        mm.From = new MailAddress("mail.takeoff.contact@gmail.com");
    //        NetworkCredential NetworkCred = new NetworkCredential("mail.takeoff.contact@gmail.com", "TakeOff7$");
    //        smtp.UseDefaultCredentials = true;
    //        smtp.Credentials = NetworkCred;
    //        smtp.Port = 587;
    //        smtp.Send(mm);
    //        ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent.');", true);
    //    }
    //}
}