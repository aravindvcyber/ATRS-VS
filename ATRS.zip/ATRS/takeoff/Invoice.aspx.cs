﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;
using KeepAutomation.Barcode.Bean;


public partial class Invoice : System.Web.UI.Page
{
    EntInvoice EntI = new EntInvoice();
    BusInvoice BusI = new BusInvoice();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] != null)
        {
            if (Request.Cookies["bookingid"] != null)
            {
                string user = Session["uname"].ToString();

                inv.Attributes["data-jdenticon-hash"] = ((MasterPage)this.Master.Master).Hash(user);
                if (!IsPostBack)
                {

                    EntI.BookingId = Request.Cookies["bookingid"].Value;
                    ((User)this.Master).SMSmsg = "Booking Id: " + Request.Cookies["bookingid"].Value + ". Take a print out of this page for your reference.";
                    ((User)this.Master).Headmsg = "Successfully opened!";
                    fetchBookingDetails();
                    fetchTicketDetails();
                    fetchCancelDetails();
                }
            }
            else
            {
                Response.Redirect("transactions.aspx");
            }
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }

    private void fetchCancelDetails()
    {
        SqlDataReader reader= BusI.fetchCancelDetails(EntI);
        while (reader.Read())
        {

            Status.Text = "Cancellation Id : " + reader["cancellationid"].ToString();
        }
        reader.Close();
    }

    private void fetchTicketDetails()
    {
        SqlDataReader reader= BusI.fetchTicketDetails(EntI);
        while (reader.Read())
        {
            Tickets.Items.Add(reader[0].ToString());
        }
        reader.Close();
    }

    private void fetchBookingDetails()
    {
        SqlDataReader reader= BusI.fetchBookingDetails(EntI);
        sid.Text = reader["ScheduleId"].ToString();
        aname.Text = reader["A_NAME"].ToString();
        fname.Text = reader["FlightId"].ToString(); 
        svgimg.Src=reader["Logo"].ToString();
        CusName.Text = reader["CustomerName"].ToString();
        BookId.Text = reader["BookingId"].ToString();
        BookDate.Text = Convert.ToDateTime(reader["BookingDate"]).ToString();
        mobile.Text = reader["mobile"].ToString();
        booking.Text = "&#8377 " + reader["BookingCharge"].ToString();
        Total.Text = "&#8377 " + reader["Amount"].ToString();
        ticket.Text = "&#8377 " + (Convert.ToInt32(reader["Amount"].ToString()) - Convert.ToInt32(reader["BookingCharge"].ToString())).ToString();
        fromloc.Text = reader["FromLocation"].ToString();
        toloc.Text = reader["ToLocation"].ToString();
        classtype.Text = reader["ClassType"].ToString();
        dateofjourney.Text = Convert.ToDateTime(reader["DepartureDate"]).ToShortDateString() + " " + reader["DepartureTime"].ToString();
        //BarCode qrcode = new BarCode();
        qrcode.Symbology = KeepAutomation.Barcode.Symbology.QRCode;
        qrcode.CodeToEncode = "CustomerId: " + Session["cid"].ToString() + "\nBookingId: " + reader["BookingId"].ToString();
     
        qrcode.X = 4;
        qrcode.Y = 4;
        qrcode.BarCodeHeight = 100;
        qrcode.BarCodeWidth = 100;
        qc.NavigateUrl = "http://localhost:777/takeoff/viewinvoice.aspx?cid=" + Session["cid"].ToString() + "&bid=" + reader["BookingId"].ToString();
        //qrcode.generateBarcodeToImageFile("C://qrcode-csharp.png");
        
        reader.Close();
      
    }
}