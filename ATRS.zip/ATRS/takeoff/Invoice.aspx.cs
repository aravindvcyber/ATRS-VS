﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;


public partial class Invoice : System.Web.UI.Page
{
    EntInvoice EntI = new EntInvoice();
    BusInvoice BusI = new BusInvoice();

    protected void Page_Load(object sender, EventArgs e)
    {
        string user = Session["uname"].ToString();

        inv.Attributes["data-jdenticon-hash"] = ((MasterPage)this.Master.Master).Hash(user);
        if (!IsPostBack)
        {

            EntI.BookingId = Request.Cookies["bookingid"].Value;

            fetchBookingDetails();
            fetchTicketDetails();
            fetchCancelDetails();
        }
    }

    private void fetchCancelDetails()
    {
        SqlDataReader reader= BusI.fetchCancelDetails(EntI);
        while (reader.Read())
        {

            Status.Text = "Cancellation Id : " + reader["cancellationid"].ToString();
        }
        reader.Close();
    }

    private void fetchTicketDetails()
    {
        SqlDataReader reader= BusI.fetchTicketDetails(EntI);
        while (reader.Read())
        {
            Tickets.Items.Add(reader[0].ToString());
        }
        reader.Close();
    }

    private void fetchBookingDetails()
    {
        SqlDataReader reader= BusI.fetchBookingDetails(EntI);
       


        CusName.Text = reader["CustomerName"].ToString();
        BookId.Text = reader["BookingId"].ToString();
        BookDate.Text = Convert.ToDateTime(reader["BookingDate"]).ToString();
        mobile.Text = reader["mobile"].ToString();
        booking.Text = "&#8377 " + reader["BookingCharge"].ToString();
        Total.Text = "&#8377 " + reader["Amount"].ToString();
        ticket.Text = "&#8377 " + (Convert.ToInt32(reader["Amount"].ToString()) - Convert.ToInt32(reader["BookingCharge"].ToString())).ToString();
        fromloc.Text = reader["FromLocation"].ToString();
        toloc.Text = reader["ToLocation"].ToString();
        classtype.Text = reader["ClassType"].ToString();
        dateofjourney.Text = Convert.ToDateTime(reader["DepartureDate"]).ToShortDateString() + " " + reader["DepartureTime"].ToString();
        reader.Close();
    }
}