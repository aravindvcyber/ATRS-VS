﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Locations : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void cancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("insert_locations", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@locname", SqlDbType.VarChar, 30);
        sqlParam.Value = locationname.Value;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception inserting location. " + ex.Message);
        }
        finally
        {
            conn.Close();
        }
        Response.Redirect("admin.aspx");
    }
}