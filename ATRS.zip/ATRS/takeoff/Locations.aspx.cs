﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Locations : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "Locations Inserter";
        ((Admin)this.Master).Headmsg = "Successfully opened!";  
    }

    protected void cancel_Click(object sender, EventArgs e)
    {

        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {

        //ControlCollection cc = new ControlCollection(this.Page.Form);
        //foreach (Control c in this.Page.Form.Controls)
        //{
        //    foreach (Control c2 in c.Controls)
        //    {
        //        foreach (Control c4  in c2.Controls)
        //        {
                  
        //                if (c4 is Label)
        //                {
        //                    Label lb = (Label)c4;
        //                    lb.Text = "Traversed";
        //                }
                    
        //        }
        //    }
        //}
     



        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("insert_locations", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@locname", SqlDbType.VarChar, 30);
        sqlParam.Value = locationname.Value;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {

            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception inserting location. " + ex.Message);
        }
        finally
        {
            conn.Close();
        }

        
        //foreach (Control c in this.Page.Form.Controls)
        //{
        //    foreach (Control c2 in c.Controls)
        //    {
        //        if (c2 is Label && c2.ID == "sms")
        //        {
        //            Label lb = (Label)c2;
        //            lb.Text = "traverse";
        //        }
        //    }
        //}
        //((Admin)this.Master).ChangeSms("method");
        //((Admin)this.Master).Sms = "property";
        ((Admin)this.Master).SMSmsg = "Location "+locationname.Value+" added...";
        ((Admin)this.Master).Headmsg = "Successfull!";
        
        Response.Redirect("admin.aspx");
    }
}