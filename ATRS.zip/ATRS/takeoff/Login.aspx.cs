﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ARS.Entity;
using ARS.Business;

public partial class Login : System.Web.UI.Page
{
    EntLogin EntL = new EntLogin();
    BusLogin BusL = new BusLogin();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
            UserName.Value = Request.QueryString["uname"];

        //Response.Write("<script type='javascript'>Materialize.toast('I am a toast', 4000,'',function(){alert('Your toast was dismissed')})</script>");
    }
    protected void Logon_Click(object sender, EventArgs e)
    {
        //try
        //{
        EntL.UserName = UserName.Value;
        EntL.Password = password.Value;
        if (Admin.Checked)
        {
            //if (checkAdmin(UserName.Value))
            //{
            if(BusL.checkAdmin(EntL))
            {

                if (BusL.AuthenticateAdmin(EntL))
                {
                    //AuthenticateAdmin(UserName.Value, password.Value);
                    Response.Redirect("admin.aspx");
                }
            }
            else
            {
                Msg.Text = "You are not Admin. Please contact administrator";
            }
        }
        else
        {
            if (BusL.AuthenticateUser(EntL))
            {
                AuthenticateUser(UserName.Value, password.Value);
                Response.Redirect("user.aspx");
            }

            //AuthenticateUser(UserName.Value, password.Value);


        }

        //if ((UserName.Value == "aravindv") &&
        //        (password.Value == "admin123"))
        //{
        //    FormsAuthentication.RedirectFromLoginPage
        //       (UserName.Value,Persist.Checked);
        //}
        //else
        //{
        //    Msg.Text = "Invalid credentials. Please try again.";
        //}
    }

    //private bool checkAdmin(string username)
    //{
    //    Boolean admin = false;
    //    string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
    //    using (SqlConnection con = new SqlConnection(CS))
    //    {
    //        //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
    //        SqlCommand cmd = new SqlCommand("checkAdmin", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        SqlParameter paramUsername = new SqlParameter("@UserName", username);
    //        cmd.Parameters.Add(paramUsername);
    //        con.Open();
    //        SqlDataReader rdr = cmd.ExecuteReader();
    //        while (rdr.Read())
    //        {
    //            admin = Convert.ToBoolean(rdr["isadmin"].ToString());
    //        }
    //    }

    //    return admin;
    //}

    private void AuthenticateAdmin(string username, string password)
    {
        // ConfigurationManager class is in System.Configuration namespace
        string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
        // SqlConnection is in System.Data.SqlClient namespace
        using (SqlConnection con = new SqlConnection(CS))
        {
            //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
            SqlCommand cmd = new SqlCommand("spAuthenticateUser", con);
            cmd.CommandType = CommandType.StoredProcedure;

            //Formsauthentication is in system.web.security
            string saltAndPwd = String.Concat(password, getSalt(username));
            string encryptedpassword = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");

            //sqlparameter is in System.Data namespace
            SqlParameter paramUsername = new SqlParameter("@UserName", username);
            SqlParameter paramPassword = new SqlParameter("@Password", encryptedpassword);

            cmd.Parameters.Add(paramUsername);
            cmd.Parameters.Add(paramPassword);

            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                int RetryAttempts = Convert.ToInt32(rdr["RetryAttempts"]);
                if (Convert.ToBoolean(rdr["AccountLocked"]))
                {
                    Msg.Text = "Account locked. Please contact administrator";
                }
                else if (RetryAttempts > 0)
                {
                    int AttemptsLeft = (4 - RetryAttempts);
                    Msg.Text = "Invalid user name and/or password. " +
                        AttemptsLeft.ToString() + "attempt(s) left";
                }
                else
                    if (Convert.ToBoolean(rdr["Authenticated"]))
                    {
                        //Session["uname"] = UserName.Value;
                        generatesessionvariables(UserName.Value);
                        Response.Write("<script type='javascript'>alert('Logged in Successfully')</script>");
                        FormsAuthentication.RedirectFromLoginPage(UserName.Value, Persist.Checked);
                    }
                //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
            }
        }
    }
    //protected static string getPasswordHash(string pwd, string salt)
    //{
    //    string saltAndPwd = String.Concat(pwd, salt);
    //    string hashedPwd = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
    //    //hashedPwd = String.Concat(hashedPwd, salt);
    //    return hashedPwd;
    //}
    //protected static string getSalt(string username)
    //{
    //    string salt = "";
    //    string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
    //    using (SqlConnection con = new SqlConnection(CS))
    //    {
    //        //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
    //        SqlCommand cmd = new SqlCommand("getsalt", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        SqlParameter paramUsername = new SqlParameter("@UserName", username);
    //        cmd.Parameters.Add(paramUsername);
    //        con.Open();
    //        SqlDataReader rdr = cmd.ExecuteReader();
    //        while (rdr.Read())
    //        {
    //            salt = rdr["salt"].ToString();
    //        }
    //    }

    //    return salt;
    //}
    private void AuthenticateUser(string username, string password)
    {
        // ConfigurationManager class is in System.Configuration namespace
        string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
        // SqlConnection is in System.Data.SqlClient namespace
        using (SqlConnection con = new SqlConnection(CS))
        {
            //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
            SqlCommand cmd = new SqlCommand("spAuthenticateUser", con);
            cmd.CommandType = CommandType.StoredProcedure;

            //Formsauthentication is in system.web.security
            string saltAndPwd = String.Concat(password, getSalt(username));
            string encryptedpassword = FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");

            //sqlparameter is in System.Data namespace
            SqlParameter paramUsername = new SqlParameter("@UserName", username);
            SqlParameter paramPassword = new SqlParameter("@Password", encryptedpassword);

            cmd.Parameters.Add(paramUsername);
            cmd.Parameters.Add(paramPassword);

            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                int RetryAttempts = Convert.ToInt32(rdr["RetryAttempts"]);
                if (Convert.ToBoolean(rdr["AccountLocked"]))
                {
                    Msg.Text = "Account locked. Please contact administrator";
                }
                else if (RetryAttempts > 0)
                {
                    int AttemptsLeft = (4 - RetryAttempts);
                    Msg.Text = "Invalid user name and/or password. " +
                        AttemptsLeft.ToString() + "attempt(s) left";
                }
                else
                    if (Convert.ToBoolean(rdr["Authenticated"]))
                    {
                        generatesessionvariables(UserName.Value);
                        //Session["uname"] = UserName.Value;

                        Response.Write("<script type='javascript'>alert('Logged in Successfully')</script>");
                        FormsAuthentication.RedirectFromLoginPage(UserName.Value, Persist.Checked);
                    }
                //Response.Write("<script type='javascript'>alert('inserted successfully')</script>");
            }
        }
    }

    private void generatesessionvariables(string UserName)
    {
        string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            //SqlCommand cmd = new SqlCommand("select UserName,password,RetryAttempts from logins where username='" + username + "' and password='" + password + "'", con);
            SqlCommand cmd = new SqlCommand("sessionvariables", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar, 15);
            sqlParam.Value = UserName;
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                Session["uname"] = UserName;
                Session["cid"] = rdr["customerid"].ToString();
                Session["fname"] = rdr["firstname"].ToString();
                Session["lname"] = rdr["lastname"].ToString();
                Session["wallet"] = rdr["wallet"].ToString();
                Session["isadmin"] = rdr["isadmin"].ToString();
            }
        }
    }
}
