﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ARS.Entity;
using ARS.Business;
using LoggingSample;

/// <summary>
///Login Page.
/// </summary>
public partial class Login : System.Web.UI.Page
{
    EntLogin EntL = new EntLogin();
    BusLogin BusL = new BusLogin();
    /// <summary>
    /// Login.Page_Load.
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            var sessionsToRemove = Session.Keys.Cast<string>().Where(key => key != "randomStr").ToList();
            foreach (var key in sessionsToRemove)
            {
                Session.Remove(key);
            }
        }
        else
        {
            ((MasterPage)this.Master).displayMessage("<p style='color:navy;'>Session Terminated</p> Due to your Action<br/>"+Session["uname"].ToString());
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Session Terminated due to your Action')", true);
            var sessionsToRemove = Session.Keys.Cast<string>().Where(key => key != "randomStr").ToList();
            foreach (var key in sessionsToRemove)
            {
                Session.Remove(key);
            }
        }
        Response.Cookies["uname"].Expires = DateTime.Now;
        if (Request.QueryString.Count > 0)
            UserName.Value = Request.QueryString["uname"];
       

    }
    protected void Logon_Click(object sender, EventArgs e)
    {

        if (Session["randomStr"] != null)
        {
            if (Page.IsValid && (captcha.Value.ToString() == Session["randomStr"].ToString()))
            {
                Logging.LogInfo("Processing new Login Request for username : "+UserName.Value, true);
                EntL.UserName = UserName.Value;
                EntL.Password = password.Value;
                EntLogin SessVar = new EntLogin();
                if (Admin.Checked)
                {
                    
                    if (BusL.checkAdmin(EntL))
                    {
                        Dictionary<string, string> AuthAdmin = BusL.AuthenticateAdmin(EntL, out SessVar);
                        bool auth = Convert.ToBoolean(Convert.ToInt32(AuthAdmin["Authenticated"].ToString()));
                        if (auth)
                        {

                         
                            CreateSess(SessVar);
                            LoggingSample.Logging.LogInfo("Login Successfull for Admin: "+Session["uname"].ToString(),true);
                            ((MasterPage)this.Master).displayMessage("<p style='color:navy;'>Redirecting... to Admin Page</p> <br/>" + "Login Successfull for Admin: " + Session["uname"].ToString());
                            Response.Redirect("admin.aspx");
                        }
                        else
                        {
                            Msg.Text = AuthAdmin["Msg"].ToString();
                        }
                    }
                    else
                    {
                        LoggingSample.Logging.LogInfo("User " + UserName.Value + " Trying to login as admin", true);


                        Msg.Text = "You are not Admin. Please contact administrator or Try to login as user";
                        ((MasterPage)this.Master).displayMessage("<p style='color:navy;'>You are not Admin.</p> <br/>" + "Please contact administrator<br/> or Try to login as user");
                        
                    }
                }
                else
                {

                    Dictionary<string, string> AuthUser = BusL.AuthenticateUser(EntL, out SessVar);
                    bool auth = Convert.ToBoolean(Convert.ToInt32(AuthUser["Authenticated"].ToString()));
                    if (auth)
                    {
                        CreateSess(SessVar);
                        LoggingSample.Logging.LogInfo("Login Successfull for User: "+Session["uname"].ToString(),true);
                        ((MasterPage)this.Master).displayMessage("<p style='color:navy;'>Redirecting... to User Page</p> <br/>" + "Login Successfull for User: "+Session["uname"].ToString());
                      
                        Response.Redirect("user.aspx");
                    }
                    else
                    {
                        Msg.Text = AuthUser["Msg"].ToString();
                    }

                    //AuthenticateUser(UserName.Value, password.Value);

                }

            }
            else
            {

                Label1.Text = "Re-enter Captcha-digits...";
                //((MasterPage)this.Master).displayMessage("<p style='color:navy;'>Re-enter Captcha-digits...</p> <br/>" + "We Regret your inconvenience..");
            }


          
        }
        else
        {
            Msg.Text = "Sorry Captcha Expired";
            //((MasterPage)this.Master).displayMessage("<p style='color:navy;'>Sorry Captcha Expired.</p> <br/>" + "We Regret your inconvenience..");
        }
    }

    private void CreateSess(EntLogin SessVar)
    {
        Session["uname"] = SessVar.Uname;
        Session["cid"] = SessVar.Cid;
        Session["fname"] = SessVar.Fname;
        Session["lname"] = SessVar.Lname;
        Session["wallet"] = SessVar.Wallet;
        Session["isadmin"] = SessVar.Isadmin;
        if (Convert.ToBoolean(Session["isadmin"].ToString()))
        {
               Session["AdminID"]=Session["cid"].ToString();
        }
        else
        {
            Session["UserID"] = Session["cid"].ToString();
        }
    }

    

    
}
