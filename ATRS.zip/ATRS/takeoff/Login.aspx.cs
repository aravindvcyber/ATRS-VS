﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ARS.Entity;
using ARS.Business;

/// <summary>
///Login Page.
/// </summary>
public partial class Login : System.Web.UI.Page
{
    EntLogin EntL = new EntLogin();
    BusLogin BusL = new BusLogin();
    /// <summary>
    /// Login.Page_Load.
    /// </summary>
    protected void Page_Load(object sender, EventArgs e)
    {
        //string cap=Session["randomStr"].ToString();
        //Session.RemoveAll();
        //Session["randomStr"] = cap;
       
        if (Request.QueryString.Count > 0)
            UserName.Value = Request.QueryString["uname"];

    }
    protected void Logon_Click(object sender, EventArgs e)
    {
      
        if (Request.Cookies.Count > 0)
        {
            if (Page.IsValid && (captcha.Value.ToString() == Session["randomStr"].ToString()))
            {
                // The Code to insert data
                //try
                //{
                EntL.UserName = UserName.Value;
                EntL.Password = password.Value;
                EntLogin SessVar = new EntLogin();
                if (Admin.Checked)
                {
                    //if (checkAdmin(UserName.Value))
                    //{
                    if (BusL.checkAdmin(EntL))
                    {
                        Dictionary<string, string> AuthAdmin = BusL.AuthenticateAdmin(EntL, out SessVar);
                        bool auth = Convert.ToBoolean(Convert.ToInt32(AuthAdmin["Authenticated"].ToString()));
                        if (auth)
                        {

                            //AuthenticateAdmin(UserName.Value, password.Value);
                            CreateSess(SessVar);
                            Response.Redirect("admin.aspx");
                        }
                        else
                        {
                            Msg.Text = AuthAdmin["Msg"].ToString();
                        }
                    }
                    else
                    {
                        Msg.Text = "You are not Admin. Please contact administrator";
                    }
                }
                else
                {

                    Dictionary<string, string> AuthUser = BusL.AuthenticateUser(EntL, out SessVar);
                    bool auth = Convert.ToBoolean(Convert.ToInt32(AuthUser["Authenticated"].ToString()));
                    if (auth)
                    {
                        CreateSess(SessVar);
                        //AuthenticateUser(UserName.Value, password.Value);
                        Response.Redirect("user.aspx");
                    }
                    else
                    {
                        Msg.Text = AuthUser["Msg"].ToString();
                    }

                    //AuthenticateUser(UserName.Value, password.Value);

                }

            }
            else
            {
                Label1.Text = "Re-enter Captcha-digits...";
            }


          
        }
        else
        {
            Response.Redirect("expired.aspx");
        }
    }

    private void CreateSess(EntLogin SessVar)
    {
        Session["uname"] = SessVar.Uname;
        Session["cid"] = SessVar.Cid;
        Session["fname"] = SessVar.Fname;
        Session["lname"] = SessVar.Lname;
        Session["wallet"] = SessVar.Wallet;
        Session["isadmin"] = SessVar.Isadmin;
        if (Convert.ToBoolean(Session["isadmin"].ToString()))
        {
               Session["AdminID"]=Session["cid"].ToString();
        }
        else
        {
            Session["UserID"] = Session["cid"].ToString();
        }
    }

    

    
}
