﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using LoggingSample;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;

public partial class MasterPage : System.Web.UI.MasterPage
{
    string user = "";
    
    
    protected void Page_Load(object sender, EventArgs e)
    {
        List<HttpCookie> allCookies = new List<HttpCookie>(); foreach (string key in Request.Cookies.Keys)
        {

            allCookies.Add(Request.Cookies[key]);

        }

        List<HttpCookie> sessionCookies = allCookies.Where(c => c.Name.Contains("winID__") && c.Name != "winID__").ToList(); 
        HttpCookie currentSession = sessionCookies.FirstOrDefault(c => c.Value == "1"); 
        int expTime = 1; 
        foreach (HttpCookie c in sessionCookies)
        {

            if (Response.Cookies[c.Name] != null)
            {

                Response.Cookies[c.Name].Value ="0";
                Response.Cookies[c.Name].Expires = DateTime.Now.AddHours(expTime);
            }

            else
            {

                HttpCookie ck = new HttpCookie(c.Name, "0");
                ck.Expires =DateTime.Now.AddHours(expTime);
                Response.Cookies.Add(ck);

            }

        }

        if (currentSession == null)
        {

            uxWinID.Text =Guid.NewGuid().ToString(); string cookieName = "winID__" + uxWinID.Text; HttpCookie ck = new HttpCookie(cookieName, "0");
            ck.Expires =DateTime.Now.AddHours(2);
            Response.Cookies.Add(ck);

        }

        else
        {

            uxWinID.Text = currentSession.Name.Replace("winID__", "").Trim();
        }
        
       
        try
        {
        if (Session["uname"] == null)
        {
            menu.InnerHtml= "Menu<i class='"+"material-icons right'"+">menu</i>";
            
            signin.InnerText = "Login";
            signup.InnerText = "Register";
            logout.Text = "login";
            user = "Guest";
            svg.Attributes["data-jdenticon-hash"] = Hash(user);
          
            
            uname.Text = "Guest";
        }
        else
        {
            menu.InnerHtml= Session["uname"].ToString()+"<i class='"+"material-icons right'"+">menu</i>";
            signin.InnerText = "";
            signup.InnerText = "";
            logout.Text = "logout";
            user = Session["uname"].ToString();
            svg.Attributes["data-jdenticon-hash"] = Hash(user);
            uname.Text = Session["fname"].ToString() + " " + Session["lname"].ToString();
        }


    
            //HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            //HttpContext.Current.Response.Cache.SetNoServerCaching();
            //HttpContext.Current.Response.Cache.SetNoStore();
            //{get data from database by passing userid}
            ////to check if it logs the error throw an argument exception
            //throw new ArgumentException("generated error");
            //on success Log the activity
            //if (Session["uname"] == null)
            //{
               
            //}
            //else
            //{
                
            //}
            Logging.LogInfo("Get successful for userid : " + user, true);
            //uname.Text = if(Session["uname"].ToString()==null)? Request.Cookies["uname"].ToString():Session["uname"].ToString();
            //wallet.Text = Session["wallet"].ToString();
            getwallet();
        }
        catch (Exception ex)
        {
            //on error log the exception
            Logging.LogException(ex, "Error in Session Values");
        }

    }

    private void getwallet()
    {
        string custid = Session["cid"].ToString();
        //custid = Request.Cookies["customerid"].Value;
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select BookingId from Booking";
        SqlConnection myConnection = new SqlConnection(ConnectString);
        SqlCommand storedProcCommand = new SqlCommand("getwallet", myConnection);
        storedProcCommand.CommandType = CommandType.StoredProcedure;
        //storedProcCommand.Parameters.Add("@customerid", Request.Cookies["customerid"].Value);
        SqlParameter parameter = new SqlParameter("@customerid", SqlDbType.VarChar, 6);
        //Set the parameter direction as output
        //parameter.Direction = ParameterDirection.Output;
        storedProcCommand.Parameters.Add(parameter);
        parameter.Value = custid;
        SqlDataAdapter sqlAdapter = new SqlDataAdapter(storedProcCommand);
        DataSet ds = new DataSet();
        sqlAdapter.Fill(ds, "wallet");
        //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select BookingId from Booking";

        //SqlConnection myConnection = new SqlConnection(ConnectString);
        //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
        //DataSet ds = new DataSet();
        //myCommand.Fill(ds, "BookingId");

        wallet.Text = ds.Tables[0].Rows[0][0].ToString();
       
      
    }
    protected void logout_Click(object sender, EventArgs e)
    {
        //Session.RemoveAll;
        Session.RemoveAll(); 
        uname.Text = "User";
        wallet.Text = "";
        logout.Text = "login";
        if (logout.Text == "logout")
            Response.Redirect("home.aspx");
        else
            Response.Redirect("login.aspx");
    }
    public string Hash(string input)
    {
        using (SHA1Managed sha1 = new SHA1Managed())
        {
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(input));
            var sb = new StringBuilder(hash.Length * 2);

            foreach (byte b in hash)
            {
                // can be "x2" if you want lowercase
                sb.Append(b.ToString("X2"));
            }

            return sb.ToString();
        }
    }
   
}
