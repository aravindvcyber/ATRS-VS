﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Web.Security;
using System.Data;
using System.Configuration;
using ARS.Business;
using ARS.Entity;

public partial class Register : System.Web.UI.Page
{
    EntRegister EntR = new EntRegister();
    BusRegister BusR = new BusRegister();
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select SecurityQuestions from Security";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "SecurityQuestions");

            security.DataSource = ds;
            security.DataTextField = "SecurityQuestions";
            security.DataValueField = "SecurityQuestions";
            security.DataBind();

        }
        if (Request.Cookies["uname"].Value != null)
        {
            UserName.Value = Request.Cookies["uname"].Value;
        }

        else
        {
            Response.Redirect("newusername.aspx");
        }

    }
    
    //protected void StoreAccountDetails(string userName,string passwordHash,string salt)
    //{


    //    SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

    //    string newcustid = getnewcustid();


    //    SqlCommand cmd = new SqlCommand("RegisterUserDetails", conn);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    SqlParameter sqlParam = null;
    //    sqlParam = cmd.Parameters.Add("@CustomerId", SqlDbType.VarChar, 6);
    //    sqlParam.Value = newcustid;
    //    sqlParam = cmd.Parameters.Add("@CustomerName", SqlDbType.VarChar, 25);
    //    sqlParam.Value = first_name.Value + " "+last_name.Value;
    //    sqlParam = cmd.Parameters.Add("@EmailId ", SqlDbType.VarChar, 50);
    //    sqlParam.Value = this.Request.Form.Get("email");
    //    sqlParam = cmd.Parameters.Add("@SecurityQuestion", SqlDbType.VarChar, 50);
    //    sqlParam.Value = security.Value;
    //     sqlParam = cmd.Parameters.Add("@mobile", SqlDbType.VarChar, 15);
    //    sqlParam.Value = mobile.Value; 
    //    sqlParam = cmd.Parameters.Add("@SecurityAnswer", SqlDbType.VarChar, 50);
    //    sqlParam.Value = securityans.Value; 
    //    sqlParam = cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 10);

    //    if (this.Request.Form.Get("test1") == "true")
    //    sqlParam.Value = "Male" ; 
    //    else
    //    sqlParam.Value = "Female"; 
    //    sqlParam = cmd.Parameters.Add("@DOB", SqlDbType.Date);
    //    sqlParam.Value = this.Request.Form.Get("DOB");
    //    try
    //    {
    //        conn.Open();
    //        cmd.ExecuteNonQuery();
    //    }
    //    catch (Exception ex)
    //    {
    //        // Code to check for primary key violation (duplicate account name)
    //        // or other database errors omitted for clarity
    //        throw new Exception("Exception adding Customer Details " + ex.Message);
    //    }
    //    finally
    //    {
    //        conn.Close();
    //    }
    //    cmd = new SqlCommand("RegisterUser", conn);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    sqlParam = null;
    //    sqlParam = cmd.Parameters.Add("@id", SqlDbType.VarChar, 6);
    //    sqlParam.Value = newcustid;
    //    sqlParam = cmd.Parameters.Add("@userName", SqlDbType.VarChar,15);
    //    sqlParam.Value = userName;
    //    sqlParam = cmd.Parameters.Add("@passwordHash ", SqlDbType.VarChar,40);
    //    sqlParam.Value = passwordHash;
    //    sqlParam = cmd.Parameters.Add("@salt ", SqlDbType.VarChar, 40);
    //    sqlParam.Value = salt;
    //    try
    //    {
    //        conn.Open();
    //        cmd.ExecuteNonQuery();
    //    }
    //    catch (Exception ex)
    //    {
    //        // Code to check for primary key violation (duplicate account name)
    //        // or other database errors omitted for clarity
    //        throw new Exception("Exception adding account. " + ex.Message);
    //    }
    //    finally
    //    {
    //        conn.Close();
    //    }
    //}
    //protected static string getnewcustid()
    //{
    //    string custid = "";
    //    string CS = ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString;
    //    using (SqlConnection con = new SqlConnection(CS))
    //    {
           
    //        SqlCommand cmd = new SqlCommand("gen_customerid", con);
    //        cmd.CommandType = CommandType.StoredProcedure;
           
    //        con.Open();
    //        SqlDataReader rdr = cmd.ExecuteReader();
    //        while (rdr.Read())
    //        {
    //            custid = rdr["customerid"].ToString();
    //        }
    //    }
    //    return custid;
    //}
    protected static string CreateSalt(int size)
    {
        // Generate a cryptographic random number using the cryptographic
        // service provider
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] buff = new byte[size];
        rng.GetBytes(buff);
        // Return a Base64 string representation of the random number
        return Convert.ToBase64String(buff);
    }
    protected static string CreatePasswordHash(string pwd, string salt)
    {
        string saltAndPwd = String.Concat(pwd, salt);
        string hashedPwd =FormsAuthentication.HashPasswordForStoringInConfigFile(saltAndPwd, "SHA1");
        //hashedPwd = String.Concat(hashedPwd, salt);
        return hashedPwd;
    }


    protected void registerbtn_Click(object sender, EventArgs e)
    {
        int saltSize = 5;
        string salt = CreateSalt(saltSize);
        string passwordHash = CreatePasswordHash(password.Value, salt);
        try
        {
            EntR.UserName = UserName.Value;
            EntR.Salt = salt;
            EntR.PasswordHash = passwordHash;
            if (this.Request.Form.Get("test1") == "true")
                EntR.Gender = "Male";
            else
                EntR.Gender = "Female";
            EntR.DOB=Convert.ToDateTime(this.Request.Form.Get("DOB"));
            EntR.EmailId=this.Request.Form.Get("email");
            EntR.Mobile=mobile.Value;
            EntR.CustomerName = first_name.Value + " " + last_name.Value;
            EntR.SecurityQuestion=security.Value;
            EntR.SecurityAnswer = securityans.Value;
            BusR.StoreAccountDetails(EntR);
            //StoreAccountDetails(UserName.Value, passwordHash, salt);
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
       
        Response.Write("<script type='javascript'>alert('inserted successfully')</script>"); 
        Response.Redirect("Login.aspx?uname="+UserName.Value);
    }


}