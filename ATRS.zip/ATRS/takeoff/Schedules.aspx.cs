﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Schedules : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select FlightId from Flight_Master";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "FlightId");

            flightid.DataSource = ds;
            flightid.DataTextField = "FlightId";
            flightid.DataValueField = "FlightId";
            flightid.DataBind();
            QueryString = "select Location_Name from Location_Master";

            myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
            ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

            L1.DataSource = ds;
            L1.DataTextField = "Location_Name";
            L1.DataValueField = "Location_Name";
            L1.DataBind();
            QueryString = "select Location_Name from Location_Master ";

            myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
            ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

            L2.DataSource = ds;
            L2.DataTextField = "Location_Name";
            L2.DataValueField = "Location_Name";
            L2.DataBind();

        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("insert_scheduledetails", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@flightid", SqlDbType.VarChar, 20);
        sqlParam.Value = flightid.Value;
        sqlParam = cmd.Parameters.Add("@from", SqlDbType.VarChar, 20);
        sqlParam.Value = L1.Value;
        sqlParam = cmd.Parameters.Add("@to", SqlDbType.VarChar, 20);
        sqlParam.Value = L2.Value;
        sqlParam = cmd.Parameters.Add("@departuredate", SqlDbType.Date);
        sqlParam.Value = Convert.ToDateTime(this.Request.Form.Get("departuredate"));
        //sqlParam = cmd.Parameters.Add("@duration", SqlDbType.Time);
        //sqlParam.Value = this.Request.Form.Get("duration");
        sqlParam = cmd.Parameters.Add("@arrivaltime", SqlDbType.Time);
        string arr = this.Request.Form.Get("arrivaltime");
        sqlParam.Value = TimeSpan.Parse(arr);
        sqlParam = cmd.Parameters.Add("@departuretime", SqlDbType.Time);
       string dep = this.Request.Form.Get("departuretime");
        sqlParam.Value = TimeSpan.Parse(dep);

        TimeSpan duration = DateTime.Parse(arr).Subtract(DateTime.Parse(dep));
        sqlParam = cmd.Parameters.Add("@duration", SqlDbType.Time);
        sqlParam.Value = duration;

        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception inserting schedule. " + ex.Message);
        }
        finally
        {
            conn.Close();
        }
        Response.Redirect("admin.aspx");
       
    }
}