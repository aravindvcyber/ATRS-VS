﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Schedules : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select FlightId from Flight_Master";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "FlightId");

            flightid.DataSource = ds;
            flightid.DataTextField = "FlightId";
            flightid.DataValueField = "FlightId";
            flightid.DataBind();
            QueryString = "select Location_Name from Location_Master";

            myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
            ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

            L1.DataSource = ds;
            L1.DataTextField = "Location_Name";
            L1.DataValueField = "Location_Name";
            L1.DataBind();
            QueryString = "select Location_Name from Location_Master ";

            myConnection = new SqlConnection(ConnectString);
            myCommand = new SqlDataAdapter(QueryString, myConnection);
            ds = new DataSet();
            myCommand.Fill(ds, "Location_Name");

            L2.DataSource = ds;
            L2.DataTextField = "Location_Name";
            L2.DataValueField = "Location_Name";
            L2.DataBind();

        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {

    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }
}