﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ARS.Business;
using ARS.Entity;
using System.Data;

namespace takeoff
{
    public partial class TopUp : System.Web.UI.Page
    {
        EntTopUp EntTU = new EntTopUp();
        BusTopUp BusTU = new BusTopUp();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((Admin)this.Master).SMSmsg = "TopUp Users' Wallet";
                ((Admin)this.Master).Headmsg = "Successfully opened!";
                DataSet ds = new DataSet();
                ds = BusTU.fetchUsers();

                username.DataSource = ds;
                username.DataTextField = "username";
                username.DataValueField = "username";
                username.DataBind();
            }
        }
        protected void cancel_Click(object sender, EventArgs e)
        {

            Response.Redirect("admin.aspx");
        }

        protected void confirm_Click(object sender, EventArgs e)
        {

            try
            {
                EntTU.UserName = username.Value;
                EntTU.Amount = Convert.ToInt32(amount.Value);
                if (BusTU.TopUpWallet(EntTU))
                {
                    ControlCollection cc = new ControlCollection(this.Page.Form);
                    foreach (Control c in this.Page.Form.Controls)
                    {
                        foreach (Control c2 in c.Controls)
                        {
                            foreach (Control c4 in c2.Controls)
                            {

                                if (c4 is Label)
                                {
                                    Label lb = (Label)c4;
                                    lb.Text = "Wallet of UserName " + username.Value + "is TopUp with Amount Rs."+amount.Value + "...";
                                }
                                else if (c4.ID == "heading")
                                {

                                }

                            }
                        }
                    }
                }
                else
                {
                }

            }
            catch (Exception ex)
            {

                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception in TopUp of User's Wallet. " + ex.Message);
            }
            finally
            {
                amount.Value = "";

            }

            //Response.Redirect("Locations.aspx");
        }
    }
}