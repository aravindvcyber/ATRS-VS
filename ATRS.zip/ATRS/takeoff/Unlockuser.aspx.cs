﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Unlockuser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            string QueryString = "select username from logins where islocked='true'";

            SqlConnection myConnection = new SqlConnection(ConnectString);
            SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, myConnection);
            DataSet ds = new DataSet();
            myCommand.Fill(ds, "username");

            username.DataSource = ds;
            username.DataTextField = "username";
            username.DataValueField = "username";
            username.DataBind();
        }
    }

    protected void cancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("admin.aspx");
    }

    protected void confirm_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");

        SqlCommand cmd = new SqlCommand("unlockuser", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@username", SqlDbType.VarChar, 15);
        sqlParam.Value = username.Value;
        try
        {
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            // Code to check for primary key violation (duplicate account name)
            // or other database errors omitted for clarity
            throw new Exception("Exception unlocking account. " + ex.Message);
        }
        finally
        {
            conn.Close();
        }
        Response.Redirect("admin.aspx");
    }
}