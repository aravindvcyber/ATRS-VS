﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User : System.Web.UI.MasterPage
{
    public string SMSmsg = "Hi";
    public string Headmsg = "Successfull!";
    protected void Page_Load(object sender, EventArgs e)
    {
        sms.Text = SMSmsg;
        heading.InnerText = Headmsg;
        if (Session["uname"] == null)
        {
            
            Response.Redirect("login.aspx");
        }
        else
        {

            SMSmsg += Session["fname"];
        }

    }
    //protected void Page_Prerender(object sender, EventArgs e)
    //{


    //}
    //public void ChangeSms(string label)
    //{
    //    sms.Text = label;
    //}
    //public string Sms
    //{
    //    set
    //    {
    //        sms.Text = value;
    //    }
    //    get
    //    {
    //        return sms.ToString();
    //    }

    //}
}
