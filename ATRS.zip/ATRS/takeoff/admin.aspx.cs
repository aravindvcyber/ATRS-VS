﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["uname"] != null)
        //{
        //    if (Session["isadmin"].ToString() != "true")
        //        Response.Redirect("login.aspx");

        //}


        if (Session["uname"] == null)
        {

            string myscript = @"<script language='javascript'>alert('hello world');</script>";
           Page.ClientScript.RegisterClientScriptBlock("".GetType(), "s", myscript);
           Response.Redirect("login.aspx", false);
            //ClientScriptManager cs = Page.ClientScript;
            //string message = "You need to Login\n to access this page";
            //string url = "Login.aspx";
            //string script = "window.onload = function(){ alert('";
            //script += message;
            //script += "');";
            //script += "window.location = '";
            //script += url;
            //script += "'; }";
            //cs.RegisterStartupScript(this.GetType(), "Redirect", script, true);

        }
        else
        {
            //if (Session["isadmin"].ToString() != "True")
            //    Response.Redirect("user.aspx");
        }
    }
}