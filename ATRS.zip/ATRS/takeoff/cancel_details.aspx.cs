﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Entity;
using ARS.Business;

public partial class cancel_details : System.Web.UI.Page
{
    EntCancel_details EntCD = new EntCancel_details();
    BusCancel_details BusCD = new BusCancel_details();
    protected void Page_Load(object sender, EventArgs e)
    {
        ((User)this.Master).SMSmsg = "Are you sure you want to cancel booking id " + Request.Cookies["bookingid"].Value;
        ((User)this.Master).Headmsg = "Successfully opened!";
        if (!IsPostBack)
        {
            EntCD.CustomerId = Session["cid"].ToString();
            EntCD.BookingId = Request.Cookies["bookingid"].Value;

            Dictionary<string, string> candet = new Dictionary<string, string>();

            candet = BusCD.GetCanceldetails(EntCD);

           

            BookingId.Value = candet["bid"].ToString();
            BookingDate.Value = Convert.ToDateTime(candet["bdate"].ToString()).ToShortDateString();
            flightname.Value = candet["Aname"].ToString();
            JourneyDate.Value = Convert.ToDateTime(candet["depdate"].ToString()).ToShortDateString();
            From.Value = candet["flocation"].ToString();
            To.Value = candet["tlocation"].ToString();
            NoofSeats.Value = candet["seats"].ToString();
            ClassType.Value = candet["classtype"].ToString();
            int totalamount = Convert.ToInt32(candet["amount"].ToString());


           
         
           
            double days;
            double cancelamount;
            double refund;
            days = (Convert.ToDateTime(Convert.ToDateTime(JourneyDate.Value).ToShortDateString())-Convert.ToDateTime(DateTime.Now.ToShortDateString()) ).TotalDays;
            if (days > 30)
            {
                cancelamount = totalamount * 0.10;
                refund = totalamount - cancelamount;
            }
            else if (days <= 30 && days > 10)
            {
                cancelamount = totalamount * 0.25;
                refund = totalamount - cancelamount;
            }
            else if (days <= 10 && days > 0)
            {
                cancelamount = totalamount * 0.50;
                refund = totalamount - cancelamount;
            }
            else
            {
                cancelamount = 0;
                refund = 0;
            }


           

            CancellationCharge.Value=((int)cancelamount).ToString();
            RefundableAmount.Value=((int)refund).ToString();

          
        }
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
          if (Page.IsValid && (captcha.Value.ToString() ==
                            Session["randomStr"].ToString()))
        {
        EntCD.CustomerId = Session["cid"].ToString();
        EntCD.BookingId = BookingId.Value;
        EntCD.Remarks = Remarks.Value;
        EntCD.CancelCharge = Convert.ToInt32(CancellationCharge.Value);
        EntCD.Refund = Convert.ToInt32(RefundableAmount.Value);
        BusCD.cancelTickets(EntCD);
        Response.Redirect("cancel_invoice.aspx");
        }
          else
          {
              Label1.Text = "Please re-enter the Captcha-digits correctly...";
          }
   


        
    }

   

    protected void Back_Click(object sender, EventArgs e)
    {
        
        Response.Redirect("cancel_page.aspx");
    }
}