﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
        Response.Cookies["Bookingid"].Value = this.Request.Form.Get("BookingId");
        Response.Cookies["Remarks"].Value = this.Request.Form.Get("Remarks");
        cancelTickets(this.Request.Form.Get("BookingId"));
        Response.Redirect("invoice.aspx");
    }

    private void cancelTickets(string bid)
    {
        throw new NotImplementedException();
    }

    protected void Back_Click(object sender, EventArgs e)
    {
        Response.Redirect("cancel_page.aspx");
    }
}