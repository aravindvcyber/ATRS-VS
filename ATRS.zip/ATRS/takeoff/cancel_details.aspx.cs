﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
            //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

            SqlConnection con = new SqlConnection(ConnectString);

            //string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
            //SqlCommand com = new SqlCommand(str, con);
            //SqlDataReader reader = com.ExecuteReader();
            SqlCommand cmd = new SqlCommand("cancel_details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter sqlParam = null;
            sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 10);
            sqlParam.Value = Request.Cookies["BookingId"].Value;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            BookingId.Value = reader["bookingid"].ToString();
            BookingDate.Value = Convert.ToDateTime(reader["bookingdate"].ToString()).ToShortDateString();
            flightname.Value = reader["A_name"].ToString();
            JourneyDate.Value =Convert.ToDateTime( reader["departuredate"].ToString()).ToShortDateString();
            From.Value = reader["fromlocation"].ToString();
            To.Value = reader["tolocation"].ToString();
            NoofSeats.Value = reader["Seats"].ToString();
            ClassType.Value = reader["ClassType"].ToString();
            int totalamount = Convert.ToInt32(reader["amount"].ToString());

            reader.Close();
         
           
            double days;
            double cancelamount;
            double refund;
            days = (Convert.ToDateTime(Convert.ToDateTime(JourneyDate.Value).ToShortDateString())-Convert.ToDateTime(DateTime.Now.ToShortDateString()) ).TotalDays;
            if (days > 30)
            {
                cancelamount = totalamount * 0.10;
                refund = totalamount - cancelamount;
            }
            if (days <= 30 && days > 10)
            {
                cancelamount = totalamount * 0.25;
                refund = totalamount - cancelamount;
            }
            if (days <= 10 && days > 0)
            {
                cancelamount = totalamount * 0.50;
                refund = totalamount - cancelamount;
            }
            else
            {
                cancelamount = 0;
                refund = 0;
            }
            CancellationCharge.Value=cancelamount.ToString();
            RefundableAmount.Value=refund.ToString();
        }
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
        Response.Cookies["Bookingid"].Value = this.Request.Form.Get("BookingId");
        Response.Cookies["Remarks"].Value = this.Request.Form.Get("Remarks");
        cancelTickets();
        Response.Redirect("invoice.aspx");
    }

    private void cancelTickets()
    {
        string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
        //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
        //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

        SqlConnection con = new SqlConnection(ConnectString);

        //string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
        //SqlCommand com = new SqlCommand(str, con);
        //SqlDataReader reader = com.ExecuteReader();
        SqlCommand cmd = new SqlCommand("insert_canceldetails", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlParameter sqlParam = null;
        sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
        sqlParam.Value = Session["cid"];
        sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar,10);
        sqlParam.Value = BookingId.Value;
        sqlParam = cmd.Parameters.Add("@remarks", SqlDbType.Text);
        sqlParam.Value = Remarks.Value;
        sqlParam = cmd.Parameters.Add("@cancelcharge", SqlDbType.Int);
        sqlParam.Value = CancellationCharge.Value;
        sqlParam = cmd.Parameters.Add("@refundamount", SqlDbType.Int);
        sqlParam.Value = RefundableAmount.Value;
        con.Open();
        SqlDataReader reader = cmd.ExecuteReader();
        reader.Read();
        reader.Close();
    }

    protected void Back_Click(object sender, EventArgs e)
    {
        
        Response.Redirect("cancel_page.aspx");
    }
}