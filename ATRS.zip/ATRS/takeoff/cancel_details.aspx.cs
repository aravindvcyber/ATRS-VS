﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Entity;
using ARS.Business;

public partial class cancel_details : System.Web.UI.Page
{
    EntCancel_details EntCD = new EntCancel_details();
    BusCancel_details BusCD = new BusCancel_details();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            EntCD.CustomerId = Session["cid"].ToString();
            EntCD.BookingId = Request.Cookies["bookingid"].Value;

            Dictionary<string, string> candet = new Dictionary<string, string>();

            candet = BusCD.GetCanceldetails(EntCD);

            //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
            

            //SqlConnection con = new SqlConnection(ConnectString);

         
            //SqlCommand cmd = new SqlCommand("cancel_details", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //SqlParameter sqlParam = null;
            //sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 10);
            //sqlParam.Value = Request.Cookies["bookingid"].Value;
            //con.Open();
            //SqlDataReader reader = cmd.ExecuteReader();
            //reader.Read();

            BookingId.Value = candet["bid"].ToString();
            BookingDate.Value = Convert.ToDateTime(candet["bdate"].ToString()).ToShortDateString();
            flightname.Value = candet["Aname"].ToString();
            JourneyDate.Value = Convert.ToDateTime(candet["depdate"].ToString()).ToShortDateString();
            From.Value = candet["flocation"].ToString();
            To.Value = candet["tlocation"].ToString();
            NoofSeats.Value = candet["seats"].ToString();
            ClassType.Value = candet["classtype"].ToString();
            int totalamount = Convert.ToInt32(candet["amount"].ToString());


            //BookingId.Value = reader["bookingid"].ToString();
            //BookingDate.Value = Convert.ToDateTime(reader["bookingdate"].ToString()).ToShortDateString();
            //flightname.Value = reader["A_name"].ToString();
            //JourneyDate.Value =Convert.ToDateTime( reader["departuredate"].ToString()).ToShortDateString();
            //From.Value = reader["fromlocation"].ToString();
            //To.Value = reader["tolocation"].ToString();
            //NoofSeats.Value = reader["Seats"].ToString();
            //ClassType.Value = reader["ClassType"].ToString();
            //int totalamount = Convert.ToInt32(reader["amount"].ToString());

            //reader.Close();
         
           
            double days;
            double cancelamount;
            double refund;
            days = (Convert.ToDateTime(Convert.ToDateTime(JourneyDate.Value).ToShortDateString())-Convert.ToDateTime(DateTime.Now.ToShortDateString()) ).TotalDays;
            if (days > 30)
            {
                cancelamount = totalamount * 0.10;
                refund = totalamount - cancelamount;
            }
            else if (days <= 30 && days > 10)
            {
                cancelamount = totalamount * 0.25;
                refund = totalamount - cancelamount;
            }
            else if (days <= 10 && days > 0)
            {
                cancelamount = totalamount * 0.50;
                refund = totalamount - cancelamount;
            }
            else
            {
                cancelamount = 0;
                refund = 0;
            }


           

            CancellationCharge.Value=((int)cancelamount).ToString();
            RefundableAmount.Value=((int)refund).ToString();

          
        }
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
          if (Page.IsValid && (captcha.Value.ToString() ==
                            Session["randomStr"].ToString()))
        {
        EntCD.CustomerId = Session["cid"].ToString();
        EntCD.BookingId = BookingId.Value;
        EntCD.Remarks = Remarks.Value;
        EntCD.CancelCharge = Convert.ToInt32(CancellationCharge.Value);
        EntCD.Refund = Convert.ToInt32(RefundableAmount.Value);
        BusCD.cancelTickets(EntCD);
        Response.Redirect("cancel_invoice.aspx");
        }
          else
          {
              Label1.Text = "Please re-enter the Captcha-digits correctly...";
          }
   


        //Response.Cookies["Bookingid"].Value = this.Request.Form.Get("BookingId");
        //Response.Cookies["Remarks"].Value = this.Request.Form.Get("Remarks");
        //cancelTickets();
        //Response.Redirect("cancel_invoice.aspx");
    }

    //private void cancelTickets()
    //{
    //    string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
    //    //string QueryString = "select customerid from Booking where customerId='ARS001' and bookingid='B16072901'";
    //    //SqlDataAdapter myCommand = new SqlDataAdapter(QueryString, con);

    //    SqlConnection con = new SqlConnection(ConnectString);

    //    //string str = "select Customers.CustomerName,Booking.BookingId,Schedules.DepartureTime,Booking.BookingDate,Customers.mobile,Booking.BookingCharge,Booking.Amount,Schedules.FromLocation,Schedules.ToLocation,Booking.ClassType,Schedules.DepartureDate from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Schedules on Schedules.Id=Booking.ScheduleId where Customers.customerId='ARS001' and bookingid='B16072901'";
    //    //SqlCommand com = new SqlCommand(str, con);
    //    //SqlDataReader reader = com.ExecuteReader();
    //    SqlCommand cmd = new SqlCommand("insert_canceldetails", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    SqlParameter sqlParam = null;
    //    sqlParam = cmd.Parameters.Add("@customerid", SqlDbType.VarChar, 6);
    //    sqlParam.Value = Session["cid"];
    //    sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar,10);
    //    sqlParam.Value = BookingId.Value;
    //    sqlParam = cmd.Parameters.Add("@remarks", SqlDbType.Text);
    //    sqlParam.Value = Remarks.Value;
    //    sqlParam = cmd.Parameters.Add("@cancelcharge", SqlDbType.Int);
    //    sqlParam.Value = Convert.ToInt32(CancellationCharge.Value);
    //    sqlParam = cmd.Parameters.Add("@refundamount", SqlDbType.Int);
    //    sqlParam.Value = Convert.ToInt32(RefundableAmount.Value);
    //    con.Open();
    //    SqlDataReader reader = cmd.ExecuteReader();
    //    reader.Read();
    //    reader.Close();
    //}

    protected void Back_Click(object sender, EventArgs e)
    {
        
        Response.Redirect("cancel_page.aspx");
    }
}