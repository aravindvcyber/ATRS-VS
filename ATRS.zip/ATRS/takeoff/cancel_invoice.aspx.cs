﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using ARS.Business;
using ARS.Entity;

namespace takeoff
{
    

    public partial class cancel_invoice : System.Web.UI.Page
    {

        BusCancelInvoice BusCI = new BusCancelInvoice();
        EntCancelInvoice EntCI = new EntCancelInvoice();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                EntCI.BookingId = Request.Cookies["bookingid"].Value;

                fetchBookingDetails();
                fetchTicketDetails();
                fetchCancelDetails();
                fetchCancelStatus();



                
                //string ConnectString = "Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;";
              

                //SqlConnection con = new SqlConnection(ConnectString);
                //SqlCommand cmd = new SqlCommand("invoice_canceldetails", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //SqlParameter sqlParam = null;
                //sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 10);
                //sqlParam.Value = Request.Cookies["bookingid"].Value;
                //con.Open();
               
                //SqlDataReader reader = cmd.ExecuteReader();


                //reader.Read();
                

               

                //con = new SqlConnection(ConnectString);
                //cmd = new SqlCommand("invoice_ticketdetails", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //sqlParam = null;
                //sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 10);
                //sqlParam.Value = Request.Cookies["bookingid"].Value;
                //con.Open();

                //reader = cmd.ExecuteReader();
                //while (reader.Read())
                //{
                //    Tickets.Items.Add(reader[0].ToString());
                //}
                //con = new SqlConnection(ConnectString);
                //cmd = new SqlCommand("cancelstatus", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //sqlParam = null;
                //sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 9);
                //sqlParam.Value = Request.Cookies["bookingid"].Value;
                //con.Open();

                //reader = cmd.ExecuteReader();
                
                //con.Close();
                //con = new SqlConnection(ConnectString);
                //cmd = new SqlCommand("invoice_cancel", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //sqlParam = null;
                //sqlParam = cmd.Parameters.Add("@bookingid", SqlDbType.VarChar, 9);
                //sqlParam.Value = Request.Cookies["bookingid"].Value;
                //con.Open();

                //reader = cmd.ExecuteReader();
               
                
                
                //str = "select TicketId from Customers inner join Booking on Booking.CustomerId=Customers.CustomerId inner join Tickets on Tickets.BookingId=Booking.BookingId  where Customers.customerId='ARS001' and Booking.bookingid='B16072901' and status='false'";
                //com = new SqlCommand(str, con);
                //reader = com.ExecuteReader();
                //while (reader.Read())
                //{
                //    TicketsCancel.Text += reader[0].ToString() + " ";
                //}
            }

        }

        private void fetchCancelStatus()
        {
            SqlDataReader reader = BusCI.FetchCancelStatus(EntCI);
            while (reader.Read())
            {

                Status.Text = reader["cancellationid"].ToString();
            }
        }

        private void fetchCancelDetails()
        {
            SqlDataReader reader = BusCI.fetchCancelDetails(EntCI);
            while (reader.Read())
            {

                cancellationcharge.Text = "&#8377 " + reader["cancellationcharge"].ToString();
                refundamount.Text = "&#8377 " + reader["Refund"].ToString();
                totalamount.Text = "&#8377 " + (Convert.ToInt32(reader["cancellationcharge"].ToString()) + Convert.ToInt32(reader["Refund"].ToString())).ToString();

            }
            reader.Close();
            
        }

        private void fetchTicketDetails()
        {
            SqlDataReader reader = BusCI.fetchTicketDetails(EntCI);
            while (reader.Read())
            {
                Tickets.Items.Add(reader[0].ToString());
            }
            
            reader.Close();
        }

        private void fetchBookingDetails()
        {
            SqlDataReader reader = BusCI.fetchBookingDetails(EntCI);
           
            CusName.Text = reader["CustomerName"].ToString();
            BookId.Text = reader["BookingId"].ToString();

            canceldate.Text = reader["CancellationDate"].ToString();
            mobile.Text = reader["mobile"].ToString();

            fromloc.Text = reader["FromLocation"].ToString();
            toloc.Text = reader["ToLocation"].ToString();
            classtype.Text = reader["ClassType"].ToString();
            dateofjourney.Text = Convert.ToDateTime(reader["DepartureDate"]).ToShortDateString() + " " + reader["DepartureTime"].ToString();
            reader.Close();

        }
    }
}