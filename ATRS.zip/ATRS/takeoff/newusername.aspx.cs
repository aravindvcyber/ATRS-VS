﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;
using ARS.Business;
using ARS.Entity;

public partial class newusername : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
 
   
    protected void checkavailability_onclick(object sender, EventArgs e)
    {
        newusercheck username = new newusercheck();
        username.NewUser = txtUsername.Text;

            if (!string.IsNullOrEmpty(txtUsername.Text))
            {
                string str = @"^[a-zA-Z]{1}[a-zA-Z0-9]{6,12}$";
                if (Regex.IsMatch(txtUsername.Text, str))
                {
                    SqlConnection con = new SqlConnection("Data Source=PC202424;Initial Catalog=ATRS;User ID=sa;Password=password-1;");
                    SqlCommand cmd = new SqlCommand("check_uname_available", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter paramUsername = new SqlParameter("@UserName", txtUsername.Text);
                    cmd.Parameters.Add(paramUsername);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    rdr.Read();
                    //SqlCommand cmd = new SqlCommand("select * from Login where UserName=@Name", con);
                    //cmd.Parameters.AddWithValue("@Name", txtUsername.Text);
                    //SqlDataReader dr = cmd.ExecuteReader();
                    if (Convert.ToInt32(rdr["count"].ToString())!=0)
                    {
                        checkusername.Visible = true;
                        imgstatus.ImageUrl = "img/cross.jpeg";
                        lblStatus.Text = @"UserName Already Taken";
                        System.Threading.Thread.Sleep(2000);
                    }
                    else
                    {
                        //checkusername.Visible = true;
                        //imgstatus.ImageUrl = "img/check.png";
                        //lblStatus.Text = "UserName Available";

                        System.Threading.Thread.Sleep(5000);
                        Response.Cookies["uname"].Value = txtUsername.Text;
                        Response.Redirect("Register.aspx");
                    }
                }
                else
                {
                    lblStatus.Text = "Invalid UserName";
                }
            }
            else
            {
                checkusername.Visible = false;
            }
        }
       
    }

