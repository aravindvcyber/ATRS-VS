﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class user : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"]!=null)
        {
            //HiddenField hidDate1 = (HiddenField)this.FormView1.FindControl("HiddenField1");
       
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
    protected void DataGrid1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {
        Response.Redirect("comments.aspx");
    }
}