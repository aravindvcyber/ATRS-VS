﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CryptSharp;
using System.Text;
using CryptSharp.Utility;
using System.Security.Cryptography;


public partial class _Default : System.Web.UI.Page
{
    public byte[] sa = new byte[16];
    public String pwd;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnEncryptPassword_Click(object sender, EventArgs e)
    {
        //string cryptedPassword = Crypter.Blowfish.Crypt(txtPassword.Text.Trim());
        //txtPassword0.Text = cryptedPassword;
        var crypter = new BlowfishCrypter();
        var passwordBytes = Encoding.Unicode.GetBytes(txtPassword.Text.Trim()); // Convert passwords to bytes.

        var salt = GenerateSalt(); // Generate byte array 16 long from cryptographically random source.
        var saltString = Convert.ToBase64String(salt); // Convert to string for printing.
        sa = salt;
   
        var hash = BlowfishCipher.BCrypt(passwordBytes, salt, 10); // Perform bcrypt algorithm with set difficulty.
        var hashString = Convert.ToBase64String(hash); // Convert hash to string for storing/printing
        pwd = Convert.ToBase64String(hash);
        txtPassword0.Text = hashString;
        txtPassword2.Text = saltString;
        //Response.Write(string.Format("Password encrypted successfully. Encrypted password is: {0}", cryptedPassword));
    }

    private byte[] GenerateSalt()
    {
        // To be completely secure we should generate a salt from a cryptographical random number source.
        var prov = new RNGCryptoServiceProvider();
        byte[] salt = new byte[16];
        prov.GetBytes(salt);
        return salt;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        byte[] testPassword = Encoding.ASCII.GetBytes(txtPassword1.Text.Trim());

        byte[] salt = new byte[16];
        salt=Encoding.ASCII.GetBytes(txtPassword2.Text);

        String cryptedPassword = txtPassword0.Text.Trim();
        bool matches = Crypter.CheckPassword(BlowfishCipher.BCrypt(testPassword, sa, 10), pwd );

        //bool matches = Crypter.CheckPassword(sa, cryptedPassword);

        if (matches == true)
            Label1.Text = "Successfull";
        else
            Label1.Text = "Failure";

    }
}