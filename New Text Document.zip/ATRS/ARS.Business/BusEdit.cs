﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ARS.Data;
using ARS.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ARS.Business
{
    public class BusEdit
    {
        DatEdit DatE = new DatEdit();
        public void updatecustomerdetails(EntEdit EntE)
        {
            SqlParameter[] sp = new SqlParameter[12];

            sp[0] = new SqlParameter("@CustomerId", SqlDbType.VarChar, 6);
            sp[0].Value = EntE.CustomerId;
            sp[1] = new SqlParameter("@first", SqlDbType.VarChar, 25);
            sp[1].Value = EntE.FirstName;
            sp[2] = new SqlParameter("@email", SqlDbType.VarChar, 50);
            sp[2].Value = EntE.EmailId;
            sp[3] = new SqlParameter("@security", SqlDbType.VarChar, 50);
            sp[3].Value = EntE.SecurityQuestion;
            sp[4] = new SqlParameter("@securityans", SqlDbType.VarChar, 50);
            sp[4].Value = EntE.SecurityAnswer;
            sp[5] = new SqlParameter("@mobile", SqlDbType.VarChar, 15);
            sp[5].Value = EntE.Mobile;
            sp[6] = new SqlParameter("@gender", SqlDbType.VarChar, 10);
            sp[6].Value = EntE.Gender;
            sp[7] = new SqlParameter("@dob", SqlDbType.Date);
            sp[7].Value = EntE.DOB.ToShortDateString();
            sp[8] = new SqlParameter("@last", SqlDbType.VarChar, 25);
            sp[8].Value = EntE.LastName;
            sp[9] = new SqlParameter("@address", SqlDbType.VarChar, 100);
            sp[9].Value = EntE.Address;
            sp[10] = new SqlParameter("@ssntype", SqlDbType.VarChar, 30);
            sp[10].Value = EntE.SsnType;
            sp[11] = new SqlParameter("@ssnvalue", SqlDbType.VarChar, 50);
            sp[11].Value = EntE.SsnValue;
          
            DatE.updatecustomerdetails(sp);

        }
        public EntEdit viewcustomerdetails(EntEdit EntE)
        {
            SqlParameter sp = new SqlParameter();

            sp = new SqlParameter("@CustomerId", SqlDbType.VarChar, 6);
            sp.Value = EntE.CustomerId;

            Dictionary<string, string> DicPD = DatE.viewcustomerdetails(sp);


            EntE.FirstName = DicPD["fname"].ToString();

            EntE.EmailId = DicPD["emailid"].ToString();

            EntE.SecurityQuestion = DicPD["SecurityQuestion"].ToString();

            EntE.SecurityAnswer = DicPD["SecurityAnswer"].ToString();

            EntE.Mobile = DicPD["mobile"].ToString();

            EntE.Gender = DicPD["gender"].ToString();

            EntE.DOB = Convert.ToDateTime(DicPD["DOB"].ToString());

            EntE.LastName = DicPD["lname"].ToString();

            EntE.Address = DicPD["address"].ToString();

            EntE.SsnType = DicPD["ssntype"].ToString();

            EntE.SsnValue = DicPD["ssnvalue"].ToString();

            return EntE;

        }

        public DataSet fetchSsnType()
        {

            return DatE.fetchSsnType();
        }

        public DataSet fetchSecurityQues()
        {


            return DatE.fetchSecurityQues();
        }
    }
}
