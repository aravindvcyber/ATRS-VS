﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ARS.Data
{
    public class DatEdit
    {
        SqlConnection con = null;

        public DatEdit()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ATRSConnectionString"].ConnectionString);
        }
        public void updatecustomerdetails(SqlParameter[] sp)
        {

            SqlCommand com = new SqlCommand("updatecustomerdetails", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddRange(sp);
            try
            {
                con.Open();
                com.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Updating Customer Details. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            

        }
        public Dictionary<string,string> viewcustomerdetails(SqlParameter sp)
        {
            Dictionary<string, string> DicPD = new Dictionary<string, string>();
            SqlCommand com = new SqlCommand("selectCommand", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.Add(sp);
            try
            {
                con.Open();
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    DicPD.Add("fname",rdr["firstname"].ToString());
                    DicPD.Add("lname", rdr["lastname"].ToString());
                    DicPD.Add("emailid", rdr["emailid"].ToString());
                    DicPD.Add("ssntype", rdr["ssntype"].ToString());
                    DicPD.Add("ssnvalue", rdr["ssnvalue"].ToString());
                    DicPD.Add("SecurityQuestion", rdr["SecurityQuestion"].ToString());
                    DicPD.Add("SecurityAnswer", rdr["SecurityAnswer"].ToString());
                    DicPD.Add("gender", rdr["gender"].ToString());
                    DicPD.Add("address", rdr["address"].ToString());
                    DicPD.Add("mobile", rdr["mobile"].ToString());
                    DicPD.Add("DOB", rdr["DOB"].ToString());
                    //this.Page.Form.V date.Text   = rdr["dob"].ToString();
                    
                }
            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception Getting Customer Details. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return DicPD;

        }


        public DataSet fetchSsnType()
        {
            SqlCommand com = new SqlCommand("getssntypes", con);
            com.CommandType = CommandType.StoredProcedure;
           
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "SSN_Type");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting  SSN Types. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }

        public DataSet fetchSecurityQues()
        {
            SqlCommand com = new SqlCommand("getsecutiyques", con);
            com.CommandType = CommandType.StoredProcedure;
            
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(com);

                sqlAdapter.Fill(ds, "SecurityQuestions");

            }
            catch (Exception ex)
            {
                // Code to check for primary key violation (duplicate account name)
                // or other database errors omitted for clarity
                throw new Exception("Exception getting Security Questions. " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return ds;
        }
    }
}
