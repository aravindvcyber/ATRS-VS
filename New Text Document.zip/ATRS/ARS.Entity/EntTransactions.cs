﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARS.Entity
{
    public class EntTransactions
    {
        private string customerid;

        public string CustomerId
        {
            get { return customerid; }
            set { customerid = value; }
        }
        
    }
}
