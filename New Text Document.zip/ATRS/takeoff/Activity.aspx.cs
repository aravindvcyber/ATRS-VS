﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.Xml.Xsl;
using System.Xml;

public partial class Activity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ((Admin)this.Master).SMSmsg = "Activity Logger";
        ((Admin)this.Master).Headmsg = "Successfull!";
        if (!Page.IsPostBack)
        {
            if (Request.QueryString.Count == 0)
            {
                dvActivityReport.InnerHtml = ApplyXSLTransformation();
            }
            else
            {
                dvActivityReport.InnerHtml = ApplyXSLTransformation(Request.QueryString["fid"]);
            }
        }
    }
    
    private string ApplyXSLTransformation(string fid)
    {
        string strHtml;


        string strXstFile = Server.MapPath("Styles/ActivityLog.xslt");
        XslCompiledTransform x = new XslCompiledTransform();

        // Load the XML 
        string path = HttpContext.Current.Server.MapPath("Logs_App");

        string File = path + "\\" + fid;

      
        StringBuilder sbLogFiles = new StringBuilder();
        sbLogFiles.Append("<Activities>");
       
            StreamReader strmReader = new StreamReader(File);
            sbLogFiles.Append(strmReader.ReadToEnd());
            strmReader.Close();

        sbLogFiles.Append("</Activities>");
        XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

        var objOrderedXml = (from a in objXmlLog.Elements("Activity")
                             
                             select a);

        XElement objFinalXML = new XElement("Activities", objOrderedXml);

        XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
        XPathDocument doc = new XPathDocument(objXmlReader);

        // Load the style sheet.
        XslCompiledTransform xslt = new XslCompiledTransform();
        xslt.Load(strXstFile);
        MemoryStream ms = new MemoryStream();
        XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
        StreamReader rd = new StreamReader(ms);
        xslt.Transform(doc, writer);
        ms.Position = 0;
        strHtml = rd.ReadToEnd();
        rd.Close();
        ms.Close();
        return strHtml;
    }
    private string ApplyXSLTransformation()
        {
            string strHtml;
           

            string strXstFile = Server.MapPath("Styles/ActivityLog.xslt");
            XslCompiledTransform x = new XslCompiledTransform();

            // Load the XML 
            string path = HttpContext.Current.Server.MapPath("Logs_App");
            string[] strFiles = Directory.GetFiles(path);
            StringBuilder sbLogFiles = new StringBuilder();
            sbLogFiles.Append("<Activities>");
            for (int i = 0; i < strFiles.Length; i++)
            {
                StreamReader strmReader = new StreamReader(strFiles[i]);
                sbLogFiles.Append(strmReader.ReadToEnd());
                strmReader.Close();
            }
            sbLogFiles.Append("</Activities>");
            XElement objXmlLog = XElement.Parse(sbLogFiles.ToString());

            var objOrderedXml = (from a in objXmlLog.Elements("Activity")
                                
                                 select a);

            XElement objFinalXML = new XElement("Activities", objOrderedXml);

            XmlReader objXmlReader = XmlReader.Create(new StringReader(objFinalXML.ToString()));
            XPathDocument doc = new XPathDocument(objXmlReader);

            // Load the style sheet.
            XslCompiledTransform xslt = new XslCompiledTransform();
            xslt.Load(strXstFile);
            MemoryStream ms = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(ms, Encoding.ASCII);
            StreamReader rd = new StreamReader(ms);
            xslt.Transform(doc, writer);
            ms.Position = 0;
            strHtml = rd.ReadToEnd();
            rd.Close();
            ms.Close();
            return strHtml;
        }
}